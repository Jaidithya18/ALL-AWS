# README #
Resolving Unwanted Commits in Feature Branch
This README explains how to remove or revert an unwanted commit pushed by someone else in your feature branch, especially when you�ve made subsequent changes.


### What is this repository for? ###

Step-1 Identifieds the unwanted
 identify the unwanted commit

![identify](images/review_file_changed.png)

 
Step-2 Fetch the author and commit ID to revert

![identify](images/identify_author.png)

Step-3 open the branch in local to revert
![identify](images/open_branch.png)

Step-4  revert the commit 
![identify](images/revert_changes.png)


Step-5  Check the file change
![identify](images/after_revert.png)

