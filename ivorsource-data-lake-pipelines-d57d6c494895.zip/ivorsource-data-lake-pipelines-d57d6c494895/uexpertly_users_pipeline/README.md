#  DATA LAKE PIPELINE TO GET USERS DATA FROM COGNITO TO S3

##  Table of Contents

1. [Introduction](#1-introduction)  
2. [DataLake Architecture](#2-data-lake-architecture)
3. [Flowchart](#3-flowchart)
4. [AWS Cognito Overview](#4-aws-cognito-overview) 
5. [Data Pipeline Architecture](#5-data-pipeline-architecture)  
6. [Amazon S3 – Data Storage](#6-amazon-s3--data-storage)  
7. [IAM Roles and Permissions](#7-iam-roles-and-permissions)  
8. [AWS Glue – ETL Processing and Data Transformation](#8-aws-glue--etl-processing-and-data-transformation)  
9. [Data Pipeline Workflow](#9-data-pipeline-workflow)  
10. [Benefits of the Pipeline](#10-benefits-of-the-pipeline)  
11. [Conclusion](#11-conclusion)
12. [Prerequisites](#12-prerequisites)
      [S3 repository](https://bitbucket.org/ivorsource/s3/src/main/), 
      [IAM repository](https://bitbucket.org/ivorsource/iam_roles/src/IAM_Roles/), 
      [Glue repository](https://bitbucket.org/ivorsource/glue/src/main/)


---

## 1. Introduction

This report outlines the implementation of a historical users' data lake and Lakehouse pipeline using AWS services. The source of data is AWS Cognito User Pool, which stores UEXPERTLY users' authentication and profile data. The target storage is an Amazon S3 bucket, where user data is processed and stored using AWS Glue. This pipeline enables efficient data extraction, transformation, and loading (ETL) for further analytics and insights.

---

## 2. Data Lake Architecture

These architectures are implemented in Spark jobs that fetch user data from AWS Cognito and store it in Amazon S3 in different formats and structures—either as raw Parquet files (Data Lake).

A **Data Lake** is a centralized repository that allows you to store all your structured and unstructured data at any scale. In this project, Amazon S3 is used as the storage layer to hold raw user data extracted from Amazon Cognito. The data is processed using Apache Spark within an AWS Glue job and stored in **Parquet format**, making it efficient for analytical queries.

#### Key Concepts:
- **Storage:** Amazon S3 is used to store raw, untransformed data.
- **Processing:** Spark transforms data from Cognito into a tabular format.
- **Format:** Data is stored in Parquet, a columnar storage format optimized for big data.
- **Use Case:** Suitable for storing high volumes of raw data for future processing, exploration, or machine learning workflows.

This approach separates storage and compute, allowing scalability and flexibility for different analytics engines.

---

## 3. Flowchart of entire DataLake & LakeHouse Pipeline



![Flowchart_of_entire_DataLake&LakeHouse_Pipeline](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/flowchart.png)


## 4. AWS Cognito Overview

AWS Cognito is a fully managed identity service provided by AWS that enables user authentication, authorization, and user management for web and mobile applications.

It offers two key components:

- **Cognito User Pools**

  Cognito User Pools are used to manage and authenticate users. They provide built-in sign-up and sign-in functionality, user directory storage, and user attribute management. Users can authenticate directly through Cognito or via social identity providers (UExpertly). 

- **Cognito Identity Pools**

  Cognito Identity Pools allow authenticated users to access AWS resources using temporary AWS credentials. They integrate with User Pools and third-party authentication providers to grant controlled access to AWS services like S3, DynamoDB, and Lambda.
 
![Cognito_User_pool_Overview](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/userpool.png)
 
### Features of AWS Cognito
- **User Authentication & Authorization**: Supports user sign-up, sign-in, and authentication mechanisms.
- **Identity Federation**: Enables login via external identity providers (UExpertly).
- **Multi-Factor Authentication (MFA)**: Provides an extra layer of security.
- **Customizable Authentication Flow**: Allows the implementation of custom authentication and authorization workflows using AWS Lambda triggers.
- **User Attributes Management**: Supports predefined and custom attributes for storing user details.
- **Security & Compliance**: Implements encryption, token-based authentication, and compliance with security standards.
- **Integration with AWS Services**: Works with API Gateway, Lambda, S3, DynamoDB, and more.

---

## 5. Data Pipeline Architecture

The historical users' data lake and Lakehouse pipeline involve several AWS services.

### Pipeline Components:

- **AWS Cognito User Pool** – The source storing UEXPERTLY users’ data.  
- **AWS Glue** – Extracts, transforms, and loads (ETL) user data from Cognito to Amazon S3.  
- **Amazon S3** – The storage layer for raw and processed user data.  
- **AWS Glue Data Catalog** – Maintains metadata for easy data discovery and query execution.  
- **AWS IAM** – Controls access and security for the pipeline.  
- **AWS CloudWatch** – Monitors job execution and logs errors.  
- **AWS Athena** – Enables SQL-like queries on the data stored in S3.  
- **AWS Lake Formation** – Enhances data governance and security in the Lakehouse.  


## 6. Amazon S3 – Data Storage

Amazon S3 serves as the storage layer in this pipeline. It is used to store both raw and processed data. The data is initially extracted from the Cognito User Pool, transformed into an optimized format (such as Parquet), and then loaded into S3. Amazon S3 ensures highly durable and scalable storage for both small and large datasets, making it ideal for handling historical user data at scale.


 **[S3 repository](https://bitbucket.org/ivorsource/s3/src/main/)
 
 
### Create an S3 Bucket:

1. In the AWS Management Console, navigate to **S3** and create a new bucket with appropriate naming and configuration (`datalake-dev-users`).

 **CLI commad to create the bucket: **

``` sh
  aws s3 mb s3://datalake-dev-users --region us-east-2
```

![Creating_S3_Bucket](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/createbucket.png)

  **Creating Folders/Layers in S3 Bucket:**
   
  **CLI commands to create the folders –**
   
``` sh
aws s3 cp /dev/null s3://datalake-dev-users/rawlayer/ --region us-east-2
```

``` sh
aws s3 cp /dev/null s3://datalake-dev-users/logs/ --region us-east-2
```

``` sh
aws s3 cp /dev/null s3://datalake-dev-users/scripts/ --region us-east-2
```

![Bucket_Folders](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/bucketfolders.png)


## 7. IAM Roles and Permissions

### IAM Role for AWS Glue

**Role Name**: `AWSGlueCognitoRole`

### Permissions:

 **CLI command to Attach AmazonS3FullAccess**

``` sh
aws iam attach-role-policy \
  --role-name AWSGlueCognitoRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess
```

**CLI command to Attach AWSGlueServiceRole**

``` sh
aws iam attach-role-policy \
  --role-name AWSGlueCognitoRole \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole
```

**CLI command to Attach AmazonCognitoReadOnly**

``` sh
aws iam attach-role-policy \
  --role-name AWSGlueCognitoRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonCognitoReadOnly
```

**CLI command to Attach CloudWatchLogsFullAccess**

``` sh
aws iam attach-role-policy \
  --role-name AWSGlueCognitoRole \
  --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess
```


# [IAM repository](https://bitbucket.org/ivorsource/iam_roles/src/IAM_Roles/)

- `AmazonS3FullAccess` – Allows full access to Amazon S3 for storing extracted and processed data.  
- `AWSGlueServiceRole` – Grants AWS Glue the required permissions to perform ETL jobs and interact with AWS Glue Data Catalog.  
- `AmazonCognitoReadOnly` – Provides read-only access to AWS Cognito to fetch user data.  
- `CloudWatchLogsFullAccess` – Enables logging of Glue job executions for monitoring and debugging.  

---

## 8. AWS Glue – ETL Processing and Data Transformation

AWS Glue is used for **extracting**, **transforming**, and **loading (ETL)** user data. It connects to the Cognito User Pool, extracts user data, applies transformations (e.g., formatting into Parquet for performance optimization), and loads the processed data into Amazon S3. Glue also manages the schema with its Data Catalog, which provides a centralized repository for metadata.

### How to do it:

#### Set Up AWS Glue Data Catalog:

- In the AWS Glue Console, create a new **Data Catalog** and register the necessary database to track metadata of user data.
- Add tables to the Glue Catalog for tracking different datasets.

#### Create a Glue Job:

- AWS Glue Console → Create a new ETL job

 **CLI commad to create a Glue job**

``` sh
aws glue create-job \
  --name MyGlueJob \
  --role AWSGlueCognitoRole \
  --command "Name=glueetl,ScriptLocation=s3://datalake-dev-users/scripts/Lake_house_users.py" \
  --default-arguments '{"--TempDir": "s3://datalake-dev-users/temperory/", "--additional-python-modules": "pyarrow==2, pandas==1.2.3"}' \
  --description "ETL job to transform and load data from Cognito to S3" \
  --connections "connection-name" \
  --max-capacity 10 \
  --timeout 240 \
  --notification-property "NotifyDelayAfter=60"
```


**[Glue repository](https://bitbucket.org/ivorsource/glue/src/main/)


**Step 1**  

![Creating_Glue_ETL](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/glueetl.png)

**Step 2**  

![Glue_Script](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/gluescript.png)

**Step 3**  

![View_Glue_Job_Runs](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/glueruns.png)

**Step 4**  

![Transformed_User_data](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/45b7409a07b18948cb4abc4bf16884f6ac83f945/uexpertly_users_pipeline/images/s3parquet.png)



## 9. Data Pipeline Workflow

1. **Data Extraction**: AWS Glue connects to Cognito User Pool and retrieves user attributes such as username, email, and sign-in history.  
2. **Data Transformation**: AWS Glue processes and formats the data into Parquet for optimized storage.  
3. **Data Storage**: The processed data is stored in an Amazon S3 bucket.  
4. **Metadata Management**: AWS Glue Crawler updates the Glue Data Catalog for seamless querying.  
5. **Data Querying & Analytics**: AWS Athena allows SQL-based queries for insights.  
6. **Automation & Monitoring**: AWS CloudWatch tracks execution, and AWS IAM enforces security.  


## 10. Benefits of the Pipeline

- **Scalability**: Handles historical and real-time user data efficiently.  
- **Automation**: AWS Glue automates ETL processes, reducing manual workload.  
- **Security & Compliance**: Meets data privacy regulations.  
- **Cost-Effectiveness**: Uses serverless architecture to minimize costs.  
- **Data Accessibility**: Enables efficient querying via AWS Glue Data Catalog and Athena.  


## 11. Conclusion

The implementation of the historical users' data lake and Lakehouse pipeline using AWS Cognito, AWS Glue, and Amazon S3 demonstrates a robust and scalable approach to managing and analyzing user data. By leveraging AWS services, the pipeline ensures efficient data extraction, transformation, and storage while maintaining high security and compliance standards. This architecture not only facilitates streamlined data processing but also enables future expansion for real-time analytics and deeper insights into user behavior. Through proper security measures, automation, and performance optimization, this solution provides a reliable foundation for long-term data-driven decision-making.


## 12. Prerequisites

To run this pipeline, please refer to the prerequisite setup in the following repository:  

 [Click here to open the S3 repository](https://bitbucket.org/ivorsource/s3/src/main/)

[Click here to open the IAM repository](https://bitbucket.org/ivorsource/iam_roles/src/IAM_Roles/)

[Click here to open the Glue repository](https://bitbucket.org/ivorsource/glue/src/main/)



# AWS Glue Job for USERS Incremental Pipeline Deployment via Bitbucket Pipelines

This project implements a fully automated data ingestion pipeline that reads latest Cognito user data, upserts it into a Parquet-based S3 data lake, and manages orchestration and deployment using AWS Step Functions, EventBridge Scheduler, and Bitbucket CI/CD.

Please refer to the flowchart_incremental.png to see the functionality of glue job.

![](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/a718cb70b570bdf28a1b5041ecc026480e21d059/uexpertly_users_pipeline/images/flowchart_incremental.png)

---
## ✨ Features

Fetches new or modified users from AWS Cognito.

Maintains a metadata timestamp in S3 to track last successful ingestion.

Performs upsert merge of user data into Parquet files on S3.

Orchestrated using AWS Step Functions.

Scheduled execution via EventBridge Scheduler (Every Sunday at 11:30 PM UTC).

Fully deployed using Bitbucket pipelines (for dev and main environments).

Please refer to the aws_services_incremental.png understand the AWS services used in this pipeline

![](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/a718cb70b570bdf28a1b5041ecc026480e21d059/uexpertly_users_pipeline/images/aws_services_incremental.png)

---

## 📁 Repository Structure

.

├── users_data_incremental_pipeline/

│   └── payload_sf_datalake_users_incremental.json  #Payload to run the step function configured in EventBridge Scheduler

│   └── sf_datalake_users_incremental.json          #Step function definition

│   └── datalake_users_incremental_glue.py          # Main Glue script

│   └── README.md

├── bitbucket-pipelines.yml                         # Pipeline for CI/CD


---

## 📁 Project Structure

EventBridge Scheduler

        |
        
        v
Step Function (sf_datalake_users_incremental)

        |
        
        +--> Check/Create Glue Job
        
        |
        
        +--> Start Glue Job
        
        |
        
        +--> Monitor Glue Job (Wait/Check/Evaluate)
        
        v
        
AWS Glue Job (datalake_users_incremental)

        |
        
        +--> Fetch Cognito Users
        
        +--> Compare with metadata timestamp
        
        +--> Filter new users
        
        +--> Merge into existing Parquet files
        
        +--> Update metadata timestamp in S3

## 📅 Schedule

Cron Expression: cron(30 23 ? * 7 *)

Runs every Saturday at 11:30 PM UTC

Managed by EventBridge Scheduler

## 

## ⚙️ What the Pipeline Does

This Bitbucket pipeline automates the following tasks for both `dev` and `main` (prod) branches:

### 1. **Upload Glue Script to S3**
- Uploads scripts in the `scripts/` directory to a specified S3 bucket.
- Configures AWS CLI credentials dynamically from Bitbucket environment variables.

### 2. **Create or Update AWS Step Function State Machine**
- Checks if the State Machine (`sf_datalake_users_incremental`) already exists.
- If it exists: updates the State Machine with the latest script and config.
- If not: creates the State Machine with appropriate IAM role and script location.

### 3. **Schedule the State Machine using EventBridge Scheduler**
- Creates or updates a schedule using AWS EventBridge Scheduler.
- Runs every Saturday at 11:30 PM UTC.
- Passes job parameters including:
  - `--region`
  - `--user-pool-id`
  - `--metadata-bucket` and `--metadata-key` (for tracking last modified timestamp)
  - `--output-path`
  - `--default-timestamp` (fallback value)

---

## 📦 Environment Variables (Bitbucket)

You must set the following secure variables in your Bitbucket repository settings:

### For Dev:
- `AWS_ACCESS_KEY_DEV`
- `AWS_SECRET_ACCESS_KEY_DEV`
- `AWS_REGION_DEV`
- `AWS_ACCOUNT_ID_DEV`
- `GLUE_JOB_ROLE_ARN_DEV`
- `S3_BUCKET_NAME_DEV`

### For Prod:
- `AWS_ACCESS_KEY_PROD`
- `AWS_SECRET_ACCESS_KEY_PROD`
- `AWS_REGION_PROD`
- `AWS_ACCOUNT_ID_PROD`
- `GLUE_JOB_ROLE_ARN_PROD`
- `S3_BUCKET_NAME_PROD`

---

## 🧠 Glue Job: Upsert Logic

The Glue job performs an **incremental upsert** based on user changes in Cognito. Here's a simplified overview:

- **Reads Cognito data** via AWS SDK using a timestamp filter (`last_modified_date`).
- **Compares** with previous records stored in S3.
- **Writes new or updated records** to S3 Data Lake in `Parquet` or `JSON` format.
- Tracks last modified time using a `metadata` file in S3.

---

## ✅ Deployment

- Push to `dev` → Triggers deployment to dev environment.
- Push to `main` → Triggers deployment to production.

Each environment handles its own S3 bucket, IAM roles, and Glue job resources.

---

## 🔐 Security

- Secrets are **not hardcoded**; they are managed via Bitbucket secured environment variables.
- The Glue job uses an IAM role with required permissions to access:
  - Cognito
  - S3
  - Glue

---
## ⚖ IAM Roles Required

Bitbucket Pipeline IAM Permissions

glue: GetJob, glue:CreateJob, glue:StartJobRun, glue:GetJobRun

stepfunctions: CreateStateMachine, UpdateStateMachine, ListStateMachines

scheduler: CreateSchedule, UpdateSchedule, GetSchedule

s3: PutObject, GetObject, ListBucket

iam: PassRole for Glue and EventBridge target roles

---
## 🔍 Monitoring

Logs from Glue job: CloudWatch Logs

Step Function execution: AWS Step Functions Console

Schedule status: Amazon EventBridge > Scheduler

## ✅ Summary

This pipeline helps keep your data lake in sync with the latest changes in AWS Cognito user pools. With its parameterized, automated, and scheduled deployment through Bitbucket, it is a scalable and production-ready solution for incremental data ingestion.
