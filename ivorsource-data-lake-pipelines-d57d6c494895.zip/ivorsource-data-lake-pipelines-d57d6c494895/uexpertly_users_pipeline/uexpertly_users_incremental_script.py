import os
import boto3
from datetime import datetime, timezone
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import to_timestamp, col, coalesce, greatest
import argparse


def get_clients(region: str):
    os.environ['AWS_REGION'] = region
    return (
        boto3.client('cognito-idp', region_name=region),
        boto3.client('s3')
    )


def fetch_cognito_users(cognito_client, user_pool_id):
    users = []
    try:
        response = cognito_client.list_users(UserPoolId=user_pool_id)
        users.extend(response.get("Users", []))
        while "PaginationToken" in response:
            response = cognito_client.list_users(
                UserPoolId=user_pool_id,
                PaginationToken=response["PaginationToken"]
            )
            users.extend(response.get("Users", []))
        print(f"Total users retrieved: {len(users)}")
        return users
    except Exception as e:
        print(f"Error fetching users from Cognito: {e}")
        raise


def get_last_processed_timestamp(s3_client, bucket: str, key: str):
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        timestamp_str = response['Body'].read().decode('utf-8').strip()
        return datetime.fromisoformat(timestamp_str) if timestamp_str else None
    except s3_client.exceptions.NoSuchKey:
        print("Metadata file not found. Processing all users.")
        return None
    except Exception as e:
        print(f"Error reading metadata file: {e}")
        return None


def filter_new_records(users, last_ts):
    new_users = []
    latest_ts = last_ts

    if isinstance(last_ts, (int, float)):
        last_ts = datetime.fromtimestamp(last_ts, tz=timezone.utc)
    elif isinstance(last_ts, str):
        try:
            last_ts = datetime.fromisoformat(last_ts)
        except Exception:
            last_ts = None

    for user in users:
        created_at = user.get('UserCreateDate')
        modified_at = user.get('UserLastModifiedDate')

        created_dt = datetime.fromtimestamp(created_at, tz=timezone.utc) if isinstance(created_at, (int, float)) else created_at
        modified_dt = datetime.fromtimestamp(modified_at, tz=timezone.utc) if isinstance(modified_at, (int, float)) else modified_at

        if modified_dt and (last_ts is None or modified_dt > last_ts):
            user_dict = {attr['Name']: attr['Value'] for attr in user.get('Attributes', [])}
            user_dict.update({
                'Username': user['Username'],
                'CreatedAt': created_dt.isoformat() if created_dt else None,
                'LastModifiedAt': modified_dt.isoformat()
            })
            new_users.append(user_dict)

            if not latest_ts or modified_dt > latest_ts:
                latest_ts = modified_dt

    print(f"New users since {last_ts}: {len(new_users)}")
    return new_users, latest_ts


def update_metadata_timestamp(s3_client, bucket: str, key: str, timestamp: datetime):
    try:
        s3_client.put_object(Bucket=bucket, Key=key, Body=timestamp.isoformat())
        print(f"Updated metadata timestamp: {timestamp}")
    except Exception as e:
        print(f"Error updating metadata: {e}")


def upsert_data(spark: SparkSession, df_new: DataFrame, dest_path: str):
    try:
        df_existing = spark.read.parquet(dest_path)
        print("Merging with existing data...")

        df_merged = df_existing.alias('existing') \
            .join(df_new.alias('new'), on='Username', how='outer') \
            .withColumn('CreatedAt', coalesce(col('new.CreatedAt'), col('existing.CreatedAt'))) \
            .withColumn('LastModifiedAt', greatest(col('new.LastModifiedAt'), col('existing.LastModifiedAt'))) \
            .select(
                coalesce(col('new.Username'), col('existing.Username')).alias('Username'),
                col('CreatedAt'), col('LastModifiedAt'),
                col('new.email'), col('new.email_verified'), col('new.name'),
                col('new.phone_number'), col('new.phone_number_verified'), col('new.sub'),
                col('new.custom_domain'), col('new.custom_gender'),
                col('new.custom_referralEmail'), col('new.custom_referralPhoneNumber'),
                col('new.custom_referralUserName')
            ).filter(col('Username').isNotNull())

        df_merged.write.format("parquet").mode("overwrite").save(dest_path)
        print("Merge completed.")
    except Exception as e:
        print(f"Error in merge: {e}. Writing new data.")
        df_new.write.format("parquet").mode("overwrite").save(dest_path)
    finally:
        spark.stop()


def main(region: str, user_pool_id: str, metadata_bucket: str, metadata_key: str, output_path: str, default_ts: str = None):
    cognito_client, s3_client = get_clients(region)
    users = fetch_cognito_users(cognito_client, user_pool_id)

    last_ts = get_last_processed_timestamp(s3_client, metadata_bucket, metadata_key)
    if default_ts:
        last_ts = datetime.fromisoformat(default_ts)
        print(f"Overriding timestamp with: {last_ts}")

    new_users, latest_ts = filter_new_records(users, last_ts)

    spark = SparkSession.builder.appName("CognitoToS3Job").getOrCreate()

    if new_users:
        df_new = spark.createDataFrame(new_users)
        for col_name in df_new.columns:
            if ':' in col_name:
                df_new = df_new.withColumnRenamed(col_name, col_name.replace(':', '_'))

        df_new = df_new.withColumn("CreatedAt", to_timestamp(col("CreatedAt"))) \
                       .withColumn("LastModifiedAt", to_timestamp(col("LastModifiedAt"))) \
                       .coalesce(1)

        upsert_data(spark, df_new, output_path)
        update_metadata_timestamp(s3_client, metadata_bucket, metadata_key, latest_ts)
    else:
        print("No new users to process.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch Cognito users and store to S3")
    parser.add_argument("--region", required=True, help="AWS region")
    parser.add_argument("--user-pool-id", required=True, help="Cognito User Pool ID")
    parser.add_argument("--metadata-bucket", required=True, help="S3 bucket for metadata")
    parser.add_argument("--metadata-key", required=True, help="S3 key for metadata")
    parser.add_argument("--output-path", required=True, help="S3 output path for user data")
    parser.add_argument("--default-timestamp", required=False, help="Optional: override last processed timestamp")

    #args = parser.parse_args()
    args, unknown = parser.parse_known_args()
    main(
        region=args.region,
        user_pool_id=args.user_pool_id,
        metadata_bucket=args.metadata_bucket,
        metadata_key=args.metadata_key,
        output_path=args.output_path,
        default_ts=args.default_timestamp
    )