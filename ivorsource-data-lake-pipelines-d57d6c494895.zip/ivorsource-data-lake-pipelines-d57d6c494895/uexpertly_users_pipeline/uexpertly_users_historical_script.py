import boto3
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, to_timestamp
from datetime import datetime
import sys
import time

# Parse script arguments passed to the Glue job
args = sys.argv
AWS_COGNITO_REGION = args[args.index('--AWS_COGNITO_REGION') + 1]
COGNITO_USER_POOL_ID = args[args.index('--COGNITO_USER_POOL_ID') + 1]
destination_bucket = args[args.index('--output_path') + 1]
bucket_name = args[args.index('--bucket_name') + 1]
metadata_key = args[args.index('--metadata_key') + 1]
metadata_file_path = args[args.index('--metadata_file_path') + 1]

# Initialize AWS SDK clients for Cognito and S3
cognito_client = boto3.client('cognito-idp', region_name=AWS_COGNITO_REGION)
s3_client = boto3.client('s3', region_name=AWS_COGNITO_REGION)

# ----------------------------------------------------------
# Read the last processed timestamp from S3 metadata file
# ----------------------------------------------------------
def read_metadata(bucket, key):
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        return json.loads(obj['Body'].read().decode('utf-8'))['last_timestamp']
    except s3_client.exceptions.NoSuchKey:
        return '1970-01-01 00:00:00'
    except Exception as e:
        print(f"Error reading metadata: {e}")
        raise

# ------------------------------------------------------
# Write the updated timestamp and metadata back to S3
# ------------------------------------------------------
def write_metadata(bucket, key, last_timestamp):
    try:
        metadata = {
            "last_timestamp": str(last_timestamp),
            "last_run": datetime.now().isoformat()
        }
        s3_client.put_object(Bucket=bucket, Key=key, Body=json.dumps(metadata))
        print("Metadata updated successfully")
    except Exception as e:
        print(f"Error writing metadata: {e}")
        raise

# Fetch all users from AWS Cognito using pagination
def fetch_all_cognito_users():
    users = []
    try:
        response = cognito_client.list_users(UserPoolId=COGNITO_USER_POOL_ID)
        users.extend(response.get("Users", []))
        while "PaginationToken" in response:
            response = cognito_client.list_users(
                UserPoolId=COGNITO_USER_POOL_ID,
                PaginationToken=response["PaginationToken"]
            )
            users.extend(response.get("Users", []))
        print(f"Total users retrieved: {len(users)}")
        return users
    except Exception as e:
        print(f"Error fetching users from Cognito: {e}")
        raise

# ----------------------------------------------------------------------
# Validating if the number of fields in schema matches expected count
# ----------------------------------------------------------------------
def validate_schema_count(df):
    print("\n=== Schema Count Validation ===")
    actual_field_count = len(df.columns)
    expected_field_count = len(df.first().asDict()) if df.count() > 0 else 0
    result = {
        "expected_field_count": expected_field_count,
        "actual_field_count": actual_field_count,
        "match": actual_field_count == expected_field_count
    }
    return result

# -----------------------------------------------------------
# Validate record counts, uniqueness of username and email
# ------------------------------------------------------------
def perform_count_checks(df, cognito_users_count):
    df_count = df.count()
    distinct_user_count = df.select("Username").distinct().count()
    distinct_email_count = df.select("email").distinct().count()
    return {
        "dataframe_record_count": df_count,
        "cognito_api_record_count": cognito_users_count,
        "distinct_usernames": distinct_user_count,
        "distinct_emails": distinct_email_count,
        "count_match": df_count == cognito_users_count,
        "username_uniqueness": distinct_user_count == df_count,
        "email_uniqueness": distinct_email_count == df_count
    }

# ----------------------------------------------------------------------------------------
# Calculating completeness and uniqueness metrics for email, username, and created date
# -----------------------------------------------------------------------------------------
def calculate_data_quality_metrics(df):
    total_records = df.count()
    completeness = {
        "email_completeness": (1 - (df.filter((col("email").isNull()) | (col("email") == "")).count() / total_records)) * 100,
        "username_completeness": (1 - (df.filter((col("Username").isNull()) | (col("Username") == "")).count() / total_records)) * 100,
        "created_at_completeness": (1 - df.filter(col("CreatedAt").isNull()).count() / total_records) * 100
    }
    uniqueness = {
        "email_uniqueness": (df.select("email").distinct().count() / total_records) * 100,
        "username_uniqueness": (df.select("Username").distinct().count() / total_records) * 100
    }
    return {
        "total_records": total_records,
        "completeness": completeness,
        "uniqueness": uniqueness,
        "timestamp": datetime.now().isoformat()
    }

# --------------------------------------------------------------------------
# Orchestrate all quality checks: schema, count, and metrics
# ---------------------------------------------------------------------------
def perform_data_quality_check(df, cognito_users_count):
    return {
        "schema_validation": validate_schema_count(df),
        "count_validation": perform_count_checks(df, cognito_users_count),
        "data_quality": calculate_data_quality_metrics(df)
    }

# ------------------------------------------------------------------------------
# Determining if any quality check failed and return True
# --------------------------------------------------------------------------------
def has_quality_check_failed(quality_results):
    if not quality_results["schema_validation"]["match"]:
        return True
    if not quality_results["count_validation"]["count_match"]:
        return True
    if not quality_results["count_validation"]["username_uniqueness"]:
        return True
    if not quality_results["count_validation"]["email_uniqueness"]:
        return True
    return False

def main():
    # Initialize Spark session
    spark = SparkSession.builder.appName("CognitoToS3Job").getOrCreate()

    # Read last processed timestamp from metadata file
    last_run_timestamp = read_metadata(bucket_name, metadata_key)
    print(f"Last run timestamp: {last_run_timestamp}")

    # Fetch users from Cognito
    cognito_users = fetch_all_cognito_users()
    cognito_users_count = len(cognito_users)
    if cognito_users_count == 0:
        print("No users found. Exiting.")
        spark.stop()
        return

    # Transforming raw Cognito user objects into dictionaries for DataFrame
    user_data = []
    for user in cognito_users:
        user_dict = {attr['Name']: attr['Value'] for attr in user.get('Attributes', [])}
        user_dict['Username'] = user['Username']
        user_dict['CreatedAt'] = user['UserCreateDate'].isoformat()
        user_dict['LastModifiedAt'] = user['UserLastModifiedDate'].isoformat()
        user_data.append(user_dict)

    # Creating Spark DataFrame with year/week partitioning
    df = spark.createDataFrame(user_data)
    df = df.withColumn("CreatedAt_timestamp", to_timestamp(col("CreatedAt")))
    df = df.withColumn("year", year(col("CreatedAt_timestamp")))
    df = df.withColumn("week", weekofyear(col("CreatedAt_timestamp")))
    df = df.drop("CreatedAt_timestamp")

    print("\nSData with partition columns:")
    df.show(5, truncate=False)

    # Run schema, count, and quality checks
    quality_results = perform_data_quality_check(df, cognito_users_count)
    quality_json = json.dumps(quality_results, indent=2)
    print("\n=== QUALITY CHECK REPORT ===")
    print(quality_json)

    # Save quality check report to S3 
    timestamp = int(time.time())
    validation_path = f"{destination_bucket}users/users_historical_dq_{timestamp}.json"
    (spark.sparkContext
        .parallelize([quality_json])
        .coalesce(1)
        .saveAsTextFile(validation_path))

    #
    # Abort job if any quality check fails (for Step Functions to catch)
    #
    if has_quality_check_failed(quality_results):
        print("Quality check failed.")
        raise Exception("Data quality check failed. Check S3 for the validation report.")

    # -----------------------------------------------------------------------
    # Writing user data to S3 in Parquet format partitioned by year and week
    # ------------------------------------------------------------------------
    (df.coalesce(1)
       .write
       .partitionBy("year", "week")
       .format("parquet")
       .mode("overwrite")
       .save(destination_bucket + "users/"))

    # ---------------------------------------------------------------------
    # Write updated timestamp to metadata file in S3
    # ---------------------------------------------------------------------
    current_timestamp = datetime.now().isoformat()
    write_metadata(bucket_name, metadata_key, current_timestamp)
    print(f"Updated metadata with current timestamp: {current_timestamp}")
    #end spark session
    spark.stop()
    print("Processing completed successfully")

# Run script
if __name__ == "__main__":
    main()
