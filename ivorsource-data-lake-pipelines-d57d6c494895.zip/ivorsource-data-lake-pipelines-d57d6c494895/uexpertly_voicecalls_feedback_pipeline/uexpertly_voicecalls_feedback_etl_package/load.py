from pyspark.sql import DataFrame
from pyspark.sql.functions import year, weekofyear, to_date
from pyspark.sql.functions import col


def write_parquet(df: DataFrame, output_path: str) -> None:
    """
    Write the final DataFrame to the given S3 path partitioned by year and week.
    """
    df = df.filter(col("start_time").isNotNull())
    df = df.withColumn("year", year(to_date(col("start_time")))) \
           .withColumn("week", weekofyear(to_date(col("start_time"))))
    df.write.partitionBy("year", "week").mode("overwrite").parquet(output_path)