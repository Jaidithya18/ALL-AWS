from pyspark.sql import SparkSession, DataFrame
from typing import Dict


def read_voice_call_feedback_table(spark: SparkSession, jdbc_url: str, connection_props: Dict[str, str]) -> DataFrame:
    """
    Read data from public.voice_call_feedback table.
    """
    return spark.read.jdbc(
        url=jdbc_url,
        table="public.voice_call_feedback",
        properties=connection_props
    )


def read_voice_interview_call_table(spark: SparkSession, jdbc_url: str, connection_props: Dict[str, str]) -> DataFrame:
    """
    Read data from public.voice_interview_call table.
    """
    return spark.read.jdbc(
        url=jdbc_url,
        table="public.voice_interview_call",
        properties=connection_props
    )


def read_student_info_table(spark: SparkSession, jdbc_url: str, connection_props: Dict[str, str]) -> DataFrame:
    """
    Read data from public.student_info table.
    """
    return spark.read.jdbc(
        url=jdbc_url,
        table="public.student_info",
        properties=connection_props
    )
