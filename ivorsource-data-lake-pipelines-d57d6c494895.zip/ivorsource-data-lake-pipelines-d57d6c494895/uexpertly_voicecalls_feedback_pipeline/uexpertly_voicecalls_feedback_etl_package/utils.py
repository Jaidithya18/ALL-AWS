import boto3
import json
from typing import Dict

def _extract_user_and_password(secret: Dict[str, str]) -> Dict[str, str]:
    """
    Extract user and password from secret dictionary with fallback for different key names.
    Supports both dev (POSTGRES_USER) and prod (username) formats.
    """
    if "POSTGRES_USER" in secret and "POSTGRES_PASSWORD" in secret:
        print("Using POSTGRES_USER and POSTGRES_PASSWORD from secret.")
        user = secret["POSTGRES_USER"]
        password = secret["POSTGRES_PASSWORD"]
    elif "username" in secret and "password" in secret:
        print("Using username and password from secret.")
        user = secret["username"]
        password = secret["password"]
    else:
        raise ValueError(
            "Secret must contain either POSTGRES_USER/POSTGRES_PASSWORD or username/password."
        )

    return {"user": user, "password": password}



def get_postgres_jdbc_config(params: Dict[str, str], region_name: str = "us-east-2") -> Dict[str, object]:
    """
    Build JDBC URL and connection properties for PostgreSQL dynamically using parameter dict.
    """
    secret_name = params["SECRET_NAME"]

    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])

    creds = _extract_user_and_password(secret)

    jdbc_url = f"jdbc:postgresql://{params['DB_HOST']}:{params['DB_PORT']}/{params['DB_NAME']}"

    return {
        "url": jdbc_url,
        "properties": {
            "user": creds["user"],
            "password": creds["password"],
            "driver": "org.postgresql.Driver"
        }
    }


def get_postgres_creds(secret_name: str, db_host: str, db_port: str, db_name: str, region_name: str = "us-east-1") -> Dict[str, object]:
    """
    Fetch PostgreSQL credentials from AWS Secrets Manager and build JDBC URL using explicit inputs.
    Handles both dev (POSTGRES_USER, POSTGRES_PASSWORD) and prod (username, password) formats.
    """
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    secret = json.loads(response['SecretString'])

    creds = _extract_user_and_password(secret)

    jdbc_url = f"jdbc:postgresql://{db_host}:{db_port}/{db_name}"

    return {
        "url": jdbc_url,
        "properties": {
            "user": creds["user"],
            "password": creds["password"],
            "driver": "org.postgresql.Driver"
        }
    }
