from pyspark.sql import DataFrame
from pyspark.sql.functions import year, weekofyear, to_date, col

def write_parquet_incremental(df: DataFrame, output_path: str) -> None:
    """
    Write only new data to S3, partitioned by year and week, using dynamic partition overwrite.
    """
    df = df.filter(col("start_time").isNotNull())
    df = df.withColumn("year", year(to_date(col("start_time")))) \
           .withColumn("week", weekofyear(to_date(col("start_time"))))
    df.write.partitionBy("year", "week").mode("overwrite").parquet(output_path)
