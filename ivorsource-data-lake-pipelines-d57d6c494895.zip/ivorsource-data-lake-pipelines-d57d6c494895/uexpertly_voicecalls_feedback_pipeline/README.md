# CI/CD-Enabled ETL Pipeline for Voice Call Feedback: PostgreSQL to Amazon S3 Using AWS Glue, Step Functions, and Athena
Built and deployed a production-ready ETL pipeline using AWS Glue, Step Functions, and Athena with Bitbucket CI/CD and dynamic environment support

## Table of Contents
- [Project Overview](#project-overview)
- [Architecture Diagram](#architecture-diagram-explanation)
- [Step-by-Step Implementation](#implementation-steps-and-commands)
- [CI/CD Flow](#why-cicd-in-my-project)
- [Unit Testing and Packaging](#unit-testing-and-automated-packaging-in-cicd)
- [Step Function Execution](#what-happens-when-step-function-is-manually-triggered)
- [Bitbucket Deployment](#what-happens-when-bitbucket-pipeline-is-deployed)
- [Conclusion](#conclusion)

## Project Overview

This project demonstrates a real-time ETL pipeline that extracts data from an AWS RDS PostgreSQL instance, transforms and writes it to Amazon S3 in Parquet format using AWS Glue, registers tables via a Glue Crawler, queries them using Amazon Athena, and orchestrates the entire process using AWS Step Functions with built-in retry and error handling for production readiness.

Note: PostgreSQL and S3 were already created, and I was granted access to both.

---

## Architecture Diagram Explanation – Real-Time ETL Pipeline with AWS Glue and Step Functions
![alt text](images/architecture_diagram.png)

This diagram illustrates a real-time ETL pipeline that extracts data from a PostgreSQL RDS database, transforms it using AWS Glue and PySpark, and stores the results in Amazon S3 in Parquet format. A Glue Crawler registers the data into the Glue Data Catalog, making it queryable via Athena. The pipeline is orchestrated by AWS Step Functions, while Bitbucket Pipelines handles CI/CD — including unit testing, module packaging (as etl_module.zip), S3 uploads, and job updates — ensuring production-ready deployment.


---
 

### 1. **Client**
- The ETL process is **manually triggered** via the AWS CLI using **Step Functions**.
- This allows you to **control when new data** is processed, avoiding unnecessary runs or automation for now.

---

### 2. **Step Function**
- Orchestrates the entire data pipeline.
- Performs the following runtime tasks:
  - Starts the Glue job (`feedback_etl.py`)
  - Waits for it to complete
  - Runs Athena queries to validate the output
  - All steps include retry and error handling logic

---

### 3. **Bitbucket Pipelines (CI/CD Layer)**
- Runs automatically whenever changes are pushed to the repo.
- **Bitbucket pipeline stages:**
  1. **Runs Unit Tests** (e.g. `pytest tests/`) to validate code quality
  2. **Packages your ETL logic** (from `etl_package/etl/`) into `etl_module.zip`
  3. **Uploads artifacts**:
     - `etl_module.zip` to `s3://interview-ai-dev/libs/`
     - `feedback_etl.py` to `s3://interview-ai-dev/scripts/`
  4. **Updates Glue Job** definition with new scripts and dependencies
  5. **Updates Step Function** state machine if needed

---

### 4. **Unit Testing and Modular Packaging**
- Before packaging and deployment, unit tests ensure:
  - Secrets Manager access works as expected
  - JDBC extraction logic returns expected schema
  - S3 writes are handled correctly
- These tests required modularizing ETL logic:
  - Splitting code into `etl/utils.py`, `etl/extract.py`, `etl/load.py`
  - Making `etl/` a package
  - Zipping this package as `etl_module.zip`
  - Appending the ZIP path to `sys.path` in `feedback_etl.py`

---

### 5. **Glue Job (feedback_etl.py)**
- The ETL script is run by AWS Glue, performing:
  - Secure credential retrieval from **Secrets Manager**
  - Reading feedback tables from **PostgreSQL RDS** via JDBC
  - Writing output to **Amazon S3** in Parquet format
  - Using PostgreSQL JDBC driver passed via `--extra-jars`

---

### 6. **Amazon S3**
- Stores:
  - Your ETL script (`feedback_etl.py`)
  - The ZIP package (`etl_module.zip`)
  - Intermediate and final Parquet outputs
  - Athena query results as CSV files

---

### 7. **Glue Crawler**
- Scans the S3 output directory (`/output/`)
- Detects schema and registers tables in the **Glue Data Catalog**

---

### 8. **Glue Data Catalog**
- Holds metadata for the feedback datasets
- Enables Athena to query structured Parquet data without manual schema definition

---

### 9. **Athena**
- Executes pre-defined SQL queries on tables registered by the Glue Crawler
- The Step Function runs these queries automatically as part of the pipeline
- Results are written to S3 under `athena-results/`

---

### 10. **Athena Output (S3)**
- Contains `.csv` results from Athena queries
- Useful for downstream reporting, validation, or audits

---

## Summary of Flow (Left to Right)

| Step | Action |
|------|--------|
| 1 | Bitbucket runs unit tests (`pytest`) on each commit |
| 2 | Bitbucket builds `etl_module.zip` from `etl_package/etl/` |
| 3 | Bitbucket uploads ZIP and ETL script to S3 |
| 4 | Bitbucket updates Glue Job and Step Function using AWS CLI |
| 5 | Client manually triggers the Step Function |
| 6 | Step Function starts Glue Job |
| 7 | Glue fetches secrets and loads JDBC JAR |
| 8 | Glue reads data from PostgreSQL and writes Parquet to S3 |
| 9 | Glue Crawler scans output path and registers tables |
|10 | Step Function runs Athena queries |
|11 | Athena saves query results to S3 (`athena-results/`) |

---



## Notes for Documentation

- The Glue job uses `spark.read.jdbc()` inside the PySpark script to connect directly to the PostgreSQL RDS instance.
- Therefore, **no AWS Glue Connection is needed**. JDBC connectivity is established programmatically using:
  - The PostgreSQL JDBC driver (`postgresql-42.7.5.jar`) passed via `--extra-jars`
  - Database credentials securely fetched from **AWS Secrets Manager**

- The RDS database used here is **temporarily configured as publicly accessible** for development purposes. This allows Glue to connect **without requiring a VPC configuration or subnet routing**.

- Similarly, Amazon S3 is also accessed publicly, so there's **no need for an S3 VPC endpoint** in this setup.

> In production, it's recommended to:
> - Move Glue into a private VPC
> - Disable public access to RDS
> - Configure VPC endpoints for S3 and Secrets Manager

---


## AWS Services Used

- AWS Glue (Job + Crawler)
- Amazon RDS (PostgreSQL)
- Amazon S3
- AWS Secrets Manager
- Amazon Athena
- AWS Step Functions
- AWS CLI (PowerShell)

## Implementation Steps and Commands
### Step 1: Launch PostgreSQL RDS Instance
- Created PostgreSQL database and loaded feedback data(I received access to already created rds with feedback data)


- Data stored in Postgres

- Stored DB credentials securely in **AWS Secrets Manager**


---

### Step 2: Create PySpark Script and JDBC JAR, Upload to S3

-  Wrote the PySpark ETL script: `feedback_etl.py`

-  Used `spark.read.jdbc()` to read from RDS
-  Retrieved credentials securely from **Secrets Manager**
-  Used PostgreSQL JDBC driver `postgresql-42.7.5.jar` (uploaded manually to S3)


### Key Changes: 
- Reads output paths from environment variables:
  - `FEEDBACK_OUTPUT_PATH`
  - `METADATA_OUTPUT_PATH`
- Supports `.env` loading using `dotenv` for local testing
- Uses `SECRET_NAME` as a dynamic input (default is `voicecall/postgres-creds`)
- Raises an error if any required path is missing



Files uploaded to S3:
- `s3://interview-ai-dev/scripts/feedback_etl.py`
- `s3://interview-ai-dev/jars/postgresql-42.7.5.jar`


---
### Step 3: Create AWS Glue Job to extract from PostgreSQL and write to S3

Used to extract from RDS and write to S3 in Parquet format.

```powershell
aws glue create-job `
  --name voicecall-feedback-extract `
  --role vinutha_glue_job `
  --command '{"Name":"glueetl","ScriptLocation":"s3://interview-ai-dev/scripts/feedback_etl.py","PythonVersion":"3"}' `
  --default-arguments '{
    "--TempDir":"s3://interview-ai-dev/temp/",
    "--extra-py-files":"s3://interview-ai-dev/jars/postgresql-42.7.5.jar"
  }' `
  --glue-version "4.0" `
  --region us-east-2
```


### Step 4: Run Glue Job & Verify Output in S3
- Ran Glue job

- Confirmed Parquet files in `s3://interview-ai-dev/output/`

### Step 5: Create Glue Database

- Created a Glue database named `voicecall_feedback_db`  
- Used it to store metadata from the crawler (e.g., tables: `voice_call_feedback`, `voice_call_feedback_metadata`)  
- This database acts as the foundation for Athena queries  


### Step 6: Create Glue Crawler to register Parquet files to Glue Catalog

- Created crawler targeting S3 path
- Stored metadata in `voicecall_feedback_db`

```powershell
aws glue create-crawler `
  --name voicecall-feedback-crawler `
  --role vinutha_glue_job `
  --database-name voicecall_feedback_db `
  --targets '{"S3Targets": [{"Path": "s3://interview-ai-dev/output/"}]}' `
  --region us-east-2
```

**Start the crawler:**
```powershell
aws glue start-crawler --name voicecall-feedback-crawler --region us-east-2
```

**Check crawler status:**
```powershell
aws glue get-crawler `
  --name voicecall-feedback-crawler `
  --query 'Crawler.State' `
  --region us-east-2
```

**List tables created:**
```powershell
aws glue get-tables `
  --database-name voicecall_feedback_db `
  --query 'TableList[*].Name' `
  --region us-east-2
```


### Step 7: Query Data Using Athena(via Step Functions)

- Queried both `voice_call_feedback` and `voice_call_feedback_metadata` tables using simple SQL queries  
- Verified that Athena could read Parquet files registered by the Glue Crawler  
- Configured Athena to store query results in the S3 path: `s3://interview-ai-dev/athena-results/`

Athena queries were executed from the Step Function, no manual SQL run was required. But verified using:

```sql
SELECT * FROM voice_call_feedback LIMIT 10;
SELECT * FROM voice_call_feedback_metadata LIMIT 10;
```



- S3 browser showing Athena output files in the `athena-results/` folder
![alt text](images/athena_results.png)

---

### Step 8: IAM Role for Step Functions

Updated trust policy for Glue + Step Functions.
same role for both glue and step function 
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": [
          "glue.amazonaws.com",
          "states.amazonaws.com"
        ]
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

Attached Policies:

- AWSGlueConsoleFullAccess
- AmazonAthenaFullAccess
- AmazonS3FullAccess


### Step 9: Create Step Function

**State machine definition file:** `step-function-etl.json`

- Created state machine via `step-function-etl.json`
- Steps:
  1. Start Glue Job
  2. Query `voice_call_feedback`
  3. Query `voice_call_feedback_metadata`


##### Create command:
```powershell
aws stepfunctions create-state-machine `
  --name vinutha-etl-step-function `
  --definition file://step-function-etl.json `
  --role-arn arn:aws:iam::<account-id>:role/vinutha_glue_job `
  --type STANDARD
```

**Update command after edits:**

```powershell
aws stepfunctions update-state-machine `
  --state-machine-arn arn:aws:states:us-east-2:<account-id>:stateMachine:vinutha-etl-step-function `
  --definition file://step-function-etl.json
```

**Start execution:**

```powershell
aws stepfunctions start-execution `
  --state-machine-arn arn:aws:states:us-east-2:<account-id>:stateMachine:vinutha-etl-step-function `
  --name run-$(date +%Y%m%d%H%M%S)
```
![alt text](images/step_function_graphview.png)


### Step 10: Retry and Error Handling in Step Functions
- Used `Retry` and `Catch` blocks for all task states
- Created `Handle Failure` fallback state

Defined in JSON:

```json
"Retry": [
  {
    "ErrorEquals": ["States.ALL"],
    "IntervalSeconds": 5,
    "MaxAttempts": 2,
    "BackoffRate": 2.0
  }
],
"Catch": [
  {
    "ErrorEquals": ["States.ALL"],
    "Next": "Handle Failure"
  }
]
```

**`Handle Failure` State:**
```json
"Handle Failure": {
  "Type": "Fail",
  "Error": "StepFunctionFailed",
  "Cause": "Task failed after retry"
}
```
![alt text](images/retry_and_error_handling.png)

- Failed execution showing 3 retries + transition to `Handle Failure`

## S3 and RDS Architecture

- RDS was publicly accessible, so Glue job was created **without VPC or S3 endpoint**
- Glue job connected to RDS using Secrets Manager and jdbc
- JDBC driver was manually provided in `--extra-jars`
- S3 is public by default, so no VPC endpoint was needed

> Note: This Glue job does not use a VPC connection. The RDS instance is temporarily public for development/testing. In production, this should be secured by:
>
> - Running Glue inside a VPC
> - Disabling RDS public access
> - Adding an S3 VPC endpoint

Sure, here's the version without emojis and emojis removed from section titles:

---
# Why CICD in my project?
**Why using CI/CD pipelines like Bitbucket Pipelines still matters even when you already have AWS Step Functions to manually invoke your ETL jobs**

**AWS Step Functions**  
Step Functions is great for orchestration.  
You can manually trigger the workflow or use EventBridge to schedule it.  
It controls the runtime flow of your jobs: Glue → Wait → Athena → etc.  

But you’re still doing this after your code (Glue script, Step Function definition, etc.) is deployed.

**Bitbucket CI/CD Pipeline**  
CI/CD comes into play before you run the Step Function. It's all about automating the deployment of your code and infrastructure.

**Why use CI/CD?**

**Automatic Deployment**  
Whenever you push updated code (like changes to your Glue script or Step Function definition), Bitbucket can:  
- Upload your PySpark script to S3  
- Update the Glue Job to point to the new script  
- Update the Step Function definition if needed  

**Version Control**  
Your ETL code, infrastructure definitions (like Step Function JSON), and even tests are version-controlled.  
- No manual copy-pasting  
- Rollback to previous versions is easy  

**Testing Before Deployment**  
Bitbucket can run linting, unit tests, or validation (e.g., check if your Step Function JSON is valid) before deploying anything to AWS.

**Consistency and Speed**  
No human errors. Everyone follows the same deployment process. One click (or just a `git push`) leads to full deployment.

**Audit Trail and Approvals**  
You know who deployed what and when. You can add manual approvals before production deployment.

**Summary**

| Feature                             | Step Functions | Bitbucket CI/CD |
|-------------------------------------|----------------|------------------|
| Automates job execution             | Yes            | No               |
| Automates code deployment           | No             | Yes              |
| Triggered manually/scheduled        | Yes            | Yes              |
| Good for orchestration              | Yes            | No               |
| Good for maintaining deployment     | No             | Yes              |

**Think of it like this**  
CI/CD = getting the latest car design into the factory  
Step Functions = the assembly line that runs the car-building process  

Both are important — CI/CD gets your changes into the system reliably, Step Functions runs them.

---
## Unit Testing and Automated Packaging in CI/CD

To ensure production-readiness and reliability, I added the following enhancements to the CI/CD pipeline:

---

### 1. Unit Testing Support

To validate the core logic of my ETL modules (`etl/utils.py`, `etl/extract.py`, `etl/load.py`), I implemented unit tests inside a `tests/` directory using **Pytest**.

#### Key Features:
- Tests the Secrets Manager logic with mocks
- Tests S3 Parquet write functionality (mocked)
- Ensures JDBC extraction functions return expected schema

#### Folder Structure:
```
/tests
  ├── test_utils.py
  ├── test_extract.py
  └── test_load.py
```

#### Command Used (in Bitbucket Pipeline):
```bash
export PYTHONPATH=.
pytest tests/
```
- CI pipeline automatically runs these tests before any deployment.

---

### 2. Automated ZIP Creation (etl_module.zip)
#### Packaging etl/ into etl_module.zip
I automated the packaging of the etl/ folder (located inside etl_package/) into a correctly structured etl_module.zip, which is passed to AWS Glue using --extra-py-files.
###### Why This Was Important
- AWS Glue does not unzip --extra-py-files. It directly adds the .zip to PYTHONPATH, so your script must explicitly include:
```
import sys
sys.path.append('/tmp/etl_module.zip')
```
#### Problem Solved:
- Glue failed with `ModuleNotFoundError: No module named 'etl'`
- This was due to incorrect ZIP structure from PowerShell
- PowerShell Compress-Archive created invalid zips (missing top-level etl/)

#### Solution:
Created a Python script `build_zip.py` that:
- Recursively packages the etl/ folder (from etl_package/) as a subfolder inside etl_module.zip
- Ensures ZIP is correctly recognized by Glue
- Uploads `etl_module.zip` to S3 using AWS CLI

```python
# scripts/build_zip.py (simplified)
import zipfile, os

with zipfile.ZipFile("etl_module.zip", "w") as zipf:
    for root, dirs, files in os.walk("etl_package/etl"):
        for file in files:
            full_path = os.path.join(root, file)
            arcname = os.path.relpath(full_path, "etl_package")
            zipf.write(full_path, arcname)
```

#### Result:
```
etl_module.zip
└── etl/
    ├── __init__.py
    ├── utils.py
    ├── extract.py
    └── load.py
```
![alt text](images/unit_testing.png)

---

## Staging and Packaging: `etl_module.zip`

- Temporary folder used for ZIP creation

- Not needed after the zip is created

- To ensure that the AWS Glue job can import the custom `etl` module, we **package it as a `.zip` file** using a **clean staging process**. This step is critical to avoid:

```
ModuleNotFoundError: No module named 'etl'
```

### Why Staging Is Required

Glue expects `--extra-py-files` to either:
- Contain `.py` files directly
- Or be a `.zip` file that **preserves the directory structure**, like:
  ```
  etl_module.zip
  └── etl/
      ├── __init__.py
      ├── utils.py
      ├── extract.py
      └── load.py
  ```

Some tools like PowerShell’s `Compress-Archive` flatten or corrupt this structure. To avoid that, we create a **staging directory first** before zipping.

---

### Packaging Steps (Manually or via CI/CD)

#### Step 1: Create Staging Directory
```powershell
mkdir etl_zip_temp\etl
Copy-Item -Recurse .\etl_package\etl\* .\etl_zip_temp\etl\
```

#### Step 2: Create ZIP Archive Using Python (Recommended)
```python
# build_zip.py
import os
import zipfile

zip_path = "etl_module.zip"
source_dir = "etl_zip_temp"

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, _, files in os.walk(source_dir):
        for file in files:
            full_path = os.path.join(root, file)
            arcname = os.path.relpath(full_path, start=source_dir)
            zipf.write(full_path, arcname)
```

> Result: The `etl_module.zip` will contain the correct `etl/` package structure.

---

###  Zip Staging in CI/CD Pipeline

In the **Bitbucket pipeline**, this zip creation is automated before deployment:

```yaml
- step:
    name: Package ETL Module
    script:
      - mkdir -p etl_zip_temp/etl
      - cp -r etl_package/etl/* etl_zip_temp/etl/
      - python scripts/build_zip.py
      - aws s3 cp etl_module.zip s3://interview-ai-dev/libs/etl_module.zip
```

---

### Lessons Learned

- Glue **does not unzip** the file — it appends the ZIP to `sys.path`.
- If the folder structure inside the ZIP isn’t right (e.g., missing top-level `etl/`), `import` will fail.
- **Always test ZIP contents with:**  
  ```bash
  tar -tf etl_module.zip
  ```

---

## Fixing ModuleNotFoundError in Glue Jobs

### What AWS Glue Actually Does with `--extra-py-files`

When you use the `--extra-py-files` argument in an AWS Glue job like this:

```bash
--extra-py-files s3://interview-ai-dev/libs/etl_module.zip
```

Glue **does not unzip** the provided file.

Instead, Glue simply adds the path to the zip file (e.g., `/tmp/etl_module.zip`) to Python’s `sys.path`. Python is then expected to import modules **directly from within the zip file**.

### Why This Caused an Error

Without manually adding `/tmp/etl_module.zip` to Python’s module search path, the runtime has no way to locate your zipped package. This resulted in the following runtime error:

```
ModuleNotFoundError: No module named 'etl'
```

Even though:

- The `etl/` package was correctly zipped and uploaded to S3
- The job included `--extra-py-files`
- The Glue job was otherwise configured correctly

Glue did not extract the zip — so Python had no visibility into its contents.

### The Fix: Manually Append the Zip to `sys.path`

To resolve this, we explicitly told Python to load the zip file by adding this line at the beginning of `feedback_etl.py`:

```python
import sys
sys.path.append('/tmp/etl_module.zip')
```

This allows Python to locate and import the `etl` package correctly from inside the zip.

After this fix, imports like the following worked as expected:

```python
from etl.utils import get_postgres_creds
```

### Summary for Future Reference

If your AWS Glue job uses zipped Python packages:

- Ensure the zip structure contains the actual `etl/` folder (not just flat `.py` files)
- Add `/tmp/<your_zip_file>.zip` to `sys.path` in your Glue script
- Do not expect Glue to unzip the file — it won’t

This fix is essential for any modular Python project running on AWS Glue.

### 3. CI/CD Integration for Deployment

My updated `bitbucket-pipelines.yml` does the following:

- Installs test dependencies
- Runs unit tests
- Builds `etl_module.zip` using `scripts/build_zip.py`
- Uploads `feedback_etl.py` and `etl_module.zip` to S3
- Calls `aws glue update-job` to apply changes
- Optionally triggers the Step Function execution



---
# keep the ZIP script for reuse:

```powershell
mkdir scripts
Move-Item .\build_zip.py .\scripts\
```

---
## Why I Added Unit Testing (and How It Influenced My Project Structure)

### Why Unit Testing Was Important

Adding unit tests helped ensure that my ETL logic is reliable, testable, and production-ready before deploying it into AWS Glue.

Unit testing allowed me to:

- Validate Secrets Manager access without hitting AWS (using mocks)
- Test data extraction logic from PostgreSQL using mock JDBC functions
- Verify data loading functions write correct Parquet files (mocked S3)
- Catch edge cases or regressions early before shipping code to production

---


### Summary of Flow Triggered by Unit Testing

Adding unit tests led to a chain of design decisions:

```text
Want unit tests
   ↓
Must split logic into modules (etl/utils.py, extract.py, load.py)
   ↓
Must import those modules inside feedback_etl.py
   ↓
Must make them accessible to AWS Glue
   ↓
Must package them as etl_module.zip with top-level etl/
   ↓
Must upload to S3 and pass via --extra-py-files
   ↓
Must add sys.path.append('/tmp/etl_module.zip') in feedback_etl.py
```

---

### Why It Was Worth It

Although it added complexity, this setup made my project:

- Modular and reusable  
- Testable and production-ready  
- Compatible with CI/CD workflows  
- Easy to debug and maintain

It reflects industry best practices and gives confidence that the Glue job will behave as expected.

---

## What Happens When Step Function is Manually Triggered

When you manually start the Step Function using:

```bash
aws stepfunctions start-execution \
  --state-machine-arn arn:aws:states:us-east-2:<account-id>:stateMachine:vinutha-etl-step-function \
  --name run-$(date +%Y%m%d%H%M%S)
```

The following sequence occurs:

| Step | Action |
|------|--------|
| 1    | Step Function starts execution |
| 2    | AWS Glue job (`feedback_etl.py`) runs using the **current version** of the script and ZIP stored in S3 |
| 3    | Glue connects to PostgreSQL, extracts data, writes to S3 in Parquet |
| 4    | Glue job finishes, triggering Athena queries inside Step Function |
| 5    | Athena queries both feedback tables and stores results in `s3://interview-ai-dev/athena-results/` |
| 6    | Execution completes or handles failure with retry/fallback logic |

> **Note:** This does not update code or redeploy anything. It simply executes the latest deployed code from S3.

---

## CI/CD Deployment Flow (Bitbucket)

When you push changes to Bitbucket (like updating the ETL logic, fixing a bug, or modifying the Step Function), the **Bitbucket CI/CD pipeline** does the following:

| Step | Action |
|------|--------|
| 1    | Installs dependencies (`pytest`, `boto3`, etc.) |
| 2    | Runs all unit tests in the `tests/` folder |
| 3    | Packages the `etl_package/etl/` folder into `etl_module.zip` using `scripts/build_zip.py` |
| 4    | Uploads the latest `etl_module.zip` to S3: `s3://interview-ai-dev/libs/etl_module.zip` |
| 5    | Uploads the updated `feedback_etl.py` script to: `s3://interview-ai-dev/scripts/feedback_etl.py` |
| 6    | Calls `aws glue update-job` with `job-update.json` to update the Glue job config (so it uses the new ZIP/script) |
| 7    | Updates the Step Function definition if changes were made to `step-function-etl.json` |
| 8    | (Optional) Starts Step Function execution — you can comment this out if you prefer manual runs |

> **This step updates your AWS environment with new logic and structure.** The next time you run the Step Function, it will use the updated Glue script and module.

---

### Summary Table

| Action                      | Step Function | Bitbucket CI/CD |
|-----------------------------|----------------|------------------|
| Starts Glue job             | Yes         | No            |
| Executes Athena query       | Yes         | No            |
| Updates Glue script         | No          | Yes           |
| Creates etl_module.zip      | No          | Yes           |
| Uploads ZIP to S3           | No          | Yes           |
| Updates Glue job config     | No          | Yes           |
| Updates Step Function       | No          | Yes (if changed) |
| Triggers Step Function run  | Manual      | Optional       |

---

### From Bitbucket Pipelines  
Just push your code to the `main` or `dev` branch — it will:

- Run unit tests
- Package your PySpark code
- Upload `feedback_etl.py` and `etl_module.zip` to S3
- Generate and apply updated Glue and Step Function definitions

---

### From your local PowerShell terminal  


```powershell
# Step 1: Navigate to project root if not already there
cd C:\Users\vinut\OneDrive\Desktop\repos\cicd-pipeline_voice-call-feedback

# Step 2: Set environment variables (if not using AWS CLI default profile)
$env:AWS_ACCESS_KEY_ID = "your-access-key"
$env:AWS_SECRET_ACCESS_KEY = "your-secret"
$env:AWS_DEFAULT_REGION = "us-east-2"
$env:STEP_FUNCTION_ARN = "arn:aws:states:us-east-2:975050215376:stateMachine:vinutha-etl-step-function"

# Step 3: Install required Python packages (only once)
pip install boto3 pyspark python-dotenv

# Step 4: Build your PySpark zip package
python scripts/build_zip.py

# Step 5: Generate all required config files
python scripts/job-update.py
python scripts/full-job-update.py
python scripts/glue-job-input.py
python scripts/generate_step_function.py

# Step 6: Upload files to S3
aws s3 cp feedback_etl.py s3://interview-ai-dev/scripts/feedback_etl.py
aws s3 cp etl_module.zip s3://interview-ai-dev/libs/etl_module.zip

# Step 7: Update Glue Job
aws glue update-job `
  --job-name voicecall-feedback-extract `
  --job-update file://job-update.json `
  --region us-east-2

# Step 8: Update Step Function definition
aws stepfunctions update-state-machine `
  --state-machine-arn $env:STEP_FUNCTION_ARN `
  --definition file://step-function-etl.json

# Step 9: Start Step Function execution
aws stepfunctions start-execution `
  --state-machine-arn $env:STEP_FUNCTION_ARN `
  --name local-run-$(Get-Date -Format "yyyyMMddHHmmss")
```

---


## Final Outcome

Your project is now:
- Parameterized and secure
- Running ETL jobs via CI/CD
- Step Functions fully orchestrated
- Logs visible via CloudWatch
- Deployable with a single script or Bitbucket push




## Testing Summary
- Ran PySpark-based ETL with AWS Glue, Verified Glue ETL job output to S3

- Packaged dependencies into a deployable zip

- Deployed & triggered via AWS Step Functions

- Queried results using Amazon Athena

- Fully managed with .env, CLI scripts, and Bitbucket Pipelines
- Tested Step Function with success and simulated failure
- Confirmed retry logic and failure handler

## Conclusion

This project demonstrates a fault-tolerant real-time ETL pipeline using AWS-native services and CI/CD automation via Bitbucket. It emphasizes secure credential handling, scalable orchestration, and production-ready retries and failure handling.


---------------------------

## UExpertly_Voicecalla_Feedback_Pipeline - Documentation Q&A (UE-324)

#### 1. What is your branching strategy?

We use a structured, multi-branch strategy in Bitbucket to manage development and deployment effectively.

- The   `main` (or `master`)   branch holds production-ready code. Only stable and fully tested features are merged into this branch.

- The   `dev`   branch is used for ongoing development. It serves as the integration point for all tested and reviewed feature work before anything is pushed to `main`.

-   Feature branches   are created from `dev` for each new task or JIRA ticket (e.g., `UE-312`). These branches are used by individual developers to work on new features or changes. Once the work is complete and tested locally, the developer raises a   Pull Request (PR)   to merge the changes back into `dev`.

- When a PR is created, it automatically triggers a   CI build   and goes through a   code review process  , either by teammates or using automated tools like SonarQube or ChatGPT. The PR is only approved and merged if the build is successful and the code review passes.

This approach helps us maintain clean, stable code in production while allowing multiple developers to work in parallel without conflicts.

#### 2. What is your deployment process?

Our deployment process is   automated, CI/CD-driven, and environment-aware  , enabling seamless transitions from development to production with minimal manual steps.

#### Step 1: Initiating the Deployment Cycle  
Developers begin by pushing code changes to their respective   feature branches  . Once ready, a   Pull Request (PR)   is raised to merge these changes into the `dev` branch, initiating the CI/CD workflow.

#### Step 2: CI/CD Pipeline Execution  
  Bitbucket Pipelines   is triggered automatically. It handles:  
- Code review (by teammates or tools like ChatGPT or SonarQube)  
- Unit and integration tests  
- Packaging of build artifacts, scripts, and configurations

#### Step 3: Automated Deployment to Development Environment  
Once the build passes, the pipeline automatically deploys to the development environment by:
- Uploading scripts to   Amazon S3    
- Updating the   AWS Glue Job   and   Step Function    
- Triggering a Step Function execution to validate the ETL process  
Any required schema changes are applied via version-controlled migration scripts.

#### Step 4: Approval and Promotion to Release  
After successful validation in the development environment, deployment to the production environment is gated behind manual approval. A merge to the main branch or a dedicated release branch triggers the production deployment process.

#### Step 5: Production Rollout  
Merging into the `main` branch triggers the   production deployment  , ensuring consistency with prior environments.   Rollback support   is available via Bitbucket’s commit history and version tracking.

#### Step 6: Post-Deployment Validation and Communication  
Monitoring is performed using tools like   Amazon CloudWatch   to track logs, ETL status, and alerts. Logs are reviewed, and stakeholders are notified about deployment success or failures.

#### 3. What is a CI/CD pipeline?

A CI/CD pipeline is an automated process that manages code integration (CI) and delivery/deployment (CD). It ensures our Glue jobs and orchestration logic are built, tested, and deployed to AWS in a repeatable and reliable way using Bitbucket Pipelines.

#### 4. What is your release cadence?
Development Environment: Deployments occur automatically on every commit via CI/CD. This allows for continuous testing and validation of changes during development.

Production Environment: We follow a weekly release cadence. Once features are tested and reviewed in the development environment, they are promoted to production on a weekly basis after approval.

#### 5. Are we using Kanban or Scrum methodology?
We use the Scrum methodology, which involves working in time-boxed sprints. Each sprint includes planning, daily stand-ups, development, reviews, and retrospectives. All tasks, progress, and sprint goals are tracked in JIRA.

#### 6. Are you building streaming or batch pipelines?

This project is a batch pipeline designed for historical data processing.

#### 7. Are you building data pipelines in real-time or near real-time?

The current pipeline is not real-time. It is a historical batch pipeline that loads full data from the source. Future versions may support incremental or near real-time processing.

#### 8. What is incremental vs historical?

- Historical: Loads all available data for initial backfill.

- Incremental: Loads only newly changed data (e.g., new or updated records)
#### 9. What is Change Data Capture (CDC)? What are the different ways of doing it?

CDC refers to tracking and processing only the changed data. Our project doesn’t implement CDC because it's a full historical load. 
 ##### CDC methods:

- Timestamp-based (e.g., using updated_at)

- Log-based (e.g., PostgreSQL WAL with Debezium)

- Trigger-based

- Snapshot comparison
#### 10. What are the different datasets?

We process the following PostgreSQL tables:

- interview_call

- feedback

- student_info

#### 11. What is the size of your datasets?
The total size of our historical load (based on current PostgreSQL table sizes) is approximately:

student_info: 72 KB

voice_interview_call: 232 KB

voice_call_feedback: 672 KB

Total: ~976 KB, expected to grow with future data ingestion.

#### 12. What is your source system?

Our source is a PostgreSQL RDS database.

Yes, you're absolutely right, Vinutha — your system also includes:

-   PostgreSQL (RDS)   as the source system  
-   AWS Glue Crawlers   to catalog the data after it's written to S3  

### 13. What is your system?

Our data pipeline system consists of the following AWS and supporting components:

-   PostgreSQL (Amazon RDS)   – Source database storing voice_call_feedback
voice_interview_call
student_info information  
-   AWS Glue   – Serverless ETL service used to extract data from PostgreSQL, transform it using PySpark, and load it into S3  
-   Amazon S3   – Object storage used to store the transformed data in Parquet format  
-   AWS Glue Crawlers   – Automatically scan the output data in S3 and catalog it in the Glue Data Catalog  
-   Amazon Athena   – Used to run SQL queries on the processed data stored in S3  
-   AWS Step Functions   – Orchestrates the pipeline by coordinating Glue job execution and error handling  
-   Bitbucket Pipelines   – Manages CI/CD for deployment and versioning of the pipeline code and configuration  

#### 14. What is the output or input file format?

Input: PostgreSQL relational tables

Output: Parquet format stored in S3

### 15. Why did you choose your target or source file format?

We chose   Parquet   as our target file format because it is well-suited for analytics workloads and integrates seamlessly with our AWS-based architecture. The key reasons include:

-   Columnar format  : Enables faster querying, especially when only a subset of columns is needed. This significantly improves performance in tools like   Amazon Athena  .

-   Efficient compression  : Parquet uses advanced encoding and compression techniques, which reduce storage costs and improve I/O performance when reading from S3.

-   Native support in AWS services  : Services like   Athena  ,   Glue Crawlers  , and   Redshift Spectrum   natively support Parquet, making integration smooth and eliminating the need for data conversion.

This makes Parquet the ideal choice for scalable, cost-effective, and high-performance data processing in our pipeline.

### 16. Who are your dataset consumers?

At the moment, there are   no active consumers   of the dataset, as the pipeline is in its initial deployment phase. However, in the future, the primary consumers will include:

-   Data Analysts   – To build reports and dashboards focused on user activity, call feedback quality, and engagement metrics  
-   Data Scientists   – To use the structured feedback data for modeling user behavior, sentiment analysis, or predictive analytics  
-   Business Stakeholders   – To gain insights into user experience and performance trends, helping drive data-informed decisions across teams

### 17. What technologies are you using?

Our project leverages a range of AWS and DevOps technologies to build a modular, CI/CD-enabled ETL pipeline:

-   PostgreSQL (Amazon RDS)   – Source system storing `student_info`, `voice_interview_call`, and `voice_call_feedback` tables  
-   AWS Glue (PySpark)   – Used for extract, transform, and load (ETL) logic written in PySpark  
-   Amazon S3   – Target storage for transformed data in Parquet format  
-   AWS Glue Crawlers   – Automatically catalog transformed data in the Glue Data Catalog for Athena access  
-   Amazon Athena   – Enables interactive querying of Parquet data stored in S3 using standard SQL  
-   AWS Step Functions   – Orchestrates the entire ETL process, including retries and error handling  
-   Bitbucket Pipelines   – CI/CD tool used for automated deployment of ETL scripts, configuration files, and Step Functions  
-   AWS Secrets Manager   – Secure storage and retrieval of sensitive credentials such as PostgreSQL access credentials  
-   Python (.env + dotenv)   – Local development and configuration management  
-   CloudWatch   – Monitoring and logging of AWS Glue job and Step Function executions  

These technologies together support a production-grade, scalable, and modular data pipeline for historical voice call feedback processing.


### 18. What is the business use case of your data pipeline?

The primary business use case of our data pipeline is to   extract and process structured voice call feedback data from PostgreSQL and load it into Amazon S3  , enabling downstream analytics.

Once the data is processed and stored in a queryable format (Parquet), it can be used to:

-   Analyze voice call feedback submitted
-   Correlate call feedback with interview metadata   (e.g., call duration, participants, status)  
-   Generate actionable insights   on interview quality, student engagement, and overall communication effectiveness

These insights will help the business   optimize training programs  ,   improve interviewer performance  , and   enhance the quality of interview experiences  .

#### 19. Where do you store your secrets or keys?

Secrets such as PostgreSQL credentials are stored in AWS Secrets Manager.

#### 20. How do you retrieve your secrets or keys?

Secrets are retrieved within the Glue job using boto3 to access AWS Secrets Manager. The credentials are parsed and passed into JDBC read operations.

#### 21. What is the frequency of your pipeline? Why did you decide on that frequency?

The current pipeline is triggered manually for historical load. Frequency will be adjusted when we implement incremental logic based on data availability and consumer requirements.

### 22. How do you troubleshoot your data pipeline when it fails?

When the pipeline fails, we follow a structured troubleshooting approach to quickly identify and resolve issues:

-   Review AWS Glue job logs   in   Amazon CloudWatch   to trace the error message, identify the failed transformation step, and check for data or schema mismatches.
-   Check the Step Function execution flow   to locate which step failed, view retry attempts, and examine the error payload for more details.
-   Run validation queries in Amazon Athena   on the S3 output to verify partial or incorrect data loads, check data consistency, and compare with expected results.

This layered approach helps isolate the problem — whether it's in the ETL logic, orchestration, or output — and ensures quick recovery or rollback if needed.

### 23. What is your data pipeline's architecture?

Our data pipeline follows    batch-processing architecture   designed for modularity, automation, and scalability. The key components are:

-   Extract  : Data is extracted from   PostgreSQL (RDS)   using JDBC within an AWS Glue job.  
-   Transform  : The data is cleaned, joined, and transformed using   PySpark   in AWS Glue.  
-   Load  : Processed data is written to   Amazon S3   in   Parquet format   for efficient storage and downstream analytics.  
-   Catalog  : A   Glue Crawler   registers the S3 data in the   AWS Glue Data Catalog  .  
-   Query  : The output is queried using   Amazon Athena   for validation and analysis.  
-   Orchestrate  : The entire workflow is coordinated using   AWS Step Functions  , with built-in retry and failure handling logic.  
-   Deploy  : All deployment steps are automated using   Bitbucket Pipelines   as part of our CI/CD process.

This batch-driven architecture enables reproducible historical data processing with consistent deployment and monitoring.

#### 24. Why are you using Glue instead of EMR?

Glue is serverless, easier to manage, and more cost-effective for our batch ETL use case. EMR is better suited for large-scale custom Spark clusters or streaming ML workloads.

### 25. What is the difference between Data Lake and Lakehouse?

-   Data Lake  : A data lake is a centralized repository that stores   raw, semi-structured, or unstructured data   (e.g., logs, JSON, Parquet) in a scalable storage system like   Amazon S3  . It uses a   schema-on-read   approach, meaning the data is interpreted at query time rather than when it's written.

-   Lakehouse  : A lakehouse combines the   scalability of a data lake   with the   data management features of a data warehouse  . It adds   schema enforcement, ACID transactions, and native query support   on top of the data lake. Tools like   AWS Glue Data Catalog  ,   Athena  , and   Redshift Spectrum   help transform a traditional data lake into a lakehouse by enabling structured querying and governance.

#### In our project:
- S3 acts as the   data lake  , storing transformed feedback data in Parquet format.
-   Glue Catalog + Athena   make it a   lakehouse  , allowing structured SQL queries and metadata management.

### 26. What is the business problem you are trying to solve?

The goal is to   extract, transform, and load voice call feedback data   from tables such as `student_info`, `voice_interview_call`, and `voice_call_feedback` to generate actionable insights. These insights help the organization:

- Improve   interviewer performance    
- Enhance   training outcomes    
- Measure   communication quality    
- Identify   coaching opportunities  

Ultimately, the pipeline supports better decision-making around the interview process and helps optimize the overall student experience.

#### 27. What is your target system?
The processed data is loaded into:

Amazon S3 – Stored in Parquet format for efficient storage, compression, and optimized analytics.

Amazon Athena – Provides SQL-based access to the data directly from S3, enabling fast querying without moving data.

#### 28. How do you ensure that you only read the latest changes from the source system?
Currently, we perform a full historical load from the PostgreSQL source.

In future incremental versions, we plan to implement timestamp-based filtering using fields like updated_at to extract only newly inserted or modified records, enabling efficient incremental loads.

#### 29. What is your team size?
Our team consists of 21 members in total

#### 30. In which format is transaction data being stored in S3?
All transaction data is stored in Parquet format under the target/ folder of the respective project path in Amazon S3. We follow a flat folder structure without nested subfolders, in line with team conventions for consistency and ease of access.

#### 31. Who are your stakeholders?

Our key stakeholders include:

-   Data Analysts   – who rely on the processed data to create reports and dashboards  
-   Data Scientists   – who use the data for modeling, pattern analysis, and building predictive insights  
-   UExpertly Management   – who oversee strategic decisions and data-driven outcomes  
-   Business Teams   – who depend on insights from the data to improve operational processes and student engagement
