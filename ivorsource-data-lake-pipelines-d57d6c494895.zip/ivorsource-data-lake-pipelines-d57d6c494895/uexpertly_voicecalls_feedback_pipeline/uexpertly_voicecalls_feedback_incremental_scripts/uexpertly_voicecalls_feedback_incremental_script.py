import sys
import os
import json
import boto3
from datetime import datetime
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, to_date, max as spark_max, row_number
from pyspark.sql.window import Window
from extract import (
    read_voice_call_feedback_table,
    read_voice_interview_call_table,
    read_student_info_table
)
from load_incremental import write_parquet_incremental
from utils import get_postgres_creds
from urllib.parse import urlparse

# === ARGUMENTS ===
args = getResolvedOptions(sys.argv, [
    'FEEDBACK_OUTPUT_PATH',
    'SECRET_NAME',
    'DB_HOST',
    'DB_PORT',
    'DB_NAME',
    'aws_region'
])

output_path = args['FEEDBACK_OUTPUT_PATH']
secret_name = args['SECRET_NAME']
db_host = args['DB_HOST']
db_port = args['DB_PORT']
db_name = args['DB_NAME']
aws_region = args['aws_region']

print("=== Starting Incremental Glue Job ===")

# === Spark Session ===
spark = SparkSession.builder.appName("VoiceCallFeedbackIncrementalETL").getOrCreate()
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

# === JDBC Config ===
secrets = get_postgres_creds(secret_name, db_host, db_port, db_name, region_name=aws_region)
jdbc_url = secrets['url']
connection_props = secrets['properties']

# === Read Last Timestamp from Metadata ===
parsed = urlparse(output_path)
bucket = parsed.netloc
prefix = parsed.path.lstrip("/")
metadata_key = os.path.join(prefix, "metadata", "last_processed_timestamp.json")

s3 = boto3.client("s3", region_name=aws_region)

def read_metadata():
    try:
        obj = s3.get_object(Bucket=bucket, Key=metadata_key)
        meta = json.loads(obj['Body'].read().decode('utf-8'))
        return meta.get('last_timestamp', '1970-01-01 00:00:00')
    except s3.exceptions.NoSuchKey:
        return '1970-01-01 00:00:00'

def write_metadata(new_timestamp):
    metadata = {
        "last_timestamp": str(new_timestamp),
        "last_run": datetime.utcnow().isoformat()

    }
    s3.put_object(Bucket=bucket, Key=metadata_key, Body=json.dumps(metadata))

last_ts = read_metadata()
print(f"Last processed timestamp: {last_ts}")

# === Read Full Tables ===
feedback_df = read_voice_call_feedback_table(spark, jdbc_url, connection_props)
interview_df = read_voice_interview_call_table(spark, jdbc_url, connection_props) \
    .withColumnRenamed("email", "interview_email") \
    .withColumnRenamed("first_name", "interview_first_name") \
    .withColumnRenamed("name", "interview_name") \
    .withColumnRenamed("uuid", "interview_uuid") \
    .withColumnRenamed("conversation_uuid", "interview_conversation_uuid") \
    .withColumnRenamed("student_id", "interview_student_id")

student_df = read_student_info_table(spark, jdbc_url, connection_props) \
    .withColumnRenamed("email", "student_email") \
    .withColumnRenamed("first_name", "student_first_name") \
    .withColumnRenamed("id", "student_id")

# === Join Tables Using INNER JOINs ===
joined_df = interview_df.join(
    feedback_df,
    interview_df.interview_conversation_uuid == feedback_df.conversation_uuid,
    "full"
)

final_df = joined_df.join(
    student_df,
    joined_df.interview_student_id == student_df.student_id,
    "full"
)

# === Filter using end_time after joins ===
final_df = final_df.filter(col("end_time") > last_ts)

# === Check for New Data ===
if final_df.rdd.isEmpty():
    print("No new data after filtering. Exiting.")
    write_metadata(last_ts)
    spark.stop()
    raise Exception("No new data — job completed successfully but skipped processing.")


# === Add Partition Columns ===
final_df = final_df.withColumn("year", year(to_date(col("start_time")))) \
                   .withColumn("week", weekofyear(to_date(col("start_time"))))

# === Get Affected Partitions ===
affected_parts = final_df.select("year", "week").distinct().collect()

# === Read Existing Data from S3 for Affected Partitions ===
try:
    existing_df = spark.read.parquet(output_path)
    filters = [((col("year") == r["year"]) & (col("week") == r["week"])) for r in affected_parts]
    if filters:
        combined_filter = filters[0]
        for f in filters[1:]:
            combined_filter = combined_filter | f
        existing_df = existing_df.filter(combined_filter)
    else:
        existing_df = spark.createDataFrame([], final_df.schema)
except Exception as e:
    print("No existing data found or read failed:", e)
    existing_df = spark.createDataFrame([], final_df.schema)

# === Deduplicate using end_time ===
all_data = final_df.unionByName(existing_df, allowMissingColumns=True)
window = Window.partitionBy("conversation_uuid").orderBy(col("end_time").desc())
deduped = all_data.withColumn("rn", row_number().over(window)).filter(col("rn") == 1).drop("rn")

# === Write to S3 ===
write_parquet_incremental(deduped, output_path)
# === Update Metadata ===
new_max_ts = final_df.agg(spark_max("end_time")).collect()[0][0]
write_metadata(new_max_ts)

print(f"Metadata updated with last_timestamp = {new_max_ts}")
print("Incremental Glue Job Completed")
spark.stop()
