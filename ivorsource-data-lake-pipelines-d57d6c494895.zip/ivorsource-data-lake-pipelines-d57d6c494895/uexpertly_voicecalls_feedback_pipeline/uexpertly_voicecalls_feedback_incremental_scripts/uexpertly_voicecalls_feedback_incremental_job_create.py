import os
import json

# Enforce PARAMS_FILE must be set
params_file = os.getenv("PARAMS_FILE")
if not params_file:
    raise RuntimeError("PARAMS_FILE environment variable is not set!")

# Load parameters from file
with open(params_file) as f:
    params = json.load(f)

# Detect environment (default to dev)
env = params.get("ENV", "dev").lower()

# Load environment-specific values
bucket = params[f"S3_BUCKET_{env.upper()}"]
glue_role = params[f"GLUE_ROLE_ARN_{env.upper()}"]
glue_job_name = params[f"GLUE_JOB_NAME_{env.upper()}"]
script_key = params["SCRIPT_KEY"]
temp_dir = params["TEMP_DIR"]
zip_key = params["ZIP_KEY"]
jar_key = params["JAR_KEY"]
feedback_output = params["FEEDBACK_OUTPUT_PATH"]
secret_name = params["SECRET_NAME"]

# Construct Glue Job payload
glue_job_config = {
    "Name": glue_job_name,
    "JobMode": "SCRIPT",
    "JobRunQueuingEnabled": False,
    "Description": "Incremental ETL job to upsert voice call feedback from PostgreSQL to S3 using Glue and Step Functions.",
    "Role": glue_role,
    "ExecutionProperty": {
        "MaxConcurrentRuns": 1
    },
    "Command": {
        "Name": "glueetl",
        "ScriptLocation": f"s3://{bucket}/{script_key}",
        "PythonVersion": "3"
    },
    "DefaultArguments": {
        "--enable-metrics": "true",
        "--enable-spark-ui": "true",
        "--enable-spark-ui-legacy-path": "true",
        "--spark-event-logs-path": f"s3://aws-glue-assets-840799296958-us-east-1/sparkHistoryLogs/",
        "--enable-job-insights": "true",
        "--enable-observability-metrics": "true",
        "--enable-glue-datacatalog": "true",
        "--enable-continuous-cloudwatch-log": "true",
        "--job-bookmark-option": "job-bookmark-disable",
        "--job-language": "python",
        "--TempDir": f"s3://{bucket}/{temp_dir}",
        "--extra-py-files": f"s3://{bucket}/{zip_key}",
        "--extra-jars": f"s3://{bucket}/{jar_key}",
        "--FEEDBACK_OUTPUT_PATH": feedback_output,
        "--SECRET_NAME": secret_name
    },
    "MaxRetries": 0,
    "Timeout": 480,
    "WorkerType": "G.1X",
    "NumberOfWorkers": 2,
    "GlueVersion": "4.0",
    "ExecutionClass": "STANDARD"
}

# Save output as JSON
output_path = os.path.join(
    os.path.dirname(params_file),
    "uexpertly_voicecalls_feedback_incremental_job_create.json"
)

with open(output_path, "w") as f:
    json.dump(glue_job_config, f, indent=2)

print(f"{os.path.basename(output_path)} generated using: {params_file}")
