import os
import json

# Enforce PARAMS_FILE must be set
params_file = os.getenv("PARAMS_FILE")
if not params_file:
    raise RuntimeError("PARAMS_FILE environment variable is not set!")

# Load parameters from file
with open(params_file) as f:
    params = json.load(f)

# Detect environment
env = params.get("ENV", "dev").lower()

# Load env-specific values
bucket = params[f"S3_BUCKET_{env.upper()}"]
glue_role = params[f"GLUE_ROLE_ARN_{env.upper()}"]
script_key = params["SCRIPT_KEY"]
temp_dir = params["TEMP_DIR"]
zip_key = params["ZIP_KEY"]
jar_key = params["JAR_KEY"]
feedback_output = params["FEEDBACK_OUTPUT_PATH"]
secret_name = params["SECRET_NAME"]

# Create Glue job update payload
job_update = {
    "Role": glue_role,
    "Command": {
        "Name": "glueetl",
        "ScriptLocation": f"s3://{bucket}/{script_key}",
        "PythonVersion": "3"
    },
    "DefaultArguments": {
        "--TempDir": f"s3://{bucket}/{temp_dir}",
        "--extra-py-files": f"s3://{bucket}/{zip_key}",
        "--extra-jars": f"s3://{bucket}/{jar_key}",
        "--enable-glue-datacatalog": "true",
        "--job-bookmark-option": "job-bookmark-disable",
        "--enable-continuous-cloudwatch-log": "true",
        "--FEEDBACK_OUTPUT_PATH": feedback_output,
        "--SECRET_NAME": secret_name
    },
    "GlueVersion": "4.0",
    "WorkerType": "G.1X",
    "NumberOfWorkers": 2,
    "Timeout": 480,
    "ExecutionClass": "STANDARD"
}

# Save output
output_path = os.path.join(
    os.path.dirname(params_file),
    "uexpertly_voicecalls_feedback_incremental_job_update.json"
)

with open(output_path, "w") as f:
    json.dump(job_update, f, indent=2)

print(f"{os.path.basename(output_path)} generated using: {params_file}")
