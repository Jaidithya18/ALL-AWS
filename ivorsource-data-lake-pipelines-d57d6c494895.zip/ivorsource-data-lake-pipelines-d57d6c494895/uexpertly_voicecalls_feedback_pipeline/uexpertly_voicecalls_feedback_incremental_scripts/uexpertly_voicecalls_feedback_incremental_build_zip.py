import zipfile
import os

# Get current script directory
script_dir = os.path.dirname(__file__)

# Set output zip path for incremental ETL
zip_path = os.path.join(script_dir, "..", "uexpertly_voicecalls_feedback_incremental_etl_module_.zip")

# Define the ETL package directory for incremental
etl_dir = os.path.join(script_dir, "..", "uexpertly_voicecalls_feedback_etl_package")

def zip_etl_module(zip_path: str, etl_dir: str) -> None:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(etl_dir):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, etl_dir)  # only relative path inside zip
                zipf.write(full_path, arcname)

zip_etl_module(zip_path, etl_dir)
print(f"{os.path.basename(zip_path)} created at {os.path.abspath(zip_path)}")
