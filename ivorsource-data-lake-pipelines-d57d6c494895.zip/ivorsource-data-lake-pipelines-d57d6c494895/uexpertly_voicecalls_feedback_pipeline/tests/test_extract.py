from unittest.mock import MagicMock
from uexpertly_voicecalls_feedback_historical_etl_package.extract import (
    read_voice_call_feedback_table,
    read_voice_interview_call_table,
    read_student_info_table
)

def test_read_voice_call_feedback_table():
    mock_spark = MagicMock()
    mock_spark.read.jdbc.return_value = "mocked_df"

    result = read_voice_call_feedback_table(
        spark=mock_spark,
        jdbc_url="jdbc:postgresql://localhost:5432/testdb",
        connection_props={"user": "test", "password": "pass"}
    )

    print("Returned from read_voice_call_feedback_table:", result)
    assert result == "mocked_df"

def test_read_voice_interview_call_table():
    mock_spark = MagicMock()
    mock_spark.read.jdbc.return_value = "mocked_df"

    result = read_voice_interview_call_table(
        spark=mock_spark,
        jdbc_url="jdbc:postgresql://localhost:5432/testdb",
        connection_props={"user": "test", "password": "pass"}
    )

    print("Returned from read_voice_interview_call_table:", result)
    assert result == "mocked_df"

def test_read_student_info_table():
    mock_spark = MagicMock()
    mock_spark.read.jdbc.return_value = "mocked_df"

    result = read_student_info_table(
        spark=mock_spark,
        jdbc_url="jdbc:postgresql://localhost:5432/testdb",
        connection_props={"user": "test", "password": "pass"}
    )

    print("Returned from read_student_info_table:", result)
    assert result == "mocked_df"
