import pytest
from unittest.mock import patch
from pyspark.sql import SparkSession, Row
from uexpertly_voicecalls_feedback_historical_etl_package.load import write_parquet


def test_write_voicecalls_feedback_parquet():
    print("Running: test_write_voicecalls_feedback_parquet")
    spark = SparkSession.builder.master("local[*]").appName("TestETL").getOrCreate()

    try:
        df = spark.createDataFrame([Row(id=1, name="Test")])
        with patch("pyspark.sql.readwriter.DataFrameWriter.parquet") as mock_parquet:
            write_parquet(df, "dummy/path")
            mock_parquet.assert_called_once()
            print("Mock parquet write called successfully.")
    finally:
        spark.stop()


def test_read_back_parquet():
    print("Running: test_read_back_parquet")
    spark = SparkSession.builder.master("local[*]").appName("TestETL").getOrCreate()

    try:
        df = spark.createDataFrame([Row(id=42, name="Vinutha")])
        with patch("pyspark.sql.readwriter.DataFrameWriter.parquet") as mock_parquet:
            df.coalesce(1).write.mode("overwrite").parquet("fake/output/path")
            mock_parquet.assert_called_once()
            print("Mock parquet write verified for read back.")
    finally:
        spark.stop()

