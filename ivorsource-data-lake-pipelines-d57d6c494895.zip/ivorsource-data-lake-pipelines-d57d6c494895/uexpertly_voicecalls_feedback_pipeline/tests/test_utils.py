import json
from unittest.mock import patch
from uexpertly_voicecalls_feedback_historical_etl_package.utils import get_postgres_creds

@patch("boto3.session.Session.client")
def test_get_postgres_creds(mock_client):
    mock_client().get_secret_value.return_value = {
        'SecretString': json.dumps({
            "POSTGRES_USER": "user",
            "POSTGRES_PASSWORD": "pass"
        })
    }

    creds = get_postgres_creds("fake-secret", "localhost", 5432, "testdb")

    print(creds)
    assert creds['url'] == "jdbc:postgresql://localhost:5432/testdb"
    assert creds['properties']['user'] == "user"
    assert creds['properties']['password'] == "pass"
