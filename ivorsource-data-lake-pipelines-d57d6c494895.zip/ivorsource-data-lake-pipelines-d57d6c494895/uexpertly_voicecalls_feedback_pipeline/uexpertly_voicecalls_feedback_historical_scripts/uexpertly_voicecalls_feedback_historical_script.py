import sys
import os
import json
import boto3
import datetime
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, to_date, max as spark_max, row_number
from utils import get_postgres_creds
from extract import (
    read_voice_call_feedback_table,
    read_voice_interview_call_table,
    read_student_info_table
)
from load import write_parquet

if os.getenv("ENV", "aws") == "local":
    from dotenv import load_dotenv
    load_dotenv(".env")

sys.path.append('/tmp/uexpertly_voicecalls_feedback_historical_etl_module_.zip')

def get_table_profile(df, duplicate_column=None):
    profile = {}
    profile["row_count"] = df.count()
    profile["columns"] = df.columns

    null_counts = {}
    for col_name in df.columns:
        count = df.filter(col(col_name).isNull()).count()
        if count > 0:
            null_counts[col_name] = count
    profile["null_counts"] = null_counts

    if duplicate_column and duplicate_column in df.columns:
        dup_count = df.groupBy(duplicate_column).count().filter("count > 1").count()
        profile["duplicate_count_on_" + duplicate_column] = dup_count

    return profile

def print_table_profile(df, table_name, duplicate_column=None):
    print(f"\n==== {table_name} Profile ====")
    print(f"Row count: {df.count()}")
    print("Schema:")
    df.printSchema()

    print("Null counts:")
    for col_name in df.columns:
        null_count = df.filter(col(col_name).isNull()).count()
        if null_count > 0:
            print(f"  {col_name}: {null_count}")

    if duplicate_column and duplicate_column in df.columns:
        dup_count = df.groupBy(duplicate_column).count().filter("count > 1").count()
        print(f"Duplicate {duplicate_column} values: {dup_count}")

    print("======================\n")

args = getResolvedOptions(sys.argv, [
    'FEEDBACK_OUTPUT_PATH',
    'SECRET_NAME',
    'DB_HOST',
    'DB_PORT',
    'DB_NAME',
    'aws_region'
])

feedback_output_path = args['FEEDBACK_OUTPUT_PATH']
secret_name = args['SECRET_NAME']
db_host = args['DB_HOST']
db_port = args['DB_PORT']
db_name = args['DB_NAME']
aws_region = args['aws_region']

print(f"FEEDBACK_OUTPUT_PATH: {feedback_output_path}")
print(f"SECRET_NAME: {secret_name}")
print(f"DB_HOST: {db_host}")
print(f"DB_PORT: {db_port}")
print(f"DB_NAME: {db_name}")
print(f"AWS_REGION: {aws_region}")

print("Starting Voice Call Feedback ETL Job")
spark = SparkSession.builder.appName("VoiceCallFeedbackETL").getOrCreate()

print("Reading PostgreSQL credentials from Secrets Manager")
secrets = get_postgres_creds(secret_name, db_host, db_port, db_name, region_name=aws_region)
jdbc_url = secrets['url']
connection_props = secrets['properties']

print("Loading tables")
interview_df = read_voice_interview_call_table(spark, jdbc_url, connection_props) \
    .withColumnRenamed("email", "interview_email") \
    .withColumnRenamed("first_name", "interview_first_name") \
    .withColumnRenamed("name", "interview_name") \
    .withColumnRenamed("uuid", "interview_uuid") \
    .withColumnRenamed("conversation_uuid", "interview_conversation_uuid") \
    .withColumnRenamed("student_id", "interview_student_id")

feedback_df = read_voice_call_feedback_table(spark, jdbc_url, connection_props)

student_df = read_student_info_table(spark, jdbc_url, connection_props) \
    .withColumnRenamed("email", "student_email") \
    .withColumnRenamed("first_name", "student_first_name") \
    .withColumnRenamed("id", "student_id")

print_table_profile(interview_df, "Interview Table", duplicate_column="interview_conversation_uuid")
print_table_profile(feedback_df, "Feedback Table", duplicate_column="conversation_uuid")
print_table_profile(student_df, "Student Table", duplicate_column="student_id")

print("Joining tables")
joined_df = interview_df.join(
    feedback_df,
    interview_df.interview_conversation_uuid == feedback_df.conversation_uuid,
    "full"
)
final_df = joined_df.join(
    student_df,
    joined_df.interview_student_id == student_df.student_id,
    "full"
)

final_df.show(10, truncate=False)
print_table_profile(joined_df, "Interview + Feedback Join", duplicate_column="conversation_uuid")
print_table_profile(final_df, "Final Joined Table", duplicate_column="conversation_uuid")

print("Running Data Quality Checks")
dq_summary = {}
dq_summary["interview_table"] = get_table_profile(interview_df, duplicate_column="interview_conversation_uuid")
dq_summary["feedback_table"] = get_table_profile(feedback_df, duplicate_column="conversation_uuid")
dq_summary["student_table"] = get_table_profile(student_df, duplicate_column="student_id")
dq_summary["interview_feedback_join"] = get_table_profile(joined_df, duplicate_column="conversation_uuid")
dq_summary["final_joined_table"] = get_table_profile(final_df, duplicate_column="conversation_uuid")

try:
    dq_summary["final_table_extra_checks"] = {}
    dq_summary["final_table_extra_checks"]["row_count"] = final_df.count()

    expected_schema = {
        "interview_conversation_uuid": "string",
        "student_email": "string",
        "interview_student_id": "string",
        "conversation_uuid": "string"
    }
    actual_schema = {field.name: field.dataType.simpleString() for field in final_df.schema.fields}
    schema_mismatches = {}
    for col_name, expected_type in expected_schema.items():
        actual_type = actual_schema.get(col_name)
        if actual_type != expected_type:
            schema_mismatches[col_name] = actual_type
    dq_summary["final_table_extra_checks"]["schema_mismatches"] = schema_mismatches

    dq_summary["final_table_extra_checks"]["nulls_in_interview_student_id"] = final_df.filter(col("interview_student_id").isNull()).count()
    dq_summary["final_table_extra_checks"]["nulls_in_student_email"] = final_df.filter(col("student_email").isNull()).count()
    dq_summary["final_table_extra_checks"]["nulls_in_conversation_uuid"] = final_df.filter(col("conversation_uuid").isNull()).count()
    dq_summary["final_table_extra_checks"]["duplicate_conversation_uuid"] = final_df.groupBy("conversation_uuid").count().filter("count > 1").count()

    if "feedback_score" in final_df.columns:
        dq_summary["final_table_extra_checks"]["invalid_feedback_score"] = final_df.filter(
            (col("feedback_score") < 1) | (col("feedback_score") > 10)
        ).count()

except Exception as e:
    print(f"DQ check exception: {str(e)}")

print("\nData Quality Results Summary:")
print(f"Total Rows: {dq_summary['final_table_extra_checks'].get('row_count', 'N/A')}")
print("Schema Mismatches:")
for col_name, mismatch in dq_summary["final_table_extra_checks"].get("schema_mismatches", {}).items():
    print(f"  - {col_name}: expected vs actual type {mismatch}")
print(f"Nulls in interview_student_id: {dq_summary['final_table_extra_checks'].get('nulls_in_interview_student_id', 'N/A')}")
print(f"Nulls in student_email: {dq_summary['final_table_extra_checks'].get('nulls_in_student_email', 'N/A')}")
print(f"Nulls in conversation_uuid: {dq_summary['final_table_extra_checks'].get('nulls_in_conversation_uuid', 'N/A')}")
print(f"Duplicate conversation_uuid count: {dq_summary['final_table_extra_checks'].get('duplicate_conversation_uuid', 'N/A')}")
print(f"Invalid feedback_score count: {dq_summary['final_table_extra_checks'].get('invalid_feedback_score', 'N/A')}")



print("Proceeding to write final data to S3")
write_parquet(final_df, feedback_output_path)

max_end_time = final_df.agg(spark_max("end_time")).collect()[0][0]
metadata = {
    "last_timestamp": str(max_end_time),
    "last_run": datetime.datetime.utcnow().isoformat()
}

# Parse bucket and key from output path
from urllib.parse import urlparse
parsed = urlparse(feedback_output_path)
bucket = parsed.netloc
prefix = parsed.path.lstrip("/")
metadata_key = os.path.join(prefix, "metadata", "last_processed_timestamp.json")

s3 = boto3.client("s3", region_name=aws_region)
s3.put_object(
    Bucket=bucket,
    Key=metadata_key,
    Body=json.dumps(metadata)
)

print(f"Metadata file written to s3://{bucket}/{metadata_key}")

spark.stop()
print("Voice Call Feedback ETL Job completed successfully")
