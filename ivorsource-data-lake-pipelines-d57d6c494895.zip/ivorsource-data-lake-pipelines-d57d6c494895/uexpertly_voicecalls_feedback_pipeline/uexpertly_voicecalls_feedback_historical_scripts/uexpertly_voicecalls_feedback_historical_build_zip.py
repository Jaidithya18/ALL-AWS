import zipfile
import os

script_dir = os.path.dirname(__file__)

# Correct: output zip path
zip_path = os.path.join(script_dir, "..", "uexpertly_voicecalls_feedback_historical_etl_module_.zip")

# Correct: etl_dir is directly the package folder (NO "etl" inside)
etl_dir = os.path.join(script_dir, "..", "uexpertly_voicecalls_feedback_etl_package")

def zip_etl_module(zip_path: str, etl_dir: str) -> None:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(etl_dir):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, etl_dir)  # Only relative to etl_dir
                zipf.write(full_path, arcname)

zip_etl_module(zip_path, etl_dir)
print(f"{os.path.basename(zip_path)} created at {os.path.abspath(zip_path)}")
