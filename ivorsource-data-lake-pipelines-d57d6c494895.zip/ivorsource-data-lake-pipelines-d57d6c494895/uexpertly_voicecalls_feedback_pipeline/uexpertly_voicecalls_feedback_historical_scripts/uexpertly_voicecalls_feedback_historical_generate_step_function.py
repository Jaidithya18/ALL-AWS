import os
import json

# Dynamically load the correct parameters file
params_file = os.getenv("PARAMS_FILE")
if not params_file:
    raise RuntimeError("PARAMS_FILE environment variable is not set!")

with open(params_file) as f:
    params = json.load(f)

env = params["ENV"].lower()

# Environment-specific values
glue_job_name = params[f"GLUE_JOB_NAME_{env.upper()}"]
data_lake_bucket = params["DATA_LAKE_BUCKET"]
athena_db = params["ATHENA_DB"]
secret_name = params["SECRET_NAME"]
feedback_output_path = params["FEEDBACK_OUTPUT_PATH"]
crawler_name = params[f"CRAWLER_NAME_{env.upper()}"]
crawler_role = params[f"GLUE_CRAWLER_ROLE_ARN_{env.upper()}"]
db_host = params["DB_HOST"]
db_port = params["DB_PORT"]
db_name = params["DB_NAME"]
aws_region = params["aws_region"]

# Step Function definition
step_function_def = {
    "Comment": "ETL with retries and Glue Crawler (conditional)",
    "StartAt": "Start Glue Job",
    "States": {
        "Start Glue Job": {
            "Type": "Task",
            "Resource": "arn:aws:states:::glue:startJobRun.sync",
            "Parameters": {
                "JobName": glue_job_name,
                "Arguments": {
                    "--FEEDBACK_OUTPUT_PATH": feedback_output_path,
                    "--SECRET_NAME": secret_name,
                    "--DB_HOST": db_host,
                    "--DB_PORT": db_port,
                    "--DB_NAME": db_name,
                    "--aws_region": aws_region
                }
            },
            "Retry": [
                {
                    "ErrorEquals": ["States.ALL"],
                    "IntervalSeconds": 5,
                    "MaxAttempts": 2,
                    "BackoffRate": 2.0
                }
            ],
            "Catch": [
                {
                    "ErrorEquals": ["States.ALL"],
                    "Next": "Handle Failure"
                }
            ],
            "Next": "Check Crawler Exists"
        },
        "Check Crawler Exists": {
            "Type": "Task",
            "Resource": "arn:aws:states:::aws-sdk:glue:getCrawler",
            "Parameters": {
                "Name": crawler_name
            },
            "Next": "Start Glue Crawler",
            "Catch": [
                {
                    "ErrorEquals": ["Glue.EntityNotFoundException"],
                    "Next": "Create Glue Crawler"
                },
                {
                    "ErrorEquals": ["States.ALL"],
                    "Next": "Handle Failure"
                }
            ]
        },
        "Create Glue Crawler": {
            "Type": "Task",
            "Resource": "arn:aws:states:::aws-sdk:glue:createCrawler",
            "Parameters": {
                "Name": crawler_name,
                "Role": crawler_role,
                "DatabaseName": athena_db,
                "Targets": {
                    "S3Targets": [
                        {
                            "Path": feedback_output_path
                        }
                    ]
                },
                "SchemaChangePolicy": {
                    "UpdateBehavior": "UPDATE_IN_DATABASE",
                    "DeleteBehavior": "DEPRECATE_IN_DATABASE"
                }
            },
            "Next": "Start Glue Crawler"
        },
        "Start Glue Crawler": {
            "Type": "Task",
            "Resource": "arn:aws:states:::aws-sdk:glue:startCrawler",
            "Parameters": {
                "Name": crawler_name
            },
            "Next": "WaitForCrawler"
        },
        "WaitForCrawler": {
            "Type": "Wait",
            "Seconds": 45,
            "Next": "Success"
        },
        "Success": {
            "Type": "Succeed"
        },
        "Handle Failure": {
            "Type": "Fail",
            "Error": "StepFunctionFailed",
            "Cause": "One or more tasks failed even after retry."
        }
    }
}

output_path = os.path.join(
    os.path.dirname(params_file),
    "uexpertly_voicecalls_feedback_historical_step_function.json"
)

with open(output_path, "w") as f:
    json.dump(step_function_def, f, indent=2)

print(f"{os.path.basename(output_path)} generated using: {params_file}")
