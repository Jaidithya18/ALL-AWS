import sys
import boto3
import json
import datetime
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, max as spark_max, to_date, row_number
from pyspark.sql.window import Window

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Parse args
args = sys.argv
secret_name = args[args.index('--secret_name') + 1]
aws_region = args[args.index('--aws_region') + 1]
destination_bucket = args[args.index('--destination_bucket') + 1]
metadata_file_path = args[args.index('--metadata_file_path') + 1]
source_table = args[args.index('--source_table') + 1]
bucket_name = args[args.index('--bucket_name') + 1]
metadata_key = args[args.index('--metadata_key') + 1]
postgres_host = args[args.index('--postgres_host') + 1]
postgres_db = args[args.index('--postgres_db') + 1]
postgres_port = args[args.index('--postgres_port') + 1]

logger.info(f"Arguments: {args}")

# Secrets
def get_secret(secret_name):
    client = boto3.client('secretsmanager', region_name=aws_region)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

secrets = get_secret(secret_name)
postgres_user = secrets['POSTGRES_USER']
postgres_password = secrets['POSTGRES_PASSWORD']

# Spark session
spark = SparkSession.builder \
    .appName("IncrementalLoadWithUpsert") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.hadoop.fs.s3a.aws.credentials.provider", "com.amazonaws.auth.DefaultAWSCredentialsProviderChain") \
    .config("spark.hadoop.fs.s3a.endpoint", "s3.amazonaws.com") \
    .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
    .config("spark.sql.files.maxPartitionBytes", "128MB") \
    .config("spark.sql.adaptive.enabled", "true") \
    .config("spark.dynamicAllocation.enabled", "true") \
    .config("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol") \
    .getOrCreate()

# S3 client
s3_client = boto3.client('s3', region_name=aws_region)

def read_metadata(bucket, key):
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        return json.loads(obj['Body'].read().decode('utf-8'))['last_timestamp']
    except s3_client.exceptions.NoSuchKey:
        return '1970-01-01 00:00:00'
    except Exception as e:
        logger.error(f"Error reading metadata: {e}")
        raise

def write_metadata(bucket, key, last_timestamp):
    try:
        metadata = {"last_timestamp": str(last_timestamp), "last_run": datetime.datetime.now().isoformat()}
        s3_client.put_object(Bucket=bucket, Key=key, Body=json.dumps(metadata))
        logger.info("Metadata updated successfully")
    except Exception as e:
        logger.error(f"Error writing metadata: {e}")
        raise

# Read last processed timestamp
last_processed_timestamp = read_metadata(bucket_name, metadata_key)
logger.info(f"Last processed timestamp: {last_processed_timestamp}")

# PostgreSQL JDBC properties
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
properties = {
    "user": postgres_user,
    "password": postgres_password,
    "driver": "org.postgresql.Driver"
}

# Read new data from Postgres
query = f"(SELECT * FROM {source_table} WHERE updated_at > '{last_processed_timestamp}') AS new_data"
logger.info(f"Query: {query}")

new_data = spark.read \
    .format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", query) \
    .option("user", properties["user"]) \
    .option("password", properties["password"]) \
    .option("driver", properties["driver"]) \
    .load()

if new_data.count() == 0:
    logger.info("No new data found. Skipping data processing.")
    write_metadata(bucket_name, metadata_key, last_processed_timestamp)
    spark.stop()
    sys.exit(0)

# Add partition columns (year and week only)
new_data = new_data.withColumn("year", year(to_date(col("end_date_time")))) \
                   .withColumn("week", weekofyear(to_date(col("end_date_time"))))

# Get affected partitions (year and week only)
affected_partitions = new_data.select("year", "week").distinct().collect()
logger.info(f"Affected partitions: {affected_partitions}")

# Build filter for only affected partitions for efficient S3 read
part_filters = [
    (col("year") == r["year"]) & (col("week") == r["week"])
    for r in affected_partitions
]
if part_filters:
    filter_expr = part_filters[0]
    for f in part_filters[1:]:
        filter_expr = filter_expr | f
else:
    filter_expr = None

# Read only existing data in affected partitions
try:
    all_data_exist = spark.read.parquet(destination_bucket)
    if filter_expr is not None:
        data_exist = all_data_exist.filter(filter_expr)
    else:
        data_exist = spark.createDataFrame([], new_data.schema)
    logger.info(f"Loaded existing data for affected partitions")
except Exception as e:
    logger.warning(f"No existing data found or failed to read: {e}")
    data_exist = spark.createDataFrame([], new_data.schema)

# Union and deduplicate (upsert by id, keep latest updated_at)
all_data = new_data.unionByName(data_exist, allowMissingColumns=True)
window = Window.partitionBy("id").orderBy(col("updated_at").desc())
all_data_dedup = all_data.withColumn("rn", row_number().over(window)) \
                         .filter(col("rn") == 1) \
                         .drop("rn")

# Write full upserted data for affected partitions (partitioned by year, week)
all_data_dedup.write \
    .mode("overwrite") \
    .option("partitionOverwriteMode", "dynamic") \
    .partitionBy("year", "week") \
    .parquet(destination_bucket)

logger.info("Written upserted data to S3")

# Update metadata with new max(updated_at)
new_updated_at = new_data.agg(spark_max(col("updated_at"))).collect()[0][0]
write_metadata(bucket_name, metadata_key, new_updated_at)
logger.info(f"Metadata updated with new updated_at: {new_updated_at}")

# Stop Spark
spark.stop()
logger.info("Spark session stopped")