## **Repo: Practice Calls Data Pipeline**

This repository contains two AWS-based ETL pipelines for managing *Practice Calls* data from a PostgreSQL database to an Amazon S3 data lake, making it queryable through Athena. The two pipelines are:

* **Historical Pipeline**
Flow diagram
![Historical](images/historical_datapipeline_flow_diagram.png)


* **Incremental Pipeline**
Flow diagram
![Incremental](images/incremental_datapipeline_flow_diagram.png)

---

### **Project Overview**

#### **1\. Historical Pipeline**

This pipeline is designed to load the **entire historical dataset** from PostgreSQL into an S3 bucket.

* A **Step Function** is triggered (created via CI/CD).

* The Step Function launches an **AWS Glue Job** that:

  * Pulls the historical data from PostgreSQL using a script from S3.

  * Writes the data to the **raw layer** in S3.

* After the job completes:

  * The Step Function initiates an **AWS Glue Crawler**.

  * The crawler catalogs the S3 data so it can be queried using **Amazon Athena**.

#### **2\. Incremental Pipeline**

This pipeline handles **weekly incremental data loads**, partitioned by date.

* A **CI/CD-deployed EventBridge** rule triggers every **Saturday at 11:30 PM**.

* This triggers a Step Function that:

  * Creates and runs an AWS Glue Job with an S3-hosted script.

  * The script:

    * Reads new data from PostgreSQL based on a `last_updated_at` column.

    * Writes partitioned data to S3 by **year/month/day** for efficient querying.


---

### **Repository Structure**

| File/Folder | Description |
| ----- | ----- |
| `.gitignore` | Git ignore rules. |
| `sql_script_modification` | SQL script to add `last_updated_at` column for enabling incremental load. |
| `uexpertly_practice_call_historical_parameters_dev.json` | Dev environment input parameters for historical Step Function. |
| `uexpertly_practice_call_historical_parameters_prod.json` | Prod environment input parameters for historical Step Function. |
| `uexpertly_practice_call_historical_script.py` | Glue script to extract historical data from PostgreSQL and load to S3. |
| `uexpertly_practice_call_historical_step_function.json` | Step Function definition for historical data pipeline. |
| `uexpertly_practice_call_incremental_parameters_dev.json` | Dev environment input parameters for incremental Step Function. |
| `uexpertly_practice_call_incremental_parameters_prod.json` | Prod environment input parameters for incremental Step Function. |
| `uexpertly_practice_call_incremental_script.py` | Glue script for incremental data extraction from PostgreSQL. |
| `uexpertly_practice_call_incremental_step_function.json` | Step Function definition for the incremental pipeline. |

---

### **🔧 Prerequisites**

* AWS Services: S3, Glue, Step Functions, EventBridge, Athena

* PostgreSQL with a `last_updated_at` column for incremental tracking

* CI/CD pipeline for infrastructure deployment (e.g., Terraform or CloudFormation)

---

### **📅 Schedule**

* **Historical Pipeline**: On-demand

* **Incremental Pipeline**: Every Saturday at 11:30 PM (via EventBridge)

---

### **🧪 Notes**

* Make sure your PostgreSQL tables include a `last_updated_at` field before running the incremental load.

* Metadata cataloging via AWS Glue Crawler allows querying via Athena.

