import logging
from pyspark.sql import SparkSession
import boto3
import json
import sys

# Set up logging
logging.basicConfig(level=logging.INFO)  # Adjust level to DEBUG, INFO, WARNING as needed
logger = logging.getLogger(__name__)

# Retrieve arguments passed to the script
args = sys.argv
logger.info(f"Arguments received: {args}")

# Parse command-line arguments
try:
    secret_name = args[args.index('--secret_name') + 1]               # Secret name
    aws_region = args[args.index('--aws_region') + 1]                 # AWS region
    destination_bucket = args[args.index('--destination_bucket') + 1]# Destination bucket
    source_table = args[args.index('--source_table') + 1]            # Source table
    postgres_host = args[args.index('--postgres_host') + 1]          # PostgreSQL host
    postgres_port = args[args.index('--postgres_port') + 1]          # PostgreSQL port
    postgres_db = args[args.index('--postgres_db') + 1]              # PostgreSQL DB name
except (ValueError, IndexError) as e:
    logger.error("Error parsing arguments: ", exc_info=e)
    sys.exit(1)

# Log the parsed arguments
logger.info(f"Argument1 Secret name         : {secret_name}")
logger.info(f"Argument2 AWS region          : {aws_region}")
logger.info(f"Argument3 Destination bucket  : {destination_bucket}")
logger.info(f"Argument4 Source table        : {source_table}")
logger.info(f"Argument5 Postgres host       : {postgres_host}")
logger.info(f"Argument6 Postgres port       : {postgres_port}")
logger.info(f"Argument7 Postgres DB         : {postgres_db}")

# Initialize Spark session
spark = SparkSession.builder \
    .appName("practicecalls_Datalake") \
    .config("spark.jars.packages", "org.postgresql:postgresql:42.2.20") \
    .getOrCreate()

# Fetch secrets from AWS Secrets Manager
def get_secret(secret_name, region_name=aws_region):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

# Get PostgreSQL credentials from Secrets Manager
secrets = get_secret(secret_name)

# Construct JDBC URL using command-line args for host, port, and db
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"

# Connection properties
properties = {
    "user": secrets["POSTGRES_USER"],
    "password": secrets["POSTGRES_PASSWORD"],
    "driver": "org.postgresql.Driver"
}

logger.info("Reading data from PostgreSQL")
# Read data from PostgreSQL
df = spark.read.jdbc(url=jdbc_url, table=source_table, properties=properties)

logger.info(f"Writing DataFrame to S3 at {destination_bucket} in Parquet format")
# Write DataFrame to S3 in Parquet format
df.write.mode("overwrite").parquet(destination_bucket)

logger.info("Stopping Spark session")
# Stop Spark session
spark.stop()
logger.info("Script finished successfully")
