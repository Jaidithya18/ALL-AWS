import sys
import boto3
import json
import logging
import datetime
import botocore.exceptions
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import year, month, col

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logging.getLogger('etl_utils').setLevel(logging.CRITICAL)
logger.info("ETL utility module loaded.")


def get_arg(name, default=None):
    if len(sys.argv) > 1 and f'--{name}' in sys.argv:
        try:
            return sys.argv[sys.argv.index(f'--{name}') + 1]
        except IndexError:
            logger.warning(f"Argument '--{name}' found but no value provided.")
            return default
    return default


def get_secret(secret_name, aws_region):
    try:
        client = boto3.client('secretsmanager', region_name=aws_region)
        response = client.get_secret_value(SecretId=secret_name)
        return json.loads(response['SecretString'])
    except Exception as e:
        logger.error(f"Error retrieving secret '{secret_name}': {e}")
        raise


def read_metadata(bucket, key, s3_client):
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        content = obj['Body'].read().decode('utf-8')
        try:
            metadata = json.loads(content)
            return metadata.get('last_timestamp', '1970-01-01')
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in metadata at {key}: {e}")
            return '1970-01-01'
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchKey':
            logger.warning(f"Metadata file '{key}' not found. Defaulting to '1970-01-01'")
            return '1970-01-01'
        else:
            logger.error(f"ClientError while reading metadata: {e}")
            return '1970-01-01'
    except Exception as e:
        logger.error(f"Unexpected error reading metadata: {e}")
        return '1970-01-01'


def write_metadata(bucket, key, last_timestamp, s3_client):
    try:
        metadata = {
            "last_timestamp": str(last_timestamp),
            "last_run": datetime.datetime.now().isoformat()
        }
        s3_client.put_object(Bucket=bucket, Key=key, Body=json.dumps(metadata))
        logger.info(f"Metadata written to {bucket}/{key}")
    except Exception as e:
        logger.error(f"Error writing metadata to {bucket}/{key}: {e}")
        raise


def read_partition_data(bucket, prefix, s3_client):
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        if 'Contents' not in response:
            logger.warning(f"No partitioned data found at prefix: {prefix}")
            return []

        partitioned_data = []
        for obj in response['Contents']:
            body = s3_client.get_object(Bucket=bucket, Key=obj['Key'])['Body'].read().decode('utf-8')
            partitioned_data.append(body)
        return partitioned_data
    except Exception as e:
        logger.error(f"Error reading partition data from {bucket}/{prefix}: {e}")
        raise


def transform_new_data(df: DataFrame) -> DataFrame:
    try:
        if "uploaded_date" not in df.columns:
            raise ValueError("Missing required column: 'uploaded_date'")
        return df.withColumn("year", year(col("uploaded_date"))) \
                 .withColumn("month", month(col("uploaded_date")))
    except Exception as e:
        logger.error(f"Error transforming data: {e}")
        raise
