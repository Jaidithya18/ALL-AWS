import unittest
from unittest.mock import patch, MagicMock
import json
import datetime
import botocore.exceptions
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from datetime import datetime as dt
from etl_utils import get_arg, get_secret, read_metadata, write_metadata, read_partition_data, transform_new_data

class TestETLUtils(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("ETLUtilsTest") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    @patch('sys.argv', ['etl_utils.py', '--input', 'data'])
    def test_get_arg(self):
        self.assertEqual(get_arg('input'), 'data')
        self.assertIsNone(get_arg('missing'))

    @patch('boto3.client')
    def test_get_secret_success(self, mock_boto_client):
        mock_client = MagicMock()
        mock_client.get_secret_value.return_value = {
            'SecretString': json.dumps({'username': 'admin'})
        }
        mock_boto_client.return_value = mock_client

        secret = get_secret('secret_id', 'us-east-1')
        self.assertEqual(secret, {'username': 'admin'})

    @patch('boto3.client')
    def test_get_secret_error(self, mock_boto_client):
        mock_client = MagicMock()
        mock_client.get_secret_value.side_effect = Exception('Secret not found')
        mock_boto_client.return_value = mock_client

        with self.assertRaises(Exception):
            get_secret('secret_id', 'us-east-1')

    def test_read_metadata_valid(self):
        mock_s3 = MagicMock()
        mock_s3.get_object.return_value = {
            'Body': MagicMock(read=MagicMock(return_value=b'{"last_timestamp": "2024-01-01"}'))
        }
        result = read_metadata('my-bucket', 'path/to/key.json', mock_s3)
        self.assertEqual(result, '2024-01-01')

    def test_read_metadata_invalid_json(self):
        mock_s3 = MagicMock()
        mock_s3.get_object.return_value = {
            'Body': MagicMock(read=MagicMock(return_value=b'invalid json'))
        }
        result = read_metadata('my-bucket', 'path/to/key.json', mock_s3)
        self.assertEqual(result, '1970-01-01')

    def test_read_metadata_no_such_key(self):
        mock_s3 = MagicMock()
        mock_s3.get_object.side_effect = botocore.exceptions.ClientError(
            {'Error': {'Code': 'NoSuchKey'}}, 'GetObject')
        result = read_metadata('bucket', 'key', mock_s3)
        self.assertEqual(result, '1970-01-01')

    def test_write_metadata_success(self):
        mock_s3 = MagicMock()
        last_timestamp = "2024-01-01T00:00:00"
        write_metadata('bucket', 'meta.json', last_timestamp, mock_s3)
        args = mock_s3.put_object.call_args[1]
        self.assertEqual(args['Bucket'], 'bucket')
        self.assertEqual(args['Key'], 'meta.json')
        self.assertIn('last_timestamp', args['Body'])

    def test_write_metadata_error(self):
        mock_s3 = MagicMock()
        mock_s3.put_object.side_effect = Exception('S3 write failed')
        with self.assertRaises(Exception):
            write_metadata('bucket', 'meta.json', '2024-01-01', mock_s3)

    def test_read_partition_data_success(self):
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {
            'Contents': [{'Key': 'prefix/part1.json'}, {'Key': 'prefix/part2.json'}]
        }
        mock_s3.get_object.side_effect = [
            {'Body': MagicMock(read=MagicMock(return_value=b'data1'))},
            {'Body': MagicMock(read=MagicMock(return_value=b'data2'))}
        ]

        result = read_partition_data('bucket', 'prefix/', mock_s3)
        self.assertEqual(result, ['data1', 'data2'])

    def test_read_partition_data_error(self):
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.side_effect = Exception('Listing error')
        with self.assertRaises(Exception):
            read_partition_data('bucket', 'prefix/', mock_s3)

    def test_transform_new_data(self):
        schema = StructType([
            StructField("id", StringType(), True),
            StructField("uploaded_date", TimestampType(), True)
        ])
        data = [("a1", dt(2024, 1, 10)), ("b2", dt(2024, 5, 22))]
        df = self.spark.createDataFrame(data, schema)

        result_df = transform_new_data(df)
        result = result_df.select("id", "year", "month").collect()

        self.assertEqual(result[0]["year"], 2024)
        self.assertEqual(result[0]["month"], 1)
        self.assertEqual(result[1]["year"], 2024)
        self.assertEqual(result[1]["month"], 5)

if __name__ == '__main__':
    unittest.main()