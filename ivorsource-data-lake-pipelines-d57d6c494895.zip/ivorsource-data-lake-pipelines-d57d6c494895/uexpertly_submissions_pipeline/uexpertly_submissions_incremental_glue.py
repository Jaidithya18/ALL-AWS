import sys
import boto3
import json
import os
import datetime
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, month, max as spark_max, row_number
from pyspark.sql.window import Window 
from py4j.protocol import Py4JJavaError

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Helper to get command-line arguments
def get_arg(name):
    return sys.argv[sys.argv.index(f'--{name}') + 1]

# Read script arguments
secret_name = get_arg('secret_name')
aws_region = get_arg('aws_region')
destination_bucket = get_arg('destination_bucket')
metadata_file_path = get_arg('metadata_file_path')
source_table = get_arg('source_table')
bucket_name = get_arg('bucket_name')
metadata_key = get_arg('metadata_key')
postgres_host = get_arg('postgres_host')
postgres_db = get_arg('postgres_db')
postgres_port = get_arg('postgres_port')

# Log received arguments
logger.info(f"Secret name        : {secret_name}")
logger.info(f"AWS region         : {aws_region}")
logger.info(f"Destination bucket : {destination_bucket}")
logger.info(f"Source table       : {source_table}")
logger.info(f"PostgreSQL host    : {postgres_host}")
logger.info(f"PostgreSQL DB      : {postgres_db}")
logger.info(f"PostgreSQL port    : {postgres_port}")

# Get secrets from AWS Secrets Manager
def get_secret(secret_name):
    try:
        client = boto3.client('secretsmanager', region_name=aws_region)
        response = client.get_secret_value(SecretId=secret_name)
        return json.loads(response['SecretString'])
    except Exception as e:
        logger.error(f"Error retrieving secrets: {e}")
        raise

# Retrieve DB credentials
secrets = get_secret(secret_name)
postgres_user = secrets['POSTGRES_USER']
postgres_password = secrets['POSTGRES_PASSWORD']

# Initialize Spark session
spark = SparkSession.builder \
    .appName("PostgresToS3ETL") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.hadoop.fs.s3a.aws.credentials.provider", "com.amazonaws.auth.DefaultAWSCredentialsProviderChain") \
    .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
    .config("spark.sql.adaptive.enabled", "true") \
    .getOrCreate()

# S3 client
s3_client = boto3.client('s3', region_name=aws_region)

# Read metadata (last processed timestamp)
def read_metadata(bucket, key):
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        return json.loads(obj['Body'].read().decode('utf-8'))['last_timestamp']
    except s3_client.exceptions.NoSuchKey:
        return '1970-01-01'
    except Exception as e:
        logger.error(f"Error reading metadata: {e}")
        raise

# Write metadata to S3
def write_metadata(bucket, key, last_timestamp):
    try:
        metadata = {"last_timestamp": str(last_timestamp), "last_run": datetime.datetime.now().isoformat()}
        s3_client.put_object(Bucket=bucket, Key=key, Body=json.dumps(metadata))
        logger.info("Metadata updated successfully")
    except Exception as e:
        logger.error(f"Error writing metadata: {e}")
        raise

# Read existing S3 partition data
def read_partition_data(spark, path):
    try:
        hadoop_path = spark.sparkContext._jvm.org.apache.hadoop.fs.Path(path)
        fs = spark.sparkContext._jvm.org.apache.hadoop.fs.FileSystem.get(spark.sparkContext._jsc.hadoopConfiguration())
        if not fs.exists(hadoop_path):
            return None
        return spark.read.parquet(path)
    except Exception as e:
        logger.warning(f"Error reading partition data: {e}")
        return None

# Load metadata timestamp
last_processed_timestamp = read_metadata(bucket_name, metadata_key)
logger.info(f"Original last_processed_timestamp from metadata: {last_processed_timestamp}")

# Build JDBC URL and read new data
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
query = f"(SELECT * FROM {source_table} WHERE uploaded_date >= '{last_processed_timestamp}') AS new_data"

logger.info(f"Executing query: {query}")
new_data = spark.read \
    .format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", query) \
    .option("user", postgres_user) \
    .option("password", postgres_password) \
    .option("driver", "org.postgresql.Driver") \
    .load()

row_count = new_data.count()
logger.info(f"Loaded {row_count} new rows from PostgreSQL")

if row_count == 0:
    logger.info("No new data found. Skipping processing.")
    write_metadata(bucket_name, metadata_key, last_processed_timestamp)
    spark.stop()
    sys.exit(0)

# Add partitioning columns
new_data = new_data.withColumn("year", year(col("uploaded_date"))) \
                   .withColumn("week", month(col("uploaded_date")))

# Get affected partitions (year and week only)
affected_partitions = new_data.select("year", "week").distinct().collect()
logger.info(f"Affected partitions: {affected_partitions}")

# Build filter for only affected partitions for efficient S3 read
part_filters = [
    (col("year") == r["year"]) & (col("week") == r["week"])
    for r in affected_partitions
]
if part_filters:
    filter_expr = part_filters[0]
    for f in part_filters[1:]:
        filter_expr = filter_expr | f
else:
    filter_expr = None

# Read only existing data in affected partitions
try:
    all_data_exist = spark.read.parquet(destination_bucket)
    if filter_expr is not None:
        data_exist = all_data_exist.filter(filter_expr)
    else:
        data_exist = spark.createDataFrame([], new_data.schema)
    logger.info(f"Loaded existing data for affected partitions")
except Exception as e:
    logger.warning(f"No existing data found or failed to read: {e}")
    data_exist = spark.createDataFrame([], new_data.schema)

# Union and deduplicate (upsert by id, keep latest uploaded_date)
all_data = new_data.unionByName(data_exist, allowMissingColumns=True)
window = Window.partitionBy("id").orderBy(col("uploaded_date").desc())
all_data_dedup = all_data.withColumn("rn", row_number().over(window)) \
                         .filter(col("rn") == 1) \
                         .drop("rn")

# Write merged data to S3 with dynamic partitioning
logger.info(f"Writing data to {destination_bucket} with dynamic partitioning.")
all_data_dedup.write \
    .mode("overwrite") \
    .partitionBy("year", "week") \
    .parquet(destination_bucket)

# Update metadata with the latest timestamp
new_uploaded_date = new_data.agg(spark_max("uploaded_date")).collect()[0][0]
write_metadata(bucket_name, metadata_key, new_uploaded_date)

# Shutdown
spark.stop()
logger.info("ETL completed successfully. Spark session stopped.")
