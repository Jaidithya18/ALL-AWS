﻿**Incremental and Historical Submissions Data Lake Pipeline Implementation**

**Introduction**

This report outlines the implementation of an incremental and historical submissions data lake pipeline using AWS services. The primary data source is a PostgreSQL database, which stores UEXPERTLY submissions data. The target storage is Amazon S3, where the extracted and transformed data is stored using AWS Glue. This ETL pipeline enables efficient data extraction, transformation, and loading (ETL), ensuring high availability and scalability for data analytics and business insights.

**SUBMISSION-INCREMENTAL FLOW DIAGRAM**

![INCREMENTAL FLOW DIAGRAM](images/submission-incremental-flow-diagram.png)
<br></br>
<br></br>
<br></br>

**SUBMISSION-HISTORICAL FLOW DIAGRAM**

![HISTORICAL FLOW DIAGRAM](images/uexpertly-submission-historical-flowdiagram.png)
<br></br>
<br></br>

**Data Pipeline Workflow:**

**Data Extraction**

AWS Glue connects to the PostgreSQL interviewai_sep database and retrieves records from the submission table.

**GLUE SUBMISSION-INCREMENTAL**

![INCREMENTAL-GLUE](images/submission-incremental-glue.png)
<br></br>
<br></br>
<br></br>

**GLUE SUBMISSION-HISTORICAL**

![HISTORICAL-GLUE](images/submissions-historical-glue-job.png)

**Extracted fields include:**

1.id – Unique submission identifier.

2.approved_on – Date of approval.

3.uploaded_on – Timestamp marking when the submission was recorded.

The pipeline supports both incremental and historical extraction, ensuring efficient data processing.

**2. Data Transformation**

Raw submissions data is processed within Glue using PySpark for scalable transformations.

**Key transformations include:**

Data type standardization (ensuring consistency across fields).

Deduplication (removing duplicate records).

Partitioning by uploaded_on (year/month) to optimize retrieval.

Conversion to Parquet format for efficient querying and storage.

**3. Data Storage**

The transformed data is stored in Amazon S3, structured as follows:

**SUBMISSION-INCREMENTAL-S3**

![INCREMETAL-S3](images/submission-incremental-s3-structure.png)
<br></br>
<br></br>
<br></br>

**SUBMISSION-HISTORICAL-S3**

![HISTORICAL-S3](images/submissions-historical-outputins3.png)

**s3://uexpertly-data-lake/submissions_incremental/year=YYYY/month=MM/**

**Storing data in Parquet format enables:**

Compression benefits, reducing storage costs.

Fast query performance, making data accessible for analytics.

Efficient integration with Athena and Redshift Spectrum.

**4. Data Orchestration**

AWS Step Functions manage the orchestration of Glue jobs.

**SUBMISSION-INCREMENTAL-STEP-FUNCTION**
<br></br>
![STEP FUNCTION-INCREMENTAL](images/submission-incremental-step-function.png)
<br></br>
<br></br>
<br></br>
**SUBMISSION-HISTORICAL-STEP-FUNCTION**
<br></br>
![STEP FUNCTION-HISTORICAL](images/submissions-historical-step-function.png)

**Execution Steps for Historical:**

1.It will create a gluejob and start it.

2.Then it will go to wait state and check for glue job status.

3.Then it will create the glue crawler and start running it.

4.Then we can check the output data by querying in athena.


**Execution flow:**

1.Step Function starts Glue job.

2.Glue reads PostgreSQL data, processes it, and stores the results in S3.

3.Step Function waits for job completion and logs execution details.

**If failures occur:**

1.Retry mechanism is initiated based on failure conditions.

2.Logs are analyzed for debugging.

3.Alerts can be set up using SNS notifications.


**EventBridge's Role in the Pipeline


**AWS EventBridge is leveraged to ensure automated scheduling and event-driven execution of the pipeline. Its key functions include:**

**SUBMISSION-INCREMENTAL-EVENTBRIDGE-NAME**
<br></br>
![EVENTBRIDGE](images/submission-incremental-eventbridge-name.png)


Scheduled Execution of ETL Jobs EventBridge Scheduler triggers Step Functions at scheduled intervals.
Cron Expression: "cron(0 6 * * 4 *)" ensures the pipeline runs daily at 06:00 AM UTC.

**SUBMISSION-INCREMENTAL-EVENTBRIDGE-SCHEDULE**
<br></br>
![EVENTBRIDGES](images/submission-incremental-eventbridge-schedule.png)

Event-Driven Processing Monitors Step Function state transitions to detect job completion.
Can trigger reprocessing in case of failed executions.

Automating Incremental Ingestion Ensures only new and modified records (uploaded_on) are processed.
Works in tandem with metadata stored in S3.

Environment Variables (Bitbucket CI/CD) To secure sensitive configurations, Bitbucket environment variables are used.

**Deployment Process**

**Push to dev →** Triggers Deployment to the Development Environment Deploys Step Function and EventBridge Scheduler for incremental processing.
Updates the uexpertly_submissions_incremental_parameters_dev.json file in S3.

**Push to main →** Triggers Deployment to the Production Environment
Deploys the pipeline to handle historical submissions data.

Ensures all new changes are moved to production seamlessly using uexpertly_submissions_incremental_parameters_prod.json file .

**Each environment manages its own:**

S3 bucket

IAM roles

Glue job resources


**Benefits of the Pipeline:**

**✅ Scalability**

Handles both historical and incremental submissions data efficiently.

Supports parallel execution via AWS Glue and Step Functions, ensuring smooth processing.

**✅ Automation**

AWS Glue automates ETL workflows, reducing manual intervention.

Step Functions orchestrate execution, ensuring jobs run automatically without manual triggers.

**✅ Security & Compliance**

IAM role-based access control ensures secure execution across AWS services.

EventBridge triggers follow a structured scheduling approach, preventing unauthorized data processing.

Complies with data governance best practices, ensuring controlled access and compliance.

**✅ Cost-Effectiveness**

Serverless architecture eliminates infrastructure costs, optimizing resource usage.

Amazon S3 provides low-cost storage, reducing overall operational expenses.

Event-driven execution minimizes idle resources, ensuring efficiency.

**✅ Data Accessibility**

Processed submissions data is stored in S3, easily accessible for downstream analytics.

Glue Data Catalog registers metadata, enabling structured access and optimized querying.

Step Functions ensure visibility into execution logs, helping teams track processing status and debug issues.


**Monitoring and Logging**

**To track pipeline execution, monitoring is enabled in AWS CloudWatch:**

**1. Glue Job Logs**

Detailed logs stored in Amazon CloudWatch Logs.

Useful for debugging data extraction and transformation errors.

**2. Step Function Execution Details**

Managed via the AWS Step Functions Console.

Shows execution history, retries, and failure reasons.

**3. EventBridge Scheduler Monitoring**

Schedule status is reviewed using aws scheduler get-schedule.

Enables tracking of missed executions.

**Summary**

This pipeline enables seamless incremental and historical ingestion of UEXPERTLY submissions data from PostgreSQL to Amazon S3, ensuring efficient analytics and real-time availability for data-driven decision-making. Using AWS Glue, Step Functions, and EventBridge, the pipeline automates extraction, transformation, storage, orchestration, and monitoring, supporting both historical and incremental data ingestion.





