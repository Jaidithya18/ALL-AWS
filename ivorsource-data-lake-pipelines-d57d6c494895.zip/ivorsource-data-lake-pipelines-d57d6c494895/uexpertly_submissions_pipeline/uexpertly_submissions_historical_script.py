from pyspark.sql import SparkSession
import boto3
import json
from awsglue.utils import getResolvedOptions
import sys

# Get script arguments from Glue input
args = getResolvedOptions(sys.argv, [
    'secret_name',
    'aws_region',
    'output_path',
    'source_table',
    'bucket_name',
    'postgres_host',
    'postgres_port',
    'postgres_db'
])

# Extract arguments
secret_name = args['secret_name']
aws_region = args['aws_region']
output_path = args['output_path']
source_table = args['source_table']
bucket_name = args['bucket_name']
postgres_host = args['postgres_host']
postgres_port = args['postgres_port']
postgres_db = args['postgres_db']

# Initialize Spark session
spark = SparkSession.builder \
    .appName("submission_Datalake") \
    .config("spark.jars.packages", "org.postgresql:postgresql:42.7.5") \
    .getOrCreate()

# Fetch secrets from AWS Secrets Manager
def get_secret(secret_name, region_name=aws_region):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

# Get PostgreSQL credentials from Secrets Manager
secrets = get_secret(secret_name)
postgres_user = secrets['POSTGRES_USER']
postgres_password = secrets['POSTGRES_PASSWORD']

# PostgreSQL connection properties
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
properties = {
    "user": postgres_user,
    "password": postgres_password,
    "driver": "org.postgresql.Driver"
}

# Read data from PostgreSQL
df = spark.read.jdbc(url=jdbc_url, table=source_table, properties=properties)

# Write to S3 in Parquet format
df.write.mode("overwrite").parquet(output_path)

# Stop Spark session
spark.stop()
