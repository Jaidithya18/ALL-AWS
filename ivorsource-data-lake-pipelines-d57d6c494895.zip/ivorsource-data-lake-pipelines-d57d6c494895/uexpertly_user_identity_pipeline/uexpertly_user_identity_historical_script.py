import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, max as spark_max, to_date
import boto3
import json
import sys
import datetime

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Function to parse argument value safely
def get_arg_value(arg_name):
    try:
        return args[args.index(arg_name) + 1]
    except (ValueError, IndexError):
        logger.error(f"❌ Missing required argument: {arg_name}")
        sys.exit(1)

# Retrieve and log arguments passed to the script
args = sys.argv
logger.info(f"Arguments received: {args}")

# Parse command-line arguments
secret_name = get_arg_value('--secret_name')
aws_region = get_arg_value('--aws_region')
destination_bucket = get_arg_value('--destination_bucket')  
source_table = get_arg_value('--source_table')
postgres_host = get_arg_value('--postgres_host')
postgres_port = get_arg_value('--postgres_port')
postgres_db = get_arg_value('--postgres_db')
bucket_name = get_arg_value('--bucket_name')

# Log parsed arguments
logger.info(f"Secret name         : {secret_name}")
logger.info(f"AWS region          : {aws_region}")
logger.info(f"Destination bucket  : {destination_bucket}")
logger.info(f"Source table        : {source_table}")
logger.info(f"Postgres host       : {postgres_host}")
logger.info(f"Postgres port       : {postgres_port}")
logger.info(f"Postgres DB         : {postgres_db}")
logger.info(f"Bucket name         : {bucket_name}")

# Initialize Spark session
spark = SparkSession.builder \
    .appName("PostgresToS3Job") \
    .config("spark.jars.packages", "org.postgresql:postgresql:42.2.20") \
    .getOrCreate()

def get_secret(secret_name, region_name=aws_region):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

def get_metadata_key(source_table):
    return f"{source_table}/metadata/last_processed_timestamp.json"

def write_metadata(s3_client, bucket, source_table, last_timestamp):
    metadata_key = get_metadata_key(source_table)
    metadata = {
        "last_timestamp": str(last_timestamp),
        "last_run": datetime.datetime.now().isoformat()
    }
    s3_client.put_object(Bucket=bucket, Key=metadata_key, Body=json.dumps(metadata))
    logger.info(f"✅ Metadata written to S3: s3://{bucket}/{metadata_key}")

# Prepare S3 client
s3_client = boto3.client('s3', region_name=aws_region)

# Get DB credentials
secrets = get_secret(secret_name)

# Construct JDBC URL and properties
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
properties = {
    "user": secrets["POSTGRES_USER"],
    "password": secrets["POSTGRES_PASSWORD"],
    "driver": "org.postgresql.Driver"
}

# Read table from PostgreSQL
logger.info(f"Reading all data from PostgreSQL table: {source_table}")
df = spark.read.jdbc(url=jdbc_url, table=source_table, properties=properties)

count = df.count()
logger.info(f"Number of records to process: {count}")

if count == 0:
    logger.info("No data found. Exiting.")
    spark.stop()
    sys.exit(0)

# Add year and week columns
df = df.withColumn("year", year(to_date(col("modified_at")))) \
       .withColumn("week", weekofyear(to_date(col("modified_at"))))

# Write partitioned by year and week
logger.info(f"Writing data partitioned by year and week to {destination_bucket}")
df.write.mode("append").partitionBy("year", "week").parquet(destination_bucket)

# Write metadata
max_modified_at = df.agg(spark_max(col("modified_at"))).collect()[0][0]
logger.info(f"max_modified_at: {max_modified_at}")
write_metadata(s3_client, bucket_name, source_table, max_modified_at)

# Stop Spark
logger.info("Stopping Spark session")
spark.stop()
logger.info("✅ Full historical load completed successfully")
