import boto3
import json
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, date_trunc, count, countDistinct, sum as _sum, round, lit, first,
    current_timestamp, avg, when
)
from pyspark.sql.types import IntegerType, DoubleType
from pyspark.sql.window import Window
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
import sys
from sqlalchemy import create_engine, text

def create_spark_session():
    return SparkSession.builder \
        .appName("UserKPIIncremental") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

def read_metadata(bucket, key):
    s3 = boto3.client("s3")
    obj = s3.get_object(Bucket=bucket, Key=key)
    content = obj['Body'].read().decode('utf-8')
    metadata = json.loads(content)
    return metadata["last_timestamp"]

def update_metadata(bucket, key, new_timestamp):
    s3 = boto3.client("s3")
    metadata = {
        "last_timestamp": new_timestamp,
        "last_run": datetime.utcnow().isoformat()
    }
    s3.put_object(Bucket=bucket, Key=key, Body=json.dumps(metadata))

def get_secret(secret_name, region_name):
    client = boto3.client('secretsmanager', region_name=region_name)
    secret_string = client.get_secret_value(SecretId=secret_name)['SecretString']
    return json.loads(secret_string)

def transform_data(practice_df, submission_df, resources_df, voicecalls_df):
    practice_df = practice_df.filter(col("email").isNotNull() & col("start_date_time").isNotNull())
    submission_df = submission_df.filter(col("uploaded_by").isNotNull() & col("uploaded_date").isNotNull())
    resources_df = resources_df.filter(col("uploaded_by").isNotNull() & col("uploaded_on").isNotNull())
    voicecalls_df = voicecalls_df.filter(col("student_email").isNotNull() & col("start_time").isNotNull())

    practice_agg = practice_df.groupBy(
        "email", date_trunc("week", "start_date_time").alias("week_start")
    ).agg(
        count("*").alias("total_practicecalls"),
        countDistinct(date_trunc("day", "start_date_time")).alias("total_practicecalls_per_day"),
        round(_sum("total_duration") / (countDistinct(date_trunc("day", "start_date_time")) * 60), 0).alias("avg_duration_practicecalls_per_day"),
        round(count("*") / countDistinct(date_trunc("day", "start_date_time")), 2).alias("avg_practicecalls_per_day"),
        first("user_name").alias("user_name")
    )

    submission_agg = submission_df.groupBy(
        "uploaded_by", date_trunc("week", "uploaded_date").alias("week_start")
    ).agg(
        count("*").alias("total_submissions_week"),
        round(count("*") / countDistinct(date_trunc("day", "uploaded_date")), 2).alias("avg_submissions_per_day")
    )

    resources_agg = resources_df.groupBy(
        "uploaded_by", date_trunc("week", "uploaded_on").alias("week_start")
    ).agg(
        count("*").alias("total_resources_added")
    ).withColumnRenamed("uploaded_by", "email")

    voicecalls_agg = voicecalls_df.groupBy(
        col("student_email").alias("email"), date_trunc("week", "start_time").alias("week_start")
    ).agg(
        count("*").alias("total_voicecalls_received"),
        count(when(col("candidate_response").isNotNull(), True)).alias("total_voicecall_answered"),
        round(avg("score"), 2).alias("voicecall_avg_rating"),
        lit(None).cast(DoubleType()).alias("voicecall_avg_minutes_day")
    )

    all_weeks = practice_agg.select("email", "week_start").union(
        submission_agg.select(col("uploaded_by").alias("email"), "week_start")
    ).union(
        resources_agg.select("email", "week_start")
    ).union(
        voicecalls_agg.select("email", "week_start")
    ).distinct()

    practice_complete = all_weeks.join(practice_agg, ["email", "week_start"], "left").fillna(0)

    submission_complete = all_weeks.join(
        submission_agg,
        (all_weeks.email == submission_agg.uploaded_by) & (all_weeks.week_start == submission_agg.week_start),
        "left"
    ).select(
        all_weeks.email,
        all_weeks.week_start,
        submission_agg.total_submissions_week,
        submission_agg.avg_submissions_per_day
    ).fillna(0)

    result_df = practice_complete \
        .join(submission_complete, ["email", "week_start"], "left") \
        .join(resources_agg, ["email", "week_start"], "left") \
        .join(voicecalls_agg, ["email", "week_start"], "left") \
        .fillna(0)

    result_df = result_df.withColumn(
        "user_name",
        first("user_name", ignorenulls=True).over(
            Window.partitionBy("email").orderBy("week_start").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
        )
    ).filter(col("email").isNotNull() & col("week_start").isNotNull())

    return result_df.select(
        "user_name", "email", "week_start",
        "total_practicecalls", "total_practicecalls_per_day",
        "avg_duration_practicecalls_per_day", "avg_practicecalls_per_day",
        "total_submissions_week", "avg_submissions_per_day",
        col("total_resources_added").cast(IntegerType()),
        col("total_voicecalls_received").cast(IntegerType()),
        col("total_voicecall_answered").cast(IntegerType()),
        col("voicecall_avg_rating").cast(DoubleType()),
        col("voicecall_avg_minutes_day").cast(DoubleType()),
        lit(None).cast(IntegerType()).alias("total_reactions_given")
    )

def write_with_merge(df, postgres_config, secret):
    url = f"jdbc:postgresql://{postgres_config['dbhost']}:{postgres_config['dbport']}/{postgres_config['dbname']}"
    props = {
        "user": secret['POSTGRES_USER'],
        "password": secret['POSTGRES_PASSWORD'],
        "driver": "org.postgresql.Driver",
        "stringtype": "unspecified"
    }

    staging_table = postgres_config.get("staging_table", "user_profile_metric_staging")
    main_table = postgres_config['dbtable']

    engine = create_engine(f"postgresql+psycopg2://{props['user']}:{props['password']}@{postgres_config['dbhost']}:{postgres_config['dbport']}/{postgres_config['dbname']}")

    with engine.connect() as conn:
        conn.execute(text(f"DROP TABLE IF EXISTS {staging_table};"))
        conn.execute(text(f"CREATE TABLE {staging_table} (LIKE {main_table} INCLUDING ALL);"))

    df.write.mode("append").jdbc(url=url, table=staging_table, properties=props)

    merge_sql = f"""
        INSERT INTO {main_table} AS main
        SELECT * FROM {staging_table}
        ON CONFLICT (email, week_start)
        DO UPDATE SET
            user_name = EXCLUDED.user_name,
            total_practicecalls = EXCLUDED.total_practicecalls,
            total_practicecalls_per_day = EXCLUDED.total_practicecalls_per_day,
            avg_duration_practicecalls_per_day = EXCLUDED.avg_duration_practicecalls_per_day,
            avg_practicecalls_per_day = EXCLUDED.avg_practicecalls_per_day,
            total_submissions_week = EXCLUDED.total_submissions_week,
            avg_submissions_per_day = EXCLUDED.avg_submissions_per_day,
            total_resources_added = EXCLUDED.total_resources_added,
            total_voicecalls_received = EXCLUDED.total_voicecalls_received,
            total_voicecall_answered = EXCLUDED.total_voicecall_answered,
            voicecall_avg_rating = EXCLUDED.voicecall_avg_rating,
            voicecall_avg_minutes_day = EXCLUDED.voicecall_avg_minutes_day,
            total_reactions_given = EXCLUDED.total_reactions_given;
    """

    with engine.connect() as conn:
        conn.execute(text(merge_sql))
        conn.execute(text(f"DROP TABLE IF EXISTS {staging_table};"))

def main():
    args = getResolvedOptions(sys.argv, [
        'input_config', 'postgres_config', 'secret_name', 'region_name'
    ])

    spark = create_spark_session()
    glueContext = GlueContext(spark.sparkContext)

    input_config = json.loads(args['input_config'])
    postgres_config = json.loads(args['postgres_config'])
    secret_name = args['secret_name']
    region_name = args['region_name']

    last_ts_sub = read_metadata(input_config['submissions_metadata_bucket'], input_config['submissions_metadata_key'])
    last_ts_prac = read_metadata(input_config['practicecalls_metadata_bucket'], input_config['practicecalls_metadata_key'])
    last_ts_res = read_metadata(input_config['resources_metadata_bucket'], input_config['resources_metadata_key'])
    last_ts_vc = read_metadata(input_config['voicecalls_metadata_bucket'], input_config['voicecalls_metadata_key'])

    submissions_df = glueContext.create_dynamic_frame.from_catalog(
        database=input_config['glue_database'],
        table_name=input_config['submissions_table']
    ).toDF().filter((col("uploaded_date") > last_ts_sub) & (col("uploaded_date") <= current_timestamp()))

    practicecalls_df = glueContext.create_dynamic_frame.from_catalog(
        database=input_config['glue_database'],
        table_name=input_config['practicecalls_table']
    ).toDF().filter((col("start_date_time") > last_ts_prac) & (col("start_date_time") <= current_timestamp()))

    resources_df = glueContext.create_dynamic_frame.from_catalog(
        database=input_config['glue_database'],
        table_name=input_config['resources_table']
    ).toDF().filter((col("uploaded_on") > last_ts_res) & (col("uploaded_on") <= current_timestamp()))

    voicecalls_df = glueContext.create_dynamic_frame.from_catalog(
        database=input_config['glue_database'],
        table_name=input_config['voicecalls_table']
    ).toDF().filter((col("start_time") > last_ts_vc) & (col("start_time") <= current_timestamp()))

    result_df = transform_data(practicecalls_df, submissions_df, resources_df, voicecalls_df)
    secret = get_secret(secret_name, region_name)

    if result_df.count() > 0:
        write_with_merge(result_df, postgres_config, secret)

        if not submissions_df.rdd.isEmpty():
            max_sub = submissions_df.agg({"uploaded_date": "max"}).collect()[0][0]
            update_metadata(input_config['submissions_metadata_bucket'], input_config['submissions_metadata_key'], str(max_sub))

        if not practicecalls_df.rdd.isEmpty():
            max_prac = practicecalls_df.agg({"start_date_time": "max"}).collect()[0][0]
            update_metadata(input_config['practicecalls_metadata_bucket'], input_config['practicecalls_metadata_key'], str(max_prac))

        if not resources_df.rdd.isEmpty():
            max_res = resources_df.agg({"uploaded_on": "max"}).collect()[0][0]
            update_metadata(input_config['resources_metadata_bucket'], input_config['resources_metadata_key'], str(max_res))

        if not voicecalls_df.rdd.isEmpty():
            max_vc = voicecalls_df.agg({"start_time": "max"}).collect()[0][0]
            update_metadata(input_config['voicecalls_metadata_bucket'], input_config['voicecalls_metadata_key'], str(max_vc))

    spark.stop()

if __name__ == '__main__':
    main()
