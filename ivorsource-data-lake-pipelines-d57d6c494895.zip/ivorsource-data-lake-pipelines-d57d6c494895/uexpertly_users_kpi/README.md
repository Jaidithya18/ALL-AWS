**Users KPI Pipeline**

***Introduction***

This project implements a scalable data transformation pipeline using AWS Glue and PySpark. The pipeline ingests parquet-formatted data from Amazon S3, performs complex weekly aggregations across multiple datasets (practice calls, submissions, resources, and voice calls), and writes the transformed data into a PostgreSQL database.  
Key features of this pipeline include:

* Serverless execution via AWS Glue.  
* Secure credential management using AWS Secrets Manager.  
* Robust data transformations with PySpark, leveraging aggregation, window functions, and joins.  
* Error handling and safe filtering to ensure clean, high-quality output.

The pipeline is designed to be triggered automatically with job parameters passed through AWS Glue jobs or Step Functions, making it highly adaptable for production environments.

***Prerequisites*** 

1) Postgres Database  
2) Glue  
3) Secrets Manager  
4) S3  
5) Step Functions  
6) Event Bridge  
     
   

***Flow chart***

![Snapshot of flowchart](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/78f8ab45c17deceaa1fc30d37c602cd4943c43ad/uexpertly_users_kpi/Images/flowchart.png)

***Data Pipeline Architecture***

* **AWS Glue Job**: Orchestrates the entire ETL workflow.  
* **AWS Secrets Manager:**  
  * Stores PostgreSQL credentials securely.  
  * Credentials are retrieved during job execution.  
* **Amazon S3:**  
  * Source storage for four datasets (Practice Calls, Submissions, Resources, Voice Calls) in Parquet format.  
* **PySpark (within AWS Glue):**  
  * Reads multiple datasets from S3.  
  * Performs transformations:  
    * Weekly aggregations.  
    * Joins across datasets based on common keys.  
    * Cleans and handles missing/null data.  
* **PostgreSQL Database:**  
  * Destination where the transformed data is inserted into a production table.  
* **Trigger Options:**  
  * Scheduled trigger (cron-like)  
* **End Process:**  
  * Successful data write to PostgreSQL.  
  * Glue job ends after clean execution.

***What the Pipeline Is Doing (High Level)***

* Triggered via AWS Glue  
* Securely fetches database credentials from AWS Secrets Manager.  
* Reads four datasets (Practice Calls, Submissions, Resources, Voice Calls) from Amazon S3 (in Parquet format).  
* Performs transformations on the data using PySpark:  
  * Cleans and filters raw data.  
  * Aggregates data on a weekly basis.  
  * Joins different datasets together to build a complete view.  
* Prepares a final transformed dataset ready for analytics/reporting.  
* Connects to PostgreSQL using credentials.  
* Inserts the transformed data into a specific PostgreSQL table.

***What the Script Is Doing*** 

* Initializes Spark session inside AWS Glue.  
* Fetches credentials (username, password, endpoint, etc.) securely from AWS Secrets Manager.  
* Reads Parquet files from S3 buckets for:  
  * Practice Calls  
  * Submissions  
  * Resources  
  * Voice Calls  
* Applies transformations:  
  * Aggregates metrics (like call counts, submission rates, resource usage) on a weekly basis.  
  * Performs joins across datasets based on user IDs or session IDs.  
  * Handles missing/null values to prevent dirty data insertions.  
* Creates a unified PySpark DataFrame with all necessary fields for reporting.  
* Establishes JDBC connection to PostgreSQL using the fetched credentials.  
* Writes the final DataFrame into a target table in PostgreSQL.  
* Stops the Spark context after successful completion.
![Snapshot of data being loaded into postgresql](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/78f8ab45c17deceaa1fc30d37c602cd4943c43ad/uexpertly_users_kpi/Images/postgresdata.png)

***Snapshot of data being loaded into Postgresql***
![Snapshot of data being loaded into postgresql](https://bitbucket.org/ivorsource/data-lake-pipelines/raw/78f8ab45c17deceaa1fc30d37c602cd4943c43ad/uexpertly_users_kpi/Images/successgluejob.png)

***Snapshot of glue job running successfully*** 