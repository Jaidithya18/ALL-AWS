import boto3
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_trunc, count, countDistinct, sum as _sum, round, lit, first, avg, when
from pyspark.sql.types import IntegerType, DoubleType, StringType, TimestampType, LongType
from pyspark.sql.window import Window
from botocore.exceptions import ClientError
from awsglue.utils import getResolvedOptions
import sys

def create_spark_session():
    """Create and return a Spark session"""
    return SparkSession.builder \
        .appName("GlueParquetReader") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

def get_secret(secret_name, region_name, secrets_client=None):
    """Retrieve secrets from AWS Secrets Manager"""
    try:
        client = secrets_client or boto3.session.Session().client(
            service_name='secretsmanager',
            region_name=region_name
        )
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return json.loads(secret)
        else:
            raise Exception("Secret not in string format")
    except ClientError as e:
        raise e

def transform_data(practice_df, submission_df, resources_df, voicecalls_df):
    """
    Perform data transformations on the input DataFrames with proper weekly alignment
    """
    # Filter out records with null email and date values from all input DataFrames
    practice_df = practice_df.filter(
        col("email").isNotNull() & 
        col("start_date_time").isNotNull()
    )
    submission_df = submission_df.filter(
        col("uploaded_by").isNotNull() & 
        col("uploaded_date").isNotNull()
    )
    resources_df = resources_df.filter(
        col("uploaded_by").isNotNull() & 
        col("uploaded_on").isNotNull()
    )
    voicecalls_df = voicecalls_df.filter(
        col("student_email").isNotNull() & 
        col("start_time").isNotNull()
    )
    
    # Transform practice call data - group by email and week
    practice_agg = practice_df.groupBy(
        "email", date_trunc("week", "start_date_time").alias("week_start")
    ).agg(
        count("*").alias("total_practicecalls"),
        countDistinct(date_trunc("day", "start_date_time")).alias("total_practicecalls_per_day"),
        round(_sum("total_duration") / (countDistinct(date_trunc("day", "start_date_time")) * 60), 0).alias("avg_duration_practicecalls_per_day"),
        round(count("*") / countDistinct(date_trunc("day", "start_date_time")), 2).alias("avg_practicecalls_per_day"),
        first("user_name").alias("user_name")
    )
    
    # Transform submission data - group by email and week
    submission_agg = submission_df.groupBy(
        "uploaded_by", date_trunc("week", "uploaded_date").alias("week_start")
    ).agg(
        count("*").alias("total_submissions_week"),
        round(count("*") / countDistinct(date_trunc("day", "uploaded_date")), 2).alias("avg_submissions_per_day")
    )
    
    # Transform resources data - group by uploaded_by and week (using uploaded_on)
    resources_agg = resources_df.groupBy(
        "uploaded_by", date_trunc("week", "uploaded_on").alias("week_start")
    ).agg(
        count("*").alias("total_resources_added")
    )
    
    # Transform voice calls data - group by student_email and week
    voicecalls_agg = voicecalls_df.groupBy(
        col("student_email").alias("email"), 
        date_trunc("week", col("start_time")).alias("week_start")
    ).agg(
        count("*").alias("total_voicecalls_received"),
        count(when(col("candidate_response").isNotNull(), True)).alias("total_voicecall_answered"),
        avg("score").alias("voicecall_avg_rating"),
        lit(None).cast(DoubleType()).alias("voicecall_avg_minutes_day")
    )
    
    # Create a complete set of weeks for each user to ensure all weeks are represented
    all_weeks = practice_agg.select("email", "week_start").union(
        submission_agg.select(col("uploaded_by").alias("email"), "week_start")
    ).union(
        resources_agg.select(col("uploaded_by").alias("email"), "week_start")
    ).union(
        voicecalls_agg.select("email", "week_start")
    ).distinct().filter(
        col("email").isNotNull() & 
        col("week_start").isNotNull()
    )
    
    # Left join practice data to all weeks
    practice_complete = all_weeks.join(
        practice_agg,
        ["email", "week_start"],
        "left"
    ).fillna(0, subset=["total_practicecalls", "total_practicecalls_per_day"])
    
    # Left join submission data to all weeks
    submission_complete = all_weeks.join(
        submission_agg,
        (all_weeks.email == submission_agg.uploaded_by) & 
        (all_weeks.week_start == submission_agg.week_start),
        "left"
    ).select(
        all_weeks["email"],
        all_weeks["week_start"],
        submission_agg["total_submissions_week"],
        submission_agg["avg_submissions_per_day"]
    ).fillna(0, subset=["total_submissions_week"])
    
    # Left join resources data to all weeks
    resources_complete = all_weeks.join(
        resources_agg,
        (all_weeks.email == resources_agg.uploaded_by) & 
        (all_weeks.week_start == resources_agg.week_start),
        "left"
    ).select(
        all_weeks["email"],
        all_weeks["week_start"],
        resources_agg["total_resources_added"]
    ).fillna(0, subset=["total_resources_added"])
    
    # Left join voice calls data to all weeks
    voicecalls_complete = all_weeks.join(
        voicecalls_agg,
        ["email", "week_start"],
        "left"
    ).fillna(0, subset=["total_voicecalls_received", "total_voicecall_answered"])
    
    # Final join with forward fill for user_name
    result_df = practice_complete.join(
        submission_complete,
        ["email", "week_start"],
        "left"
    ).join(
        resources_complete,
        ["email", "week_start"],
        "left"
    ).join(
        voicecalls_complete,
        ["email", "week_start"],
        "left"
    ).withColumn(
        "user_name",
        first("user_name", ignorenulls=True).over(
            Window.partitionBy("email").orderBy("week_start")
            .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )
    ).filter(
        col("email").isNotNull() & 
        col("week_start").isNotNull()
    )
    
    # Select and order the columns
    result_df = result_df.select(
        "user_name",
        "email",
        "week_start",
        "total_practicecalls",
        "total_practicecalls_per_day",
        "avg_duration_practicecalls_per_day",
        "avg_practicecalls_per_day",
        "total_submissions_week",
        "avg_submissions_per_day",
        "total_resources_added",
        "total_voicecalls_received",
        "total_voicecall_answered",
        "voicecall_avg_rating",
        "voicecall_avg_minutes_day",
        lit(None).cast(IntegerType()).alias("total_reactions_given")
    ).orderBy("week_start", "email")
    
    return result_df

def write_to_postgres(df, postgres_config, secret_name, region_name):
    """Write DataFrame to PostgreSQL"""
    try:
        # Get only username and password from Secrets Manager
        secret = get_secret(secret_name, region_name)
        
        postgres_url = f"jdbc:postgresql://{postgres_config['dbhost']}:{postgres_config['dbport']}/{postgres_config['dbname']}"
        postgres_properties = {
            "user": secret['POSTGRES_USER'],
            "password": secret['POSTGRES_PASSWORD'],
            "driver": "org.postgresql.Driver",
            "stringtype": "unspecified"
        }

        # Final filter to ensure no null emails or week_start values
        df = df.filter(
            col("email").isNotNull() & 
            col("week_start").isNotNull()
        )
        
        df.write \
            .mode(postgres_config.get("write_mode", "overwrite")) \
            .option("truncate", str(postgres_config.get("truncate", "true")).lower()) \
            .option("batchsize", postgres_config.get("batchsize", 10000)) \
            .jdbc(
                url=postgres_url, 
                table=postgres_config['dbtable'], 
                properties=postgres_properties
            )
    except Exception as e:
        raise

def read_data_from_folder(spark, folder_uri):
    """Read all parquet files from a folder"""
    try:
        return spark.read.parquet(folder_uri)
    except Exception as e:
        raise

def process_data(spark, input_config, postgres_config, secret_name, region_name):
    """Process data from specified folders"""
    try:
        practice_df = read_data_from_folder(spark, input_config['practice_folder'])
        submission_df = read_data_from_folder(spark, input_config['submission_folder'])
        resources_df = read_data_from_folder(spark, input_config['resources_folder'])
        voicecalls_df = read_data_from_folder(spark, input_config['voicecalls_folder'])
        transformed_df = transform_data(practice_df, submission_df, resources_df, voicecalls_df)
        write_to_postgres(transformed_df, postgres_config, secret_name, region_name)
    except Exception as e:
        raise

def main():
    """Main entry point for the script"""
    spark = create_spark_session()
    try:
        # Get parameters from Glue job arguments (passed from Step Functions)
        args = getResolvedOptions(sys.argv, [
            'input_config',
            'postgres_config',
            'secret_name',
            'region_name'
        ])
        
        input_config = json.loads(args['input_config'])
        postgres_config = json.loads(args['postgres_config'])
        secret_name = args['secret_name']
        region_name = args['region_name']
        
        process_data(spark, input_config, postgres_config, secret_name, region_name)
    except Exception as e:
        raise
    finally:
        spark.stop()

if __name__ == "__main__":
    main()