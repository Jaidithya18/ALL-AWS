import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, max as spark_max, to_date
import boto3
import json
import sys

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Retrieve and parse arguments from command line
args = sys.argv
logger.info(f"Arguments received: {args}")

try:
    secret_name = args[args.index('--secret_name') + 1]
    aws_region = args[args.index('--aws_region') + 1]
    destination_bucket = args[args.index('--destination_bucket') + 1]  # e.g. s3://my-bucket/path/
    source_table = args[args.index('--source_table') + 1]
    postgres_host = args[args.index('--postgres_host') + 1]
    postgres_port = args[args.index('--postgres_port') + 1]
    postgres_db = args[args.index('--postgres_db') + 1]
    bucket_name = args[args.index('--bucket_name') + 1]
    metadata_key = args[args.index('--metadata_key') + 1]
    metadata_file_path = args[args.index('--metadata_file_path') + 1]
    
except (ValueError, IndexError) as e:
    logger.error("Error parsing arguments: ", exc_info=e)
    sys.exit(1)

logger.info(f"Secret name         : {secret_name}")
logger.info(f"AWS region          : {aws_region}")
logger.info(f"Destination bucket  : {destination_bucket}")
logger.info(f"Source table        : {source_table}")
logger.info(f"Postgres host       : {postgres_host}")
logger.info(f"Postgres port       : {postgres_port}")
logger.info(f"Postgres DB         : {postgres_db}")

# Initialize Spark session
spark = SparkSession.builder \
    .appName("FullLoad_Datalake") \
    .config("spark.jars.packages", "org.postgresql:postgresql:42.2.20") \
    .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
    .getOrCreate()

# Fetch secrets from Secrets Manager
def get_secret(secret_name, region_name=aws_region):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

# Optional: Write metadata (e.g., max uploaded_on)
def get_metadata_key(source_table):
    return f"{source_table}/metadata/last_processed_timestamp.json"

def write_metadata(s3_client, bucket, source_table, last_timestamp):
    import datetime
    metadata_key = get_metadata_key(source_table)
    metadata = {
        "last_timestamp": str(last_timestamp),
        "last_run": datetime.datetime.now().isoformat()
    }
    s3_client.put_object(Bucket=bucket, Key=metadata_key, Body=json.dumps(metadata))
    logger.info(f"✅ Metadata written to S3: s3://{bucket}/{metadata_key}")

# Prepare S3 client
s3_client = boto3.client('s3', region_name=aws_region)
bucket_name_only = bucket_name

# Get DB credentials from secret
secrets = get_secret(secret_name)

# Construct JDBC URL and properties
jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
properties = {
    "user": secrets["POSTGRES_USER"],
    "password": secrets["POSTGRES_PASSWORD"],
    "driver": "org.postgresql.Driver"
}

# Read entire table from PostgreSQL
logger.info(f"Reading all data from PostgreSQL table: {source_table}")
df = spark.read.jdbc(url=jdbc_url, table=source_table, properties=properties)

count = df.count()
logger.info(f"Number of records to process: {count}")

if count == 0:
    logger.info("No data found. Exiting.")
    spark.stop()
    sys.exit(0)

# Add year and week columns based on uploaded_on
df = df.withColumn("year", year(to_date(col("uploaded_on")))) \
       .withColumn("week", weekofyear(to_date(col("uploaded_on"))))

# Write data partitioned by year and week
logger.info(f"Writing data partitioned by year and week to {destination_bucket}")
df.write.mode("append").partitionBy("year", "week").parquet(destination_bucket)

# Optional: Write metadata
max_uploaded_on = df.agg(spark_max(col("uploaded_on"))).collect()[0][0]
logger.info(f"max_uploaded_on: {max_uploaded_on}")
write_metadata(s3_client, bucket_name_only, source_table, max_uploaded_on)

# Stop Spark
logger.info("Stopping Spark session")
spark.stop()
logger.info("Full historical load completed successfully ✅")
