# UExpertly Resources Pipeline

This repository contains two AWS data pipelines for managing **resources data** from a PostgreSQL database into an S3 data lake, making it queryable through Athena. The pipelines include:

- **Historical Pipeline**: A one-time bulk load of historical data.
- **Incremental Pipeline**: A scheduled pipeline that processes new/updated data weekly.


##  Architecture Overview

![Historical Flow Diagram](images/resources_historical_flowchart.jpg)

![Incremental_Flow Diagram](images/resources_incremental_flowchart.jpg)


### 📜 Historical Pipeline

**Purpose**: Load all historical resources data from PostgreSQL to the raw layer in S3 and make it queryable via Athena.

**Flow**:
## Pipeline Components & Flow

- **CI/CD Pipelines**
  - Triggers the AWS Step Function execution automatically.

- **AWS Step Functions**
  - Orchestrates the pipeline flow.
  - Initiates the AWS Glue ETL job.

- **AWS Glue (ETL Jobs + Crawlers)**
  - **ETL Job**: Executes the `uexpertly_resource_historical_script.py` script from S3.
  - **Source**: Extracts data from **PostgreSQL**.
  - **Target**: Writes transformed data to the **raw S3 bucket**.
  - **Glue Crawler**: Catalogs the data written to S3.

- **Amazon S3**
  - Serves as the data lake storage layer for raw and transformed data.

- **AWS Glue Data Catalog**
  - Updated by the Glue Crawler to reflect new or changed data schemas.

- **Amazon Athena**
  - Enables querying of the data stored in S3 using standard SQL.

- **Amazon EventBridge**
  - (Optional) Can be used to schedule or trigger pipeline executions.

- **PostgreSQL**
  - Source system from which data is extracted.


![Historical Stepfunction](images/resource_historical_stepfunction.jpg)

![Historical Data](images/resource_historical_data.jpg)

---

### 🔁 Incremental Pipeline

**Purpose**: Load new or updated records from PostgreSQL to S3 **incrementally** on a scheduled basis.

**Flow**:
## Incremental Load Flow

- **Amazon EventBridge**
  - An **EventBridge Rule** is created by the **CI/CD pipeline**.
  - It triggers the Step Function **every Thursday at 7:00 PM**.

- **AWS Step Functions**
  - Orchestrates the incremental pipeline steps.
  - Executes the AWS Glue job:  
    `uexpertly_resource_incremental_script.py`.

- **AWS Glue (ETL Job)**
  - Connects to **PostgreSQL** to read only new or changed data.
  - Writes data to **Amazon S3** in a **partitioned format**:  
    `year/week`.

- **Amazon S3**
  - Stores the partitioned incremental data for further processing or querying.


![Incremental Stepfunction](images/resource_incremental_stepfinction.jpg)

![Incremental Data](images/resource_incremental_data.jpg)

## 🛠️ Technologies Used

- **AWS Step Functions**
- **AWS Glue (ETL Jobs + Crawlers)**
- **Amazon S3**
- **Amazon Athena**
- **Amazon EventBridge**
- **PostgreSQL**
- **CI/CD Pipelines**

---

## 📅 Schedule

- **Incremental Pipeline Trigger**: Every **Thursday at 7:00 PM** via EventBridge.

---

## 📌 Notes

- Ensure that the Glue scripts and configuration JSONs are kept in sync with environment-specific deployments (dev/prod).
- Make sure the IAM roles for Glue, Step Functions, and EventBridge have the appropriate permissions.