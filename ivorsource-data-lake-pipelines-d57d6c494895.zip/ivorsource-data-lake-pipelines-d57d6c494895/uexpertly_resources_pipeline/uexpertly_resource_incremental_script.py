import sys
import boto3
import json
import logging
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, year, weekofyear, max as spark_max, to_date, row_number
from pyspark.sql.window import Window

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_args():
    args = sys.argv
    return {
        'secret_name': args[args.index('--secret_name') + 1],
        'aws_region': args[args.index('--aws_region') + 1],
        'destination_bucket': args[args.index('--destination_bucket') + 1],
        'source_table': args[args.index('--source_table') + 1],
        'bucket_name': args[args.index('--bucket_name') + 1],
        'metadata_key': args[args.index('--metadata_key') + 1],
        'metadata_file_path': args[args.index('--metadata_file_path') + 1],
        'postgres_host': args[args.index('--postgres_host') + 1],
        'postgres_db': args[args.index('--postgres_db') + 1],
        'postgres_port': args[args.index('--postgres_port') + 1]
    }

def get_secret(secret_name, region):
    try:
        client = boto3.client('secretsmanager', region_name=region)
        response = client.get_secret_value(SecretId=secret_name)
        return json.loads(response['SecretString'])
    except Exception as e:
        logger.error(f"Error retrieving secrets: {e}")
        raise

def initialize_spark():
    return SparkSession.builder \
        .appName("IncrementalLoadWithUpsert") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "com.amazonaws.auth.DefaultAWSCredentialsProviderChain") \
        .config("spark.hadoop.fs.s3a.endpoint", "s3.amazonaws.com") \
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
        .config("spark.sql.files.maxPartitionBytes", "128MB") \
        .config("spark.sql.adaptive.enabled", "true") \
        .config("spark.dynamicAllocation.enabled", "false") \
        .config("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol") \
        .getOrCreate()

def read_metadata(s3_client, bucket, metadata_key):
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=metadata_key)
        timestamp = json.loads(obj['Body'].read().decode('utf-8'))['last_timestamp']
        logger.info(f"✅ Read last processed timestamp from S3: {timestamp}")
        return timestamp
    except s3_client.exceptions.NoSuchKey:
        logger.warning("⚠️ Metadata not found in S3. Using default timestamp.")
        return '1970-01-01 00:00:00'
    except Exception as e:
        logger.error(f"Error reading metadata: {e}")
        raise

def write_metadata(s3_client, bucket, metadata_key, last_timestamp):
    metadata = {
        "last_timestamp": str(last_timestamp),
        "last_run": datetime.datetime.now().isoformat()
    }
    s3_client.put_object(Bucket=bucket, Key=metadata_key, Body=json.dumps(metadata))
    logger.info(f"✅ Metadata written to S3: s3://{bucket}/{metadata_key}")

def main():
    args = parse_args()
    for key, value in args.items():
        logger.info(f"{key}: {value}")

    s3_client = boto3.client('s3', region_name=args['aws_region'])

    try:
        secrets = get_secret(args['secret_name'], args['aws_region'])
        postgres_user = secrets['POSTGRES_USER']
        postgres_password = secrets['POSTGRES_PASSWORD']

        spark = initialize_spark()

        last_processed_timestamp = read_metadata(s3_client, args['bucket_name'], args['metadata_key'])

        jdbc_url = f"jdbc:postgresql://{args['postgres_host']}:{args['postgres_port']}/{args['postgres_db']}"
        properties = {
            "user": postgres_user,
            "password": postgres_password,
            "driver": "org.postgresql.Driver"
        }

        # Read only new or updated rows after last_processed_timestamp
        query = f"""
        (
            SELECT * FROM {args['source_table']}
            WHERE last_modified_on > '{last_processed_timestamp}'
        ) AS new_data
        """
        logger.info(f"Running incremental query: {query}")

        new_data = spark.read \
            .format("jdbc") \
            .option("url", jdbc_url) \
            .option("dbtable", query) \
            .option("user", properties["user"]) \
            .option("password", properties["password"]) \
            .option("driver", properties["driver"]) \
            .load()

        total_count = new_data.count()
        logger.info(f"Total new or updated records from PostgreSQL: {total_count}")

        if total_count == 0:
            logger.info("No new data found. Skipping processing.")
            write_metadata(s3_client, args['bucket_name'], args['metadata_key'], last_processed_timestamp)
        else:
            # Add partition columns (year and week) based on last_modified_on column
            new_data = new_data.withColumn("year", year(to_date(col("last_modified_on")))) \
                               .withColumn("week", weekofyear(to_date(col("last_modified_on"))))

            # Identify affected partitions
            affected_partitions = new_data.select("year", "week").distinct().collect()
            logger.info(f"Affected partitions: {affected_partitions}")

            # Build filter for affected partitions
            part_filters = [
                (col("year") == r["year"]) & (col("week") == r["week"])
                for r in affected_partitions
            ]
            if part_filters:
                filter_expr = part_filters[0]
                for f in part_filters[1:]:
                    filter_expr = filter_expr | f
            else:
                filter_expr = None

            # Read existing data for affected partitions only
            try:
                all_data_exist = spark.read.parquet(args['destination_bucket'])
                if filter_expr is not None:
                    data_exist = all_data_exist.filter(filter_expr)
                else:
                    # No partitions affected, create empty dataframe with schema
                    data_exist = spark.createDataFrame([], new_data.schema)
                logger.info(f"Loaded existing data for affected partitions")
            except Exception as e:
                logger.warning(f"No existing data found or failed to read existing data: {e}")
                data_exist = spark.createDataFrame([], new_data.schema)

            # Union new data and existing data and perform upsert (keep latest last_modified_on)
            all_data = new_data.unionByName(data_exist, allowMissingColumns=True)

            window = Window.partitionBy("id").orderBy(col("last_modified_on").desc())
            all_data_dedup = all_data.withColumn("rn", row_number().over(window)) \
                                     .filter(col("rn") == 1) \
                                     .drop("rn")

            # Write upserted data back to S3, partitioned by year and week
            all_data_dedup.write \
                .mode("overwrite") \
                .option("partitionOverwriteMode", "dynamic") \
                .partitionBy("year", "week") \
                .parquet(args['destination_bucket'])

            logger.info("✅ Written upserted data to S3")

            # Update metadata with the max last_modified_on from new data
            new_last_modified_on = new_data.agg(spark_max(col("last_modified_on"))).collect()[0][0]
            write_metadata(s3_client, args['bucket_name'], args['metadata_key'], new_last_modified_on)

    except Exception as e:
        logger.error(f"❌ Error: {e}")
        raise
    finally:
        if 'spark' in locals():
            spark.stop()
            logger.info("Spark session stopped")

if __name__ == "__main__":
    main()
