I have been a Data Engineer and have witnessed the evolution of Big Data and how data can impact organizations and businesses. During this period, Iíve got solid hands-on experience in building scalable and efficient data pipelines using tools like Spark, Hive, Airflow, EMR, Glue, and Redshift. Iíve worked on multiple projects where Iíve designed and implemented end-to-end data workflows that can handle large volumes of data smoothly.
Iím quite comfortable working with Spark, both in Scala and Python. I have a deep understanding of Sparkís internalsólike RDDs, DataFrames, and Spark SQLóand have used these to build reliable and high-performing pipelines. Along with Spark, Iíve also worked a lot with Hive, Redshift, and Athena, which helps me manage both structured and semi-structured data effectively. Iím good at writing complex queries, fine-tuning them for performance, and making sure data is clean and accurate.
When it comes to workflow orchestration, Iíve been using Apache Airflow extensively to schedule and monitor batch pipelines. I also have strong experience with cloud platformsóespecially AWS, where Iíve used EMR, Glue, Lambda, and Redshift.and azure as well with HDInsight and Data factory. Yeah, so this is pretty much about me.


Current Project:
I am currently working at H.E.B., a leading retail company with over 400 stores across the states. In my role as a Senior Data Engineer, I lead the development of robust and scalable data lake pipelines designed to support enterprise-wide analytics, machine learning initiatives, and business reporting.
We have multiple data sourcesófirst, Amazon S3, which contains SAS and CSV files with historical reports; second, a PostgreSQL database that stores real-time transactional sales data; and third, internal REST APIs that provide up-to-date product hierarchy and metadata.
In the Bronze Layer, I handle raw ingestion, parsing complex formats like SAS, normalizing.
The Silver Layer focuses on data cleansing, standardization, and applying business logic through Spark transformationsójoining product, brand, and sales datasets.
Gold Layer, I deliver curated, partitioned Parquet datasets optimized for downstream analytics teams, enabling insights through tools like Athena and feeding ML models.
 I orchestrate workflows via Apache Airflow on AWS MWAA, monitor with CloudWatch and Slack integrations, and automate CI/CD using Bitbucket Pipelines and AWS CLI.
These outputs are consumed by data scientists for demand forecasting, BI analysts for dashboarding. Thats overview of recent project.


Introduction:
I have been a Data Engineer and have witnessed the evolution of Big Data and how data can impact organizations and businesses. During this period, I�ve got solid hands-on experience in building scalable and efficient data pipelines using tools like Spark, Hive, Airflow, EMR, Glue, and Redshift. I�ve worked on multiple projects where I�ve designed and implemented end-to-end data workflows that can handle large volumes of data smoothly.
I�m quite comfortable working with Spark, both in Scala and Python. I have a deep understanding of Spark�s internals�like RDDs, DataFrames, and Spark SQL�and have used these to build reliable and high-performing pipelines. Along with Spark, I�ve also worked a lot with Hive, Redshift, and Athena, which helps me manage both structured and semi-structured data effectively. I�m good at writing complex queries, fine-tuning them for performance, and making sure data is clean and accurate.
When it comes to workflow orchestration, I�ve been using Apache Airflow extensively to schedule and monitor batch pipelines. I also have strong experience with cloud platforms�especially AWS, where I�ve used EMR, Glue, Lambda, and Redshift.and azure as well with HDInsight and Data factory. Yeah, so this is pretty much about me.


Current Project:
I am currently working at H.E.B., a leading retail company with over 400 stores across the states. In my role as a Senior Data Engineer, I lead the development of robust and scalable data lake pipelines designed to support enterprise-wide analytics, machine learning initiatives, and business reporting.
We have multiple data sources� first, Amazon S3, customer PII information; Second, a PostgreSQL database that stores real-time transactional sales data; and third, SQL server that provide's up-to-date product hierarchy and metadata.
In the Bronze Layer, I handle raw ingestion, as it is in raw format.
The Silver Layer focuses on data cleansing, standardization, and applying business logic through Spark transformations� joining product, brand, and sales datasets.
Gold Layer, I deliver curated, partitioned Parquet datasets optimized for downstream analytics teams, enabling insights through tools like Athena and feeding ML models.
 I orchestrate workflows via Apache Airflow, monitor with CloudWatch and Slack integrations, and automate CI/CD using Bitbucket Pipelines and AWS CLI.
These outputs are consumed by data scientists for demand forecasting, BI analysts for dashboarding. Thats overview of recent project.