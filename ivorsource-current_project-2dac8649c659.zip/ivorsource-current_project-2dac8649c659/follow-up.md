Question 1: which Layers are you working on?

Question 2: what is the size of the Data your dealing with?

Question 3: What is the challenge you faced during this project? how did you resolve

Question 4: What is the partition strategy if not bucketing strategy?

Question 5: How are you validating the Data before and after?

question 6: Is your pipeline include the Raw layer as well?

Question 7: Explain the use case of this pipeline?

Question 8: what is the resources and services used and versions?

Question 9: orchestration and scheduling according to this pipeline

Question 10: If your spark job failed where will you start

Question 11: is this part of data lake or lake house