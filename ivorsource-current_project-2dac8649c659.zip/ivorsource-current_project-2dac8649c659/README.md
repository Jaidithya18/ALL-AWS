The Data Science team approached us with specific feature requirements to support forecasting models. 
They needed **enriched datasets** to calculate metrics such as **rolling weekly sales trends, year-over-year comparisons, discount indicators, and holiday impact scores**.
Their models rely on consistently structured, timely data to generate accurate predictions on INVENTORY Management (Holiday), Holiday category sales, Marketing strategy.

Based on this, I designed and implemented a scalable data pipeline that ingests raw data from GCS , PostgreSQL, and internal APIs,
 then transforms and curates it across Bronze, Silver, and Gold layers using Apache Spark.
 In the Silver layer, I applied business rules and joins to standardize the data. 
In the Gold layer, I delivered analytics-ready Parquet files partitioned by product category and week, ensuring they had all the required fields to compute those metrics reliably

 **SOURCE DATA**
Source 1 GCS – Historical Reports (SAS/CSV)

**File: # holiday_calendar_2022.csv**

| holiday_name      | date       | type     | region | is_major |
|-------------------|------------|----------|--------|----------|
| Independence Day  | 2022-07-04 | Federal  | USA    | TRUE     |
| Labor Day         | 2022-09-05 | Federal  | USA    | TRUE     |
| Halloween         | 2022-10-31 | Cultural | USA    | FALSE    |
| Thanksgiving      | 2022-11-24 | Federal  | USA    | TRUE     |


**File: #brand_metadata.csv**

| brand_id | brand_name           | category  | launch_year |
|----------|----------------------|-----------|-------------|
| 101      | H-E-B                | Beverages | 2018        |
| 102      | Central Market       | Dairy     | 2020        |
| 103      | 365 Everyday Value   | Snacks    | 2017        |

Source 2  PostgreSQL – Real-Time Sales Transactions

**Table: sales_transactions**

transaction_id | store_id | product_id | sale_date  | quantity | total_amount
---------------|----------|------------|------------|----------|--------------
TXN0012345     | 107      | 786        | 2025-04-28 | 3        | 14.97
TXN0012346     | 109      | 465        | 2025-04-28 | 1        | 4.99


SOurce 3. Internal REST API – Product Hierarchy


**Endpoint: /api/product/786**

Response: {
  "product_id": 786,
  "product_name": "Sparkling Water 12oz",
  "category": "Beverages",
  "subcategory": "Sparkling Drinks",
  "brand": "H-E-B",
  "is_discontinued": false
}

### Raw Data Ingestion (Bronze Layer)

# Objective
Ingest raw data **as-is** from multiple sources — including **Google Cloud Storage (GCS)**, **PostgreSQL**, and **internal APIs** — into the **Bronze Layer** of the data lake.

---

# Process Overview

1. **Ingestion with Apache Spark**  
   Utilize Apache Spark to read and load the raw datasets (`holiday`, `sales`, and `product` data).

2. **No Transformations Applied**  
   - Data is ingested in its **original format** without applying transformations.  
   - Formats include **CSV**, **JSON**, and **Parquet** depending on the source.

3. **Raw Data Preservation**  
   - Preserve **original structure and metadata** (e.g., timestamps, nulls, casing).  
   - For example, raw holiday data such as `2022-11-24` is ingested exactly as received.

4. **Source-specific Handling**  
   - **GCS**: Read using Spark’s GCS connector.  
   - **PostgreSQL**: Ingest using JDBC connector.  
   - **Internal APIs**: Use HTTP requests to extract and persist data.


**SILVER LAYER**

## What Happens Here (Silver Layer)

### 1. Parse Raw Files  
Convert raw input formats (e.g., complex SAS datasets) into **readable tabular structures** using Spark.

### 2. Normalize Fields

- **Date Standardization**:  
  Convert all date fields from formats like `MM/DD/YYYY` to the standard ISO format `YYYY-MM-DD`.

- **Data Type Correction**:  
  - Clean null or malformed values.  
  - Convert fields (e.g., `price` from string to float).

### 3. Apply Joins

Integrate transactional data (from **PostgreSQL**) with additional datasets:

- **Brand metadata** (from **GCS**)  
- **Holiday calendar** (from **GCS**)  
- **Product hierarchy** (from **internal API**)


## Result

A unified dataset containing **clean and enriched transactional data**, ready for aggregation and analytics.

### Example

| txn_id | sale_date  | product_id | brand_id | sale_price | regular_price | is_discounted | holiday_name  |
|--------|------------|------------|----------|------------|----------------|----------------|----------------|
| TX1001 | 2023-11-24 | P567       | B100     | 9.99       | 12.99          | TRUE           | Black Friday   |


**GOLD**

## Transformation Logic in Gold Layer

### 1. Grouping  
Group data by key dimensions such as **week**, **brand_id**, and **product category**.

### 2. Aggregated Metrics  
Compute business-relevant aggregates, including:
- `total_sales`
- `discounted_sales`
- `transaction_count`

### 3. Derived Features  
Calculate additional fields to support analytics and modeling:
- `discount_rate` = discounted_sales / total_sales
- `holiday_impact_score` = function of sales uplift during holidays

### 4. Partitioning  
Partition the final dataset by **year** and **week** to optimize performance for downstream querying and reporting.


**4.Scheduling and Orchestration – GCP Implementation**

To automate, schedule, and monitor our end-to-end data pipeline on Google Cloud, we use Cloud Composer, which is Google’s managed version of Apache Airflow.

## 1. DAG Design

Each stage of the pipeline — **Ingest → Transform → Curate** — is modeled as a separate task in the DAG.

### Tasks:

- **Ingest Stage**
  - Load raw data from:
    - **GCS** (SAS/CSV formats)
    - **PostgreSQL** (via JDBC)
    - **REST APIs** (for real-time or batch metadata)

- **Transform Stage**
  - Trigger **Dataproc Spark jobs** to:
    - Parse and normalize raw data (Silver Layer)
    - Perform aggregations and enrichments (Gold Layer)

- **Curate Stage**
  - Load curated datasets into:
    - **BigQuery** for analytics
    - **GCS** for downstream batch consumers or archival


2. Scheduling

**Daily Scheduling (During Peak Season)**
When: starts 2–3 weeks before a major holiday through 1 week after

Why: Helps merchandising and inventory teams monitor fast-moving SKUs.

**Weekly Scheduling (Off-Season or Pre-Holiday Planning)**

When: 1–2 months before the holiday season

Why: Supports forecasting models using historical data.

3. Alerting and Monitoring

Integrated with Cloud Logging and Cloud Monitoring

Sends alerts on failure 

Custom alerting thresholds for job duration, data volume drops, etc.

4. CI/CD Integration

DAGs are version-controlled in Bitbucket/GitHub

Deployment handled via Cloud Build or Bitbucket Pipelines


Result:As a Data Engineer, I ensure the Data Science team receives clean, enriched datasets that support inventory planning and restocking decisions, 
especially during peak seasons like holidays.

We provide metrics such as rolling weekly sales trends, YoY comparisons, and holiday impact scores, which help forecast demand surges. 
These insights allow merchandising and operations teams to predict fast-moving SKUs, avoid stockouts, and plan restocking cycles proactively.

This is orchestrated through scheduled pipelines that run daily during peak holiday periods to keep the data fresh and actionable for inventory models.