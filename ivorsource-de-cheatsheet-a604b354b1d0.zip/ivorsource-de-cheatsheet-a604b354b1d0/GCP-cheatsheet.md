***Google Cloud Platform***

1. **BigQuery:-**  
     
   1. **What are BigQuery slots, and how does slot allocation affect performance and cost?**  
      BigQuery slots are units of computational capacity used to execute SQL queries. The more slots allocated to a query, the faster it runs (depending on the query structure and data).I’ve managed both on-demand and flat-rate slot models. For predictable, high-volume workloads, reserving slots (via reservations) gives cost stability and guaranteed performance.  
      I’ve also configured assignments at the project/folder level and used BI Engine slots for low-latency dashboarding.  
   2. **How do you optimize slot usage across multiple teams or projects?**  
      I create slot reservations for each team and use job assignments to control usage. I monitor the Query Execution Details and Slot Utilization metrics via Cloud Monitoring.  
      If a team's queries are underutilizing slots, I reallocate. I also use auto-scaling reservations in workloads that have spikes (e.g., during ETL windows) to reduce idle time.  
   3. **When would you use a Materialized View vs. a regular View in BigQuery?**  
      I use Materialized Views (MVs) when:  
      Queries are read-heavy and don’t change often.  
      There’s an aggregation or filter over a large base table (e.g., daily sales totals).  
      MVs improve performance and lower cost by storing precomputed results.  
      Standard Views, on the other hand, are just saved SQL and get recomputed on each query ideal when the logic must always reflect real-time data.  
   4. **Can you explain how you maintain and refresh Materialized Views?**  
      Materialized Views auto-refresh incrementally every 30 minutes by default.  
      I’ve used the REFRESH MATERIALIZED VIEW command to manually refresh when needed.  
      For complex use cases, I’ve built scheduled queries or Dataform workflows that materialize results into native tables to have more control over freshness and logic.  
   5. **What’s the difference between external and managed tables in BigQuery? When would you choose one over the other?**  
      Managed tables are stored inside BigQuery (backed by Colossus). BigQuery manages storage and performance.External tables reference data in GCS, Drive, or Bigtable without moving it.  
      I use external tables when:  
      There’s a need for a single source of truth across tools.  
      Data must remain in raw GCS format (e.g., CSV, Parquet).  
       need lightweight exploration without ingestion cost.  
      But for analytics, I usually ingest data into native BQ tables for better performance (including partitioning and clustering support).  
   6. **How do partitioning and clustering improve BigQuery performance and reduce cost?**  
      Partitioning divides a table based on a date/time or integer column, reducing the amount of data scanned.  
      Clustering organizes data within partitions (or entire tables) using up to 4 columns, optimizing filtering and joins.  
      In one pipeline, I partitioned logs by `event_date` and clustered by `user_id, event_type`. This reduced query costs by 80% and improved response time by 5x.  
   7. **What are best practices when choosing partitioning and clustering keys?**  
      Choose partition keys with even distribution and high selectivity, typically timestamp/date columns.  
      For clustering, pick frequently filtered or joined columns.  
      Avoid clustering on high-cardinality columns if you’re not filtering on them — that can backfire.  
      Monitor with INFORMATION\_SCHEMA.PARTITIONS and BQ Query Plan UI to validate effectiveness.  
        
   8. **How do you monitor and optimize query performance in BigQuery?**  
      I use the Query Execution Plan to identify bottlenecks — especially on slots, shuffles, and I/O stages.  
      I enable audit logs, use Data Studio / Looker dashboards for monitoring, and trigger alerts via Cloud Monitoring on:  
      Slot saturation  
      Query durations  
      High-cost queries  
      I also use automatic rewriter tools like BigQuery Advisor and review query history with INFORMATION\_SCHEMA.JOBS.  
2. **Dataproc :-**  
   1. What is the difference between an ephemeral and a standard Dataproc cluster? When would you use each?  
      An ephemeral cluster is created dynamically when a job is submitted and automatically deleted afterward. It’s best for cost-optimized batch processing, such as scheduled ETL workflows where clusters don’t need to persist.  
      A standard cluster is long-running, ideal for:  
      Teams that need interactive access to Spark/Hive  
      Frequent ad-hoc queries  
      Shared clusters used across multiple pipeline     
3. **Google Cloud Storage :-**   
   **Standard Storage Class :-**

   For frequently accessed data  
   No minimum duration  
   Low retrieval cost  
   Use for: Active workloads, real-time processing  
   

   **Nearline Storage Class:-**

   Accessed \~1/month  
   30-day minimum storage  
   Moderate retrieval cost  
   Use for: Backups, rarely used files

   **Coldline Storage Class:-**

   Accessed \~1/quarter  
   90-day minimum storage  
   High retrieval cost  
   Use for: Disaster recovery, audit logs  
   

   **Archive Storage Class:-**

   Rarely accessed, long-term  
   365-day minimum storage  
   Highest retrieval cost  
   Use for: Compliance, archives  
     
   1. **How do storage classes affect cost and performance?**  
        
* Each class balances storage cost vs. access frequency.  
* For example, Standard has higher storage cost but lower retrieval cost, which suits frequently accessed data like raw ingestion from IoT.  
* For rarely accessed data, like compliance logs, I use Coldline or Archive, accepting higher retrieval latency to reduce overall storage spend.


  2. **How do you optimize GCS costs in a large-scale data lake?**  
       
* Use appropriate storage classes (e.g., Archive for snapshots, Nearline for aged logs).  
* Set object lifecycle rules to move/delete stale files.  
* Minimize Class A ops by batching writes/reads.  
* Use same-region buckets to reduce egress.  
* Compress files (e.g., GZIP/Parquet) and use columnar formats for analytics.

  3. **How do you implement secure access to GCS for different teams?**  
       
* I use IAM roles like roles/storage.objectViewer, roles/storage.objectAdmin at bucket level.  
* Enable Uniform bucket-level access to avoid ACL sprawl.  
* For fine-grained control, I create service accounts per workload and assign least privilege.  
* For sensitive data (e.g., PII), I use CMEK (customer-managed encryption keys) and audit access via Cloud Audit Logs.


  4. **How do you secure GCS buckets used in ETL pipelines?**  
       
* Buckets are private by default, and only accessible via service accounts with scoped IAM roles.  
* Enforce TLS in transit and CMEK for encryption at rest.  
* Use signed URLs for temporary access when needed.  
* Set up bucket-level audit logging to detect unauthorized access.

4. **Composer ( Airflow ):-**

   1. **How have you used Cloud Composer in data pipelines?**  
        
      I’ve used Cloud Composer to:  
* Orchestrate multi-step ETL pipelines (extract from GCS → transform via Dataproc → load to BigQuery)  
* Schedule daily workflows with retries and alerts  
* Pass data using XComs, leverage Jinja templating, and build custom plugins  
* Trigger ephemeral Dataproc clusters, and manage cleanup jobs post-processing  
    
  2. **How do you handle failures and retries in Composer DAGs?**

* I define retries, retry\_delay, and retry\_exponential\_backoff in task defaults.  
* Use failure callbacks to trigger Slack/email alerts via Cloud Functions.  
* Track lineage using Airflow’s metadata DB and Cloud Logging.  
* If a task fails due to transient issues (e.g., network timeout), it’s retried — but I implement idempotency in Spark jobs and downstream writes.  
    
  3. **Overview of the DAG:**  
       
* Extract data from multiple sources (parallel).  
* Transform data with retries and failure handling.  
* Load data conditionally based on success/failure of previous tasks.  
* Use external dependencies to wait for external tasks to complete.

 
``` sh  
from airflow import DAG  
from airflow.operators.python\_operator import PythonOperator, BranchPythonOperator  
from airflow.sensors.external\_task import ExternalTaskSensor  
from datetime import datetime, timedelta

\# Function definitions for ETL tasks  
def extract\_data\_source\_1():  
    print("Extracting data from source 1...")

def extract\_data\_source\_2():  
    print("Extracting data from source 2...")

def transform\_data():  
    print("Transforming data...")

def load\_data():  
    print("Loading data...")

\# Function for branching logic (conditional execution)  
def branch\_logic():  
    \# Example condition: If source 1 extraction is successful, proceed with transformation  
    flag \= True  \# This flag could be dynamically determined from the previous task  
    if flag:  
        return 'task\_a'  \# Proceed to Task A (e.g., transformation)  
    else:  
        return 'task\_b'  \# Proceed to Task B (e.g., alternative logic)

\# Define the DAG  
dag \= DAG(  
    'comprehensive\_etl',  
    description='ETL pipeline with retries, parallel tasks, branching, and external dependencies',  
    schedule\_interval='@daily',  
    start\_date=datetime(2023, 1, 1),  
    catchup=False,  
    default\_args={  
        'retries': 3,  \# Default retries for the tasks  
        'retry\_delay': timedelta(minutes=5),  \# Wait for 5 minutes before retrying  
    }  
)

\# Tasks  
task\_extract1 \= PythonOperator(  
    task\_id='extract\_data\_source\_1',  
    python\_callable=extract\_data\_source\_1,  
    dag=dag,  
    retries=2,  \# Retry 2 times if it fails  
    retry\_delay=timedelta(minutes=3),  
)

task\_extract2 \= PythonOperator(  
    task\_id='extract\_data\_source\_2',  
    python\_callable=extract\_data\_source\_2,  
    dag=dag,  
    retries=1,  \# Retry 1 time if it fails  
    retry\_delay=timedelta(minutes=3),  
)

task\_transform \= PythonOperator(  
    task\_id='transform\_data',  
    python\_callable=transform\_data,  
    dag=dag,  
)

task\_load \= PythonOperator(  
    task\_id='load\_data',  
    python\_callable=load\_data,  
    dag=dag,  
)

\# External task sensor: Wait for task 'task\_data\_loaded' in another DAG to complete before proceeding  
task\_wait\_for\_external \= ExternalTaskSensor(  
    task\_id='wait\_for\_external\_task',  
    external\_dag\_id='external\_data\_loading\_dag',  \# The other DAG  
    external\_task\_id='task\_data\_loaded',  
    poke\_interval=15,  \# Check every 15 seconds  
    timeout=600,  \# Timeout after 10 minutes  
    mode='poke',  \# Or use 'reschedule' for better efficiency  
    dag=dag,  
)

\# Branching task: Based on condition, run task\_a or task\_b  
branch\_task \= BranchPythonOperator(  
    task\_id='branch\_logic',  
    python\_callable=branch\_logic,  
    provide\_context=True,  
    dag=dag,  
)

task\_a \= PythonOperator(  
    task\_id='task\_a',  
    python\_callable=transform\_data,  \# Placeholder logic, can be modified  
    dag=dag,  
)

task\_b \= PythonOperator(  
    task\_id='task\_b',  
    python\_callable=load\_data,  \# Placeholder logic, can be modified  
    dag=dag,  
)

\# Setting up task dependencies

\# Parallel extraction: These tasks will run at the same time  
task\_extract1 \>\> task\_wait\_for\_external  
task\_extract2 \>\> task\_wait\_for\_external

\# After the external task finishes, it branches depending on the flag  
task\_wait\_for\_external \>\> branch\_task

\# Task A or Task B will run based on the condition defined in branch\_logic  
branch\_task \>\> \[task\_a, task\_b\]

\# Transform runs after both extraction tasks complete (and external task is ready)  
task\_a \>\> task\_transform  
task\_b \>\> task\_transform

\# Finally, load data after transformation  
task\_transform \>\> task\_load

``` sh

#### **1\. Basic ETL Flow:**

* **Extract tasks** (`task_extract1`, `task_extract2`):  
  * **Extract data** from two sources in parallel.  
  * We simulate this with simple print statements, but in real use cases, you would connect to databases, APIs, or files.

  #### **2\. Parallel Execution (Extraction):**

* The tasks **`task_extract1`** and **`task_extract2`** run **in parallel** since there is no dependency between them.  
* Both tasks must finish before the **external dependency** task (`task_wait_for_external`) begins.

  #### **3\. External Task Sensor:**

* The **`ExternalTaskSensor`** waits for an **external task (`task_data_loaded`)** from another DAG (`external_data_loading_dag`) to complete.  
  * **`poke_interval`** and **`timeout`** control how often it checks and how long it waits.  
  * Once the external task is complete, the DAG proceeds to the next step.  
    

  #### **4\. Conditional Execution (Branching):**

* **`BranchPythonOperator`** allows the DAG to branch based on a condition. Here, we check a flag (`flag`) and decide whether to run **`task_a`** or **`task_b`**.  
  * If `flag=True`, run **`task_a`**.  
  * If `flag=False`, run **`task_b`**.  
  * This is an example of how you can implement branching logic based on the result of prior tasks or external factors.

  #### **5\. Task Dependencies:**

* **`task_wait_for_external`** must complete before **`branch_task`** runs.  
* **`branch_task`** decides whether to run **`task_a`** or **`task_b`**.  
* After either **`task_a`** or **`task_b`** completes, **`task_transform`** runs.  
* Finally, **`task_load`** runs after **`task_transform`** completes.

  #### **6\. Task Retries and Delays:**

* Tasks like **`task_extract1`** and **`task_extract2`** have retries and **retry\_delay** to handle transient failures.  
  * `task_extract1` will retry **2 times** with a **3-minute delay**.  
  * `task_extract2` will retry **1 time** with a **3-minute delay**.  
  * **Task retry** is useful when you know that the failure might be temporary (e.g., network or service issue).

  #### **7\. Success/Failure Handling:**

* You can add **failure handling** (like **on\_failure\_callback**) to notify users or trigger compensating actions (e.g., using **Slack notifications**, etc.).  
          