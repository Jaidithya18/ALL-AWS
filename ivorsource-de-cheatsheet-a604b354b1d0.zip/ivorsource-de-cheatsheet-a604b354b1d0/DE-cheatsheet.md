***Data Engineering Cheat Sheet*** 

***Spark Topics:-***

1. Narrow \- Wide   
2. Transformations Actions  
3. Cache / Persist  
4. Repartition / Coalesce  
5. Broadcast Join  
6. Broadcast Variables  
7. Data Skew  
8. Shuffling  
9. Spark submit  
   1. Configuration  
10. Spark Architectures  
11.      RDD / Dataframe / Dataset  
12. File Formats  
13. Lazy Evaluation  
14. Spark UI  
15. Spark History Server  
16. Spark Session / Spark Context  
17. AQE (Adaptive Query Engine)   
18. Catalyst optimizer / Tungsten  
19. Spark Main Method  
20. Spark Program Explanation  
    1. Read  
    2. Write  
    3. Transformation

***GCP Topics:-***

1. BigQuery  
   1. Slots  
   2. Materialized Views / Views  
   3. External / Managed Tables  
   4. Partitioning / Clustering  
        
2. DataProc  
   1. Ephemeral Cluster / Standard Cluster  
3. Google Cloud Storage  
   1. Storage Classes  
   2. Storage Costs  
   3. Access Control  
4. Composer (AirFlow)  
   1. Explain Simple DAG with ALL scenarios  
5. Hive  
6. SCALA / SPARK  
   1. Sample Program  
   2. VAL / VAR  
   3. POM.XML  
   4. Maven  
   5. Case Class  
7. Challenging Situations   	  
   1. Data Skew (STAR)   
8. Project Datasets   
   1. STAR  
9. Apache Hudi  
10. Real Time Tasks  

***SQL:-***  
1. Rank  
2. Dense Rank  
3. ROW\_NUMBER  
4. CTE  
5. Joins  
6. Aggregate Functions  
7. Group By  
8. Where Clause  
9. Second Highest Salary

	 