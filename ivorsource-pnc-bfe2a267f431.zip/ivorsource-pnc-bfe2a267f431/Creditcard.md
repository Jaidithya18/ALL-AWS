Credit Data- Data Lake Pipeline (Daily Batch Processing)
Objective
To build a daily batch processing pipeline that ingests data from 2 sources and perform transformation based on downstream/Business requirements.


**Situation:**
Our bank wanted to build a robust and scalable daily batch data pipeline for credit card fraud detection and customer behavior analysis. 
The goal was to process transaction and customer profile data from multiple OLTP sources, ensuring clean, validated, and transformed data for analytics teams.


TASK:
I was responsible for designing and implementing a data lake architecture that would:

Ingest data from PostgreSQL and SQL Server.

Perform data quality checks, cleansing, and feature engineering.

Deliver processed data to an S3 bucket for downstream consumption, enabling risk scoring and analytics.

ACTION:
Step 1: Ingestion

Used AWS DMS to pull transaction data from PostgreSQL and store it in S3 (RAW layer).

Used AWS Glue ETL for ingesting customer profiles from SQL Server to S3 (RAW layer).

Step 2: Data Quality Checks

Used AWS Glue and PySpark to perform:

Schema validation

Completeness checks on critical fields like amount

Duplicate detection

Business logic validation (e.g., valid card types, transaction types)

Step 3: Data Cleaning & Processing

Used Apache Spark on EMR to clean and standardize data:

Removed duplicates

Normalized date formats

Imputed missing values for location using recent data

Encoded categorical fields like transaction_type into numerical features


Step 4: Joining & Feature Engineering

Performed a Spark SQL join between transaction and customer datasets on customer_id.

Created derived features like:

Transaction Frequency per customer per day

High-value transaction flags (e.g., > $5,000)

Detected location anomalies and spending behavior trends
Step 5: Storage

Stored the processed data in S3 (s3://fraud-data/processed/) in Parquet format, partitioned by date for optimal performance.


RESULT:
The daily pipeline is now fully automated, processing data from source to S3 in under 30 minutes.

Enabled downstream teams to access clean, analytics-ready data for fraud detection models and reporting.

Reduced data quality issues by 95% and improved model accuracy due to enhanced feature engineering and cleansing.




Step 1: Data Sources 

**Dataset							Source System													Storage Format						Update Frequency**
Credit Card Transactions				Bank OLTP databases (PostgreSQL, Oracle)						CSV / Parquet						Continuous (Processed Daily)
Customer Profiles				INTERNAL SQL Server  											JSON / Parquet							Daily
				



Dataset table details


1.Card Transactions Dataset

Example Row in the Card Transactions Dataset:

transaction_id	customer_id	merchant_id	 amount 	transaction_time	transaction_type	card_type	device_id	ip_address		location
TXN1001			CUST1001	MERCHANT001	 200.50	  2025-03-19 10:30:00  		Online			Visa       DEVICE1234	192.168.1.1		(40.7128, -74.0060)


2.Customer Profiles Dataset
Example Row in the Customer Profiles Dataset:

customer_id 	name	email				dob				address						account_open_date	credit_score	historical_spending				last_login_time
CUST1001	  John Doe	johndoe@email.com	1980-05-15	1234 Elm St, New York, NY		2015-08-20				750				1500						2025-03-19 09:00:00


STEP-2 **Ingestion**

1.Transaction Data (PostgreSQL) → S3 (RAW DATA)

Extracted using **AWS DMS**or **custom ETL scripts** (Python/Spark)

2. Customer Data (SQL Server) → S3 (RAW DATA)

Extracted using **AWS Glue ETL**


STEP-3
**3.1 Data Schema Validation (AWS Glue or PySpark)**


**3.2.Data Completeness Check** 
Ensures there are no null or missing values in critical Column like **Transaction Amt**

**3.3 Duplicate Data Check**
 Ensure no misleading information
 
 
**3.4 Business Rule Checks**
Validates whether transaction data follows expected **business logic.**


**LOADS DATA FROM RAW TO STAGE LAYER**


**STEP 4: Data Processing (ETL)** using **SPARK** in EMR or GLUE






**4.1 Data Cleaning** based on requirement

1.Remove duplicate transactions. As this could lead to missleading data
2.Standardize date formats.
3.Handle missing values (e.g., impute missing locations with past values).
4.Convert categorical fields like Transaction_Type into numerical values for modeling.

**4.2 Data Joining** (Customer + Transactions)
Using Spark SQL

Example after join

Transaction_ID		Customer_ID			Timestamp	Amount  	Location	Transaction_Type	Device_ID	Credit_Score	Account_Creation_Date	Account_Status
T123456				C1001		2025-03-18  14:45:23	500.00	   New York	  Online Purchase	  D45678    	750	       			2018-06-12	          	Active
T123457				C1002		2025-03-18  15:10:05	2000.00	   Chicago	  ATM Withdrawal	  D89234	      650	  			  2020-02-19				Active
T123459				C1003		2025-03-18  16:05:30	10000.00	Miami	  Wire Transfer   	 D90213	         400	  			  2016-09-08			Active

**4.3 Detecting Location Changes** cutomer based aggregations week based or daily (customer based spending/ on category type spending (cust -bucketing using join )
Using

**STEP 4: Feature Engineering** (Risk Score Calculation)

Transaction Frequency: Count the number of transactions per customer per day.
High-Value Transactions: Flag transactions above a threshold (e.g., $5,000).

STEP 5: Storing Processed Data

**Processed dataset stored in S3 (s3://fraud-data/processed/).**








