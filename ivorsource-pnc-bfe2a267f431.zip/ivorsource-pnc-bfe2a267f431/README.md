# README #

PNC Current project detials

### What is this repository for? ###

* Quick summary- Present roles and responsibilties
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

**Objective:**
Build a scalable, efficient, and secure data pipeline to ingest, process, and store transaction and customer loan data in a data lake for analytics, reporting, and compliance.

**1**
Data Sources:

**DATASET**
A. Loan Transactions Dataset (loan_transactions)
Contains all financial activities related to a loan, including disbursements, repayments, interest calculations, and defaults.

transaction_id	customer_id	loan_id 	transaction_type	transaction_date	amount	interest_rate	status
TXN001			CUST1001	LOAN5001	Disbursement	     2024-01-01	   		50,000		6.5%		Success
TXN002			CUST1001	LOAN5001	Monthly Payment		2024-02-01			1,500		6.5%		Success
TXN003			CUST1002	LOAN5002	Disbursement		2024-01-15			75,000		7.2%		Success
TXN004			CUST1002	LOAN5002	Default Payment		2024-04-01			0			7.2%	



B. Customer Information Dataset (customer_info)
Contains personal details of customers applying for loans, including their income, credit score, and employment status.

customer_id	first_name	last_name	dob	credit_score	income		employment_status	loan_count	risk_category
CUST1001	John		Doe			1985-06-20			750	80,000	Full-time				2			Low
CUST1002	Alice		Smith		1990-09-10			620	55,000	Part-time				1			Medium
CUST1003	Bob			Johnson		1982-12-05			580	40,000	Unemployed				3			high

C. Credit Bureau Reports (credit_bureau_reports)
Contains external financial history data about customers, including their overall credit health and past delinquencies.

report_id	customer_id	credit_score	report_date	credit_utilization	delinquency_count	bankruptcy_history
REP001		CUST1001		750			2024-02-01			25%					0					No
REP002		CUST1002		620			2024-02-01			45%					2				    No
REP003		CUST1003		580			2024-02-01			65%					5					Yes

**Source**:
Transation dataset-OLTP real-time data which is stored in ( PostgreSQL, MySQL, Oracle )

Customer dataset Source:  internal customer database

Credit Bureau Reports Source: External agencies like Equifax (PNC subscribed to 3rd party)


**Ingestion**

 (Transation dataset) ---**Ingestion** to Data Lake: Extracted daily or monthly via ETL tools (AWS Glue)
 
 (Customer PII) ----**Ingestion** to Data Lake: Batch extraction (daily or weekly) using ETL pipelines

(credit bureau)---**Ingestion** Monthly or on-demand batch ingestion via API data pulls   
Data stored in AWS S3 


**INGESTION SUMMARY**

1. Data Ingestion (Extract & Load)
Before processing, data is ingested into the Raw Zone of the data lake from different sources:

Loan Transactions: Extracted daily from core banking OLTP databases (PostgreSQL, Oracle) → stored as CSV/Parquet in Amazon S3
Customer Information: Extracted from Internal source database → stored as JSON/Parquet in S3
Credit Bureau Reports: Pulled monthly from Experian/Equifax APIs → stored in JSON/XML format in S3


**2** Data Processing
 (Transformation & ETL)  **using AWS Glue (PySpark), Apache Spark**

A. Data Cleaning & Standardization

Remove duplicates				 (e.g., multiple credit reports for the same customer)
Handle missing values			 (e.g., replace NULL income values with median)
Convert data types 				 (e.g., credit_score from STRING → INTEGER)

B. Data Enrichment (Joining Multiple Datasets)
Next, we join the datasets to create a consolidated loan risk profile.

Example Processed Data After Joining: To get deeper view
customer_id	name	internal_credit_score	bureau_credit_score	delinquency_count	transaction_type	amount	risk_category
CUST1001	John	750						750						0				Monthly Payment		1500		Low
CUST1002	Alice	620						620						2				Default Payment		0		Medium
CUST1003	Bob		580						580						5				Late Payment		120		High



C.Feature Engineering for Risk Score Calculation 
**we derive new insights from raw data in this step.**

Feature Name								Formula/Logic									Purpose
Debt-to-Income Ratio (DTI)					total_debt / income					Measures ability to repay loans. High DTI (>40%) is risky.

Credit Utilization Rate					credit_used / credit_limit				Indicates how much credit is being used. High (>50%) is risky.


**FINAL**

Steps:
Load the cleaned & joined data from Amazon S3 (Processed Zone).
Compute new features using PySpark or SQL-based transformations.
Store enriched data back to Amazon S3 (Curated Zone)(target) or Amazon Redshift.
Expose the risk scores for BI tools or Machine Learning models.